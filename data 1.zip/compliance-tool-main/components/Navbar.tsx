"use client";

import Link from "next/link";
import Image from "next/image";
import { FaGlobe, FaSearch, FaUserTie } from "react-icons/fa";
import { BsBoxArrowRight } from "react-icons/bs";
import { usePathname } from "next/navigation";

export default function Navbar() {
  const pathname = usePathname();
  let isLoggedIn = true;

  if (pathname.includes("/login")) {
    isLoggedIn = false;
  }

  return (
    <div className="container-fluid m-0 p-0 position-sticky">
      {isLoggedIn ? (
        <header className="d-flex flex-wrap justify-content-space-between">
          <div className="col-md-12 row align-items-center m-0 p-3 adminnav  ">
            <div className="col-md-4 px-4">
              <Link href="/">
                {" "}
                <Image
                  src="/regucheck_logo.png"
                  alt="ReguCheck"
                  width={180}
                  height={40}
                />
              </Link>
            </div>

            <div className="col-md-8">
              <ul className="nav d-flex flex-wrap align-items-center justify-content-end">
                <li className="nav-item dropdown">
                  <div className="nav-link text-decoration-none py-2 text-black">
                    <FaSearch />
                  </div>
                </li>
                <li className="nav-item dropdown">
                  <div className="nav-link text-decoration-none py-2 text-black">
                    <FaGlobe /> English
                  </div>
                </li>
                <li className="nav-item dropdown">
                  <Link
                    className="btn light btn-primary light btn-lg btn-rounded mx-2 py-2"
                    href="#!"
                  >
                    <FaUserTie className="mx-2" size={20} />
                    Nikhil Chouhan
                  </Link>
                </li>
                <li className="nav-item">
                  <Link
                    href="/login"
                    className="btn light btn-danger btn-md btn-rounded"
                  >
                    <BsBoxArrowRight className="mx-2" size={20} />
                    <b>Logout</b>
                  </Link>
                </li>
              </ul>
            </div>
          </div>
        </header>
      ) : (
        <header className="d-flex flex-wrap justify-content-space-between py-2 px-4">
          <div className="row">
            <div className="col-md-12">
              <Image src="/logo.png" alt="Logo" width={100} height={50} />
            </div>
          </div>
        </header>
      )}
    </div>
  );
}
