import React, { useState, useRef } from "react";
import Link from "next/link";
import { BsFileText, BsHouse } from "react-icons/bs";

import LoadingOverlay from "@/components/LoadingOverlay";
import Toast, { ToastType } from "@/components/Toast_old";

export default function FormComponent({
  slug,
  type,
  page,
  addborder,
  formFields,
  insideModel,
  showbreadCrumb,
}) {
  const [loading] = useState(false);
  const toastRef = useRef<ToastType>();
  formFields.hidden = formFields.hidden ?? false;
  const [showchildField, setShowChildField] = useState(false);
  addborder = addborder ?? "";

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === "status" && page === "Audit Remarks") {
      if (value === "Non Complied") {
        setShowChildField(true);
      } else {
        setShowChildField(false);
      }
    }
  };

  return (
    <>
      <main className={`container-fluid h-100 ${insideModel ? " pt-2 " : ""}`}>
        <div className="custom_row row h-100">
          {showbreadCrumb && (
            <div className="d-flex justify-content-start align-items-center">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <Link href="/" className=" breadcrumb-item">
                    <BsHouse className="mb-1 mx-3" />
                  </Link>

                  <Link
                    href={slug}
                    className="text-decoration-none breadcrumb-item"
                  >
                    {page}
                  </Link>
                  <li className="breadcrumb-item active" aria-current="page">
                    {type} {page}
                  </li>
                </ol>
              </nav>
            </div>
          )}
          <form className={`h-100 px-0 ${addborder}`}>
            <div className="row custom_row bg-white rounded-corner p-4">
              <div className="col-md-12 mb-2">
                <h5 className="fw-strong mt-2 mb-3 ">
                  <BsFileText className="mb-1 mx-3 fw-bold" />
                  {type} {page}
                </h5>

                <hr></hr>
              </div>

              {formFields.map((field, index) => (
                <div
                  key={index}
                  className="col-md-6 mb-3"
                  style={{
                    display: field.hidden
                      ? showchildField
                        ? "block"
                        : "none"
                      : "block",
                  }}
                >
                  <label
                    htmlFor={field.name}
                    className="form-label text-muted" // Apply bold style here
                  >
                    {field.label}{" "}
                    {field.required && <span className="text-danger">*</span>}
                  </label>
                  {field.type === "select" ? (
                    <select
                      className="form-select form-control input-padding"
                      id={field.name}
                      name={field.name}
                      onChange={handleChange}
                      multiple={field.multiselect}
                      required={field.required}
                      disabled={field.disabled}
                    >
                      <option value="" disabled>
                        Select {field.label}
                      </option>
                      {Array.isArray(field.options) ? (
                        field.options.map((option) => (
                          <option key={option.value} value={option.value}>
                            {option.label}
                          </option>
                        ))
                      ) : (
                        <option value="" disabled>
                          Options not available
                        </option>
                      )}
                    </select>
                  ) : field.type === "textarea" ? (
                    <textarea
                      className="form-control input-padding"
                      id={field.name}
                      name={field.name}
                      onChange={handleChange}
                      rows="4"
                      cols="50"
                      required={field.required}
                      disabled={field.disabled}
                    />
                  ) : (
                    <input
                      type={field.type}
                      className={
                        field.name == "date"
                          ? "form-control datecss input-padding"
                          : "form-control input-padding"
                      }
                      onChange={handleChange}
                      id={field.name}
                      name={field.name}
                      required={field.required}
                      disabled={field.disabled}
                    />
                  )}
                </div>
              ))}

              <div className="col-md-12 text-end">
                <button
                  type="submit"
                  className="btn btn-outline-dark btn-hover-none mx-1"
                >
                  <Link href={slug} className="text-decoration-none text-dark">
                    Cancel{" "}
                  </Link>
                </button>
                <button type="submit" className="btn btn-primary light mx-1">
                  {type} {!insideModel ?? page}
                </button>
              </div>
            </div>
          </form>
        </div>

        <LoadingOverlay isLoading={loading} />
        <Toast ref={toastRef} />
      </main>
    </>
  );
}
