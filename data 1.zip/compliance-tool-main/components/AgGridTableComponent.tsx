import React, { useState, useMemo, useRef } from "react";
import { AgGridReact } from "ag-grid-react";
import "ag-grid-enterprise";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-alpine.css";
import { GridApi, ColDef } from "ag-grid-community";
import { FaPlus } from "react-icons/fa";
import {
  BsCardList,
  BsPencil,
  BsTrash,
  BsEye,
  BsCheck2Circle,
  BsXCircle,
  BsHouse,
} from "react-icons/bs";

import Link from "next/link";
import Toast, { ToastType } from "@/components/Toast_old";
import AgGridLoader from "@/components/AgGridLoader";
import { Button, Modal } from "react-bootstrap";

interface Column {
  headerName: string;
  field: string;
  islink: boolean;
  isapi: boolean;
}

interface GridComponentProps {
  slug: string;
  page: string;
  customColumns: Column[];
  customRows: [];
  modalData: [];
  edit: string;
  aggridHeight: string;
  aggridPadding: string;
  actionBtn: boolean;
  importBtn: boolean;
  exportBtn: boolean;
  addBtn: boolean;
  customBtn: string;
  checkBox: boolean;
  checkboxActivity: boolean;
  extraActionBtn: string;
  customChangeMethod: string;
  gridApiRef: React.RefObject<GridApi | null>;
  rowClickSelection: boolean;
  handleRowClick: string;
  showbreadCrumb: boolean;
  previousPage: string;
}

export default function AgGridTableComponent({
  slug,
  page,
  customColumns,
  customRows,
  edit,
  modalData,
  aggridHeight,
  aggridPadding,
  actionBtn,
  importBtn,
  exportBtn,
  addborder,
  addBtn,
  customBtn,
  onButtonClick,
  onItemClick,
  checkBox,
  checkboxActivity,
  extraActionBtn,
  customChangeMethod,
  gridApiRef,
  rowClickSelection,
  handleRowClick,
  showbreadCrumb,
  previousPage,
}: GridComponentProps) {
  // const [rowData, setRowData] = useState(customRows);
  const rowData = customRows;
  const handleChangeMethod = customChangeMethod;
  const [refreshGrid] = useState(false);
  aggridHeight = aggridHeight ?? "550px";
  aggridPadding = aggridPadding ?? "p-4";
  addborder = addborder ?? "";
  const toastRef = useRef<ToastType>();
  const [paginationPageSize] = useState(10);
  const [showConfirmationModal, setShowConfirmationModal] = useState(false);

  const handleClick = () => {
    const responseData = true;
    onButtonClick(responseData);
  };

  const handleCompleteConfirmation = () => {
    setShowConfirmationModal(false);
  };

  const handleCancelConfirmation = () => {
    setShowConfirmationModal(false);
  };


  const columnDefs = (showCheckbox) => {
    const columns = customColumns.map((column) => {
      return {
        headerName: column.headerName,
        field: column.field,
        flex: column.flex,
        filter: "agTextColumnFilter",
        minWidth: 200,
        cellClass: "custom-cell centered-cell",
        cellRenderer: (params) => {
          const fieldtext = params.data[column.field];
          return (
            <div
              title={fieldtext}
              className={` ${
                column.islink ? "text-primary text-decoration-underline" : ""
              }`}
            >
              {fieldtext}
            </div>
          );
        },
      };
    });

    if (showCheckbox) {
      columns.unshift({
        headerCheckboxSelection: true,
        checkboxSelection: true,
        headerName: "Select",
        cellClass: "custom-cell centered-cell",
        width: 120,
        filter: false,
        editable: false,
        sortable: false,
        resizable: false,
        floatingFilter: false,
      });
    }

    if (edit) {
      columns.push({
        headerName: "",
        cellClass: "custom-cell centered-align-cell",
        cellRenderer: () => {
          return (
            <>
              {edit === "Edit" ? (
                <Link
                  className="text-decoration-none"
                  href={``}
                  onClick={handleClick}
                >
                  <BsPencil className="m  1-1 mx-1" />
                </Link>
              ) : edit === "Complete" ? (
                <button
                  className="btn btn-primary light "
                  onClick={handleClick}
                >
                  {edit}
                </button>
              ) : (
                <button className="btn btn-primary light ">{edit}</button>
              )}
            </>
          );
        },
        width: 110,
        editable: false,
        sortable: false,
        resizable: false,
        floatingFilter: false,
        pinned: "right",
      });
    }
    if (extraActionBtn) {
      columns.push({
        headerName: "",
        cellClass: "custom-cell centered-align-cell",
        cellRenderer: () => {
          return (
            <>
              {extraActionBtn === "Edit" ? (
                <Link className="text-decoration-none" href={``}>
                  <BsPencil className="m1-1 mx-1" />
                </Link>
              ) : extraActionBtn === "Activate" ? (
                <button className="d-flex align-items-center btn btn-success light ">
                  <BsCheck2Circle className="m1-1 mx-1" /> {extraActionBtn}
                </button>
              ) : extraActionBtn === "Deactivate" ? (
                <Link className="text-decoration-none" href={``}>
                  <BsXCircle className="m1-1 mx-1" />
                </Link>
              ) : (
                <button className="btn btn-primary light ">
                  {extraActionBtn}
                </button>
              )}
            </>
          );
        },
        width: 5,
        editable: false,
        sortable: false,
        resizable: false,
        floatingFilter: false,
        pinned: "right",
      });
    }

    if (actionBtn) {
      columns.push({
        headerName: "Action",
        cellClass: "custom-cell centered-align-cell",
        cellRenderer: (params) => {
          const status = params.data.status;

          return (
            <>
              <div className="d-flex justify-content-center align-items-center">
                <button
                  title={`Change Status to ${
                    status === 1 ? "Inactive" : "Active"
                  }`}
                  className="btn btn-link text-decoration-none fs-14 p-1"
                >
                  {status === 1 ? (
                    <BsXCircle className="text-decoration-none" />
                  ) : (
                    <BsCheck2Circle className="text-decoration-none" />
                  )}
                </button>

                <button
                  title="View"
                  className="btn btn-link text-decoration-none fs-14 p-1"
                >
                  <Link className="text-decoration-none" href={`${slug}/edit`}>
                    <BsEye className="text-decoration-none" />
                  </Link>
                </button>

                <button className="btn btn-link text-decoration-none fs-14 p-1">
                  <Link
                    title="Edit"
                    className="text-decoration-none"
                    href={`${slug}/edit`}
                  >
                    <BsPencil className="text-decoration-none" />
                  </Link>
                </button>

                <button
                  title="Delete"
                  className="btn btn-link text-decoration-none fs-14 p-1"
                >
                  <BsTrash className="text-decoration-none" />
                </button>
              </div>
            </>
          );
        },
        width: 105,
        filter: false,
        editable: false,
        sortable: false,
        resizable: false,
        floatingFilter: false,
        pinned: "right",
      });
    }

    return columns;
  };

  const defaultColDef = useMemo<ColDef>(() => {
    return {
      filter: true,
      floatingFilter: true,
      sortable: true,
      editable: false,
      headerClass: "centered-header",
      autoSizeColumn: true,
      flex: 1,
      resizable: true,
      autoHeight: true,
      cellStyle: { "white-space": "normal" },
    };
  }, []);

  const gridOptions = {
    pagination: true,
    paginationPageSize: paginationPageSize,
    alwaysShowVerticalScroll: true,
    onCellClicked: (event: CellClickedEvent) => {
      const columnName = event.column
        ? event.column.getColId()
        : "Unknown Column";

      if (columnName == "certificate" || columnName == "documents") {
        const url = "/sample-data/SamplePDF.pdf";
        const a = document.createElement("a");
        a.href = url;
        a.download = "certificate_sample.pdf";
        document.body.appendChild(a);
        a.click();
        a.remove();
      }

      if (columnName == "client_activity_id") {
        onItemClick(event);
      }
    },
  };

  return (
    <>
      <main className="container-fluid container-padding-25">
        {showbreadCrumb && (
          <div className="d-flex justify-content-start align-items-center mb-2">
            <nav aria-label="breadcrumb">
              <ol className="breadcrumb">
                <Link href="/" className=" breadcrumb-item">
                  <BsHouse className="mb-1 mx-3" />
                </Link>

                <Link
                  href={slug}
                  className="text-decoration-none breadcrumb-item"
                >
                  {previousPage}
                </Link>
                <li className="breadcrumb-item active" aria-current="page">
                  {page}
                </li>
              </ol>
            </nav>
          </div>
        )}
        <div
          className={`row custom_row bg-white rounded-corner h-100 ${aggridPadding} ${addborder}`}
        >
          <div className="col-md-12 px-0">
            <div className="d-flex justify-content-between align-items-center mb-2">
              <h5 className="fw-strong">
                {page && <BsCardList size={25} className="mx-3 " />}
                {page}
              </h5>
              <div className="d-flex ml-auto">
                {importBtn && (
                  <div>
                    <Link
                      href={`${slug}/import`}
                      className="btn btn-primary light px-2 mx-2 py-1"
                    >
                      <FaPlus className="mb-1 mx-1" /> Import
                    </Link>
                  </div>
                )}
                {addBtn && (
                  <Link
                    href={`${slug}/add`}
                    className="btn btn-primary light px-2 mx-2 py-1"
                  >
                    <FaPlus className="mb-1 mx-1" /> Add
                  </Link>
                )}
                {checkboxActivity && (
                  <div>
                    <button className="btn btn-success light px-2 mx-2 py-1">
                      <BsCheck2Circle className="mb-1 mx-1" /> Activate
                    </button>
                    <button className="btn btn-danger light px-2 mx-2 py-1">
                      <BsXCircle className="mb-1 mx-1" /> Deactivate
                    </button>
                  </div>
                )}
                {exportBtn && (
                  <Link
                    href="/sample-data/sampleCSV.csv"
                    target="_blank"
                    download
                    className="btn btn-primary light px-2 mx-2 py-1"
                  >
                    <FaPlus className="mb-1 mx-1" /> Export
                  </Link>
                )}
                {customBtn && (
                  <button
                    className="btn btn-primary light px-2 mx-2 py-1"
                    onClick={handleClick}
                  >
                    <FaPlus className="mb-1 mx-1" /> {customBtn}
                  </button>
                )}
              </div>
            </div>

            <div
              className="ag-theme-alpine my-3"
              style={{ height: aggridHeight, width: "100%" }}
            >
              <AgGridReact
                key={refreshGrid}
                rowSelection="multiple"
                columnDefs={columnDefs(checkBox)}
                gridOptions={gridOptions}
                rowData={rowData}
                pagination="true"
                defaultColDef={defaultColDef}
                loadingOverlayComponent={AgGridLoader}
                enableColResize={true}
                animateRows={true}
                onSelectionChanged={handleChangeMethod}
                onRowClicked={handleRowClick}
                suppressRowClickSelection={rowClickSelection}
                sideBar={{
                  toolPanels: [
                    {
                      id: "id",
                      labelDefault: "Columns",
                      labelKey: "labelKey",
                      iconKey: "iconKey",
                      toolPanel: "agColumnsToolPanel",
                      toolPanelParams: {
                        suppressPivotMode: true,
                        suppressValues: true,
                        suppressRowGroups: true,
                      },
                    },
                  ],
                }}
                onGridReady={(params) => {
                  if (gridApiRef) {
                    gridApiRef.current = params.api;
                  }
                }}
              />
            </div>
          </div>
        </div>
        <Toast ref={toastRef} />
        <Modal show={showConfirmationModal} onHide={handleCancelConfirmation}>
          <Modal.Header closeButton>
            <Modal.Title>Complete Audit</Modal.Title>
          </Modal.Header>
          <Modal.Body className="pb-0">
            {modalData?.map((item, index) => (
              <div className="row mb-1" key={index}>
                <div className="col-md-4">
                  <p
                    className={`bg-${
                      index % 2 === 0 ? "white" : "light-blue"
                    } mb-2 p-2`}
                  >
                    {item.id}:
                  </p>
                </div>
                <div className="col-md-8">
                  <p
                    className={`bg-${
                      index % 2 === 0 ? "white" : "light-blue"
                    } mb-2 p-2`}
                  >
                    {item.value}
                  </p>
                </div>
              </div>
            ))}
            Are you sure you want to complete this audit?
          </Modal.Body>
          <Modal.Footer className="pt-0 pb-0">
            <Button variant="secondary" onClick={handleCancelConfirmation}>
              Cancel
            </Button>
            <Button variant="primary" onClick={handleCompleteConfirmation}>
              Complete
            </Button>
          </Modal.Footer>
        </Modal>
      </main>
    </>
  );
}
