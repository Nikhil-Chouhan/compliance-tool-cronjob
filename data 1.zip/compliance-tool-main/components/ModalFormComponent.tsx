import React from "react";
import { Modal } from "react-bootstrap";
import FormComponent from "./FormComponent";

const ModalForm = ({
  slug,
  page,
  type,
  show,
  onHide,
  formFields,
  initialFormData,
}) => {
  return (
    <Modal show={show} onHide={onHide} dialogClassName="large-modal">
      <Modal.Header closeButton>
        <h5>{page}</h5>
      </Modal.Header>
      <Modal.Body>
        <div className="px-0">
          <FormComponent
            slug={slug}
            type={type}
            addborder="custom-border"
            page={page}
            insideModel={true}
            initialFormData={initialFormData}
            formFields={formFields}
          />
        </div>
      </Modal.Body>
      {/* <Modal.Footer>
      <Button variant="primary light">Save changes</Button>
        <Button variant="danger light" onClick={onHide}>
          Submit
        </Button>
      </Modal.Footer> */}
    </Modal>
  );
};

export default ModalForm;
