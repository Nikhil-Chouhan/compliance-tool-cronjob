import React from "react";
import { Modal } from "react-bootstrap";
import FormComponent from "@/components/FormComponent";
import AgGridTableComponent from "@/components/AgGridTableComponent";

const ActivityModalFormComponent = ({
  slug,
  page,
  type,
  show,
  onHide,
  formFields,
  initialFormData,
}) => {
  const customColumns = [
    { headerName: "Client Activity ID", field: "client_id", islink: true },
    { headerName: "Legislation", field: "legislation" },
    { headerName: "Rule", field: "rule" },
    { headerName: "Reference", field: "reference" },
    { headerName: "Who", field: "who" },
    { headerName: "When", field: "when" },
    { headerName: "Activity", field: "activity" },
    { headerName: "Procedure", field: "procedure" },
    { headerName: "Impact", field: "impact" },
    { headerName: "Frequency", field: "frequency" },
    { headerName: "Legal Due date", field: "legal_due_date" },
    { headerName: "Executor Date", field: "executor_date" },
  ];

  const staticData = [
    {
      client_id: 1,
      legislation:
        "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013",
      rule: "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013",
      reference: "Section 19(b)",
      who: "Employer of a workplace",
      when: "On applicability of the Act",
      activity:
        "Display penal consequences of sexual harassment and the composition of the Internal Committee (IC) at a conspicuous place at the workplace",
      procedure: "NA",
      impact: "Moderate",
      frequency: "Monthly",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
    {
      client_id: 2,
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Minimum Wages (Tamil Nadu) Rules, 1953",
      reference: "Section 12",
      who: "Employer ",
      when: "On employing an employee in any scheduled employment",
      activity:
        "Pay minimum rates of wages at a rate not less than the minimum rates of wages fixed of any scheduled employment	",
      procedure: "NA",
      impact: "Major",
      frequency: "Ongoing",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
    {
      client_id: 3,
      legislation:
        "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013",
      rule: "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013",
      reference: "Section 19(b)",
      who: "Employer of a workplace",
      when: "On applicability of the Act",
      activity:
        "Display penal consequences of sexual harassment and the composition of the Internal Committee (IC) at a conspicuous place at the workplace",
      procedure: "NA",
      impact: "Moderate",
      frequency: "Monthly",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
    {
      client_id: 4,
      legislation:
        "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013",
      rule: "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013",
      reference: "Section 19(b)",
      who: "Employer of a workplace",
      when: "On applicability of the Act",
      activity:
        "Display penal consequences of sexual harassment and the composition of the Internal Committee (IC) at a conspicuous place at the workplace",
      procedure: "NA",
      impact: "Moderate",
      frequency: "Monthly",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
    {
      client_id: 6,
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Minimum Wages (Tamil Nadu) Rules, 1953",
      reference: "Section 12",
      who: "Employer ",
      when: "On employing an employee in any scheduled employment",
      activity:
        "Pay minimum rates of wages at a rate not less than the minimum rates of wages fixed of any scheduled employment	",
      procedure: "NA",
      impact: "Major",
      frequency: "Ongoing",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
    {
      client_id: 7,
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Minimum Wages (Tamil Nadu) Rules, 1953",
      reference: "Section 12",
      who: "Employer ",
      when: "On employing an employee in any scheduled employment",
      activity:
        "Pay minimum rates of wages at a rate not less than the minimum rates of wages fixed of any scheduled employment	",
      procedure: "NA",
      impact: "Major",
      frequency: "Ongoing",
      legal_due_date: "26-11-2023",
      executor_date: "18-11-2023",
    },
  ];

  return (
    <Modal show={show} onHide={onHide} dialogClassName="large-modal">
      <Modal.Header closeButton>
        <h5>{page}</h5>
      </Modal.Header>
      <Modal.Body>
        <div className="px-0">
          <FormComponent
            slug={slug}
            type={type}
            page={page}
            insideModel={true}
            addborder="custom-border"
            initialFormData={initialFormData}
            formFields={formFields}
          />
          <AgGridTableComponent
            checkBox={true}
            addborder="custom-border"
            page="Select Activity"
            customColumns={customColumns}
            customRows={staticData}
          />
        </div>
      </Modal.Body>
      {/* <Modal.Footer>
      <Button variant="primary light">Save changes</Button>
        <Button variant="danger light" onClick={onHide}>
          Submit
        </Button>
      </Modal.Footer> */}
    </Modal>
  );
};

export default ActivityModalFormComponent;
