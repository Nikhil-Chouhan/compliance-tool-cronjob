import React, { useState, useRef } from "react";
import Link from "next/link";
import { FaFilter, FaAngleDown, FaAngleUp } from "react-icons/fa";
import { BsHouse } from "react-icons/bs";
import LoadingOverlay from "@/components/LoadingOverlay";
import Toast, { ToastType } from "@/components/Toast_old";

export default function ExpandSearchComponent({
  showbreadCrumb,
  slug,
  page,
  formFields,
  advancedFormFields,
  buttonName,
  filterState,
  onButtonClick,
  previousPage,
  title,
}) {
  const [loading] = useState(false);
  const toastRef = useRef<ToastType>();
  filterState = filterState ?? false;
  const [showAdvancedFields, setShowAdvancedFields] = useState(false);
  const [showSearchComponent, setShowSearchComponent] = useState(filterState);

  const handleClick = () => {
    const responseData = true;
    onButtonClick(responseData);
  };

  const toggleAdvancedFields = () => {
    setShowAdvancedFields(!showAdvancedFields);
  };

  const toggleSearchComponent = () => {
    setShowSearchComponent(!showSearchComponent);
  };

  return (
    <>
      <main className="container-fluid">
        <div className="d-flex justify-content-between align-items-center">
          {showbreadCrumb && (
            <div className="d-flex justify-content-start align-items-center mb-2">
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb">
                  <Link href="/" className=" breadcrumb-item">
                    <BsHouse className="mb-1 mx-3" />
                  </Link>
                  <Link
                    href={slug}
                    className="text-decoration-none breadcrumb-item"
                  >
                    {previousPage}
                  </Link>
                  <li className="breadcrumb-item active" aria-current="page">
                    {title}
                  </li>
                </ol>
              </nav>
            </div>
          )}
        </div>
        <div className="row custom_row bg-white rounded-corner p-3">
          <div className="col-md-12 px-0">
            <div className="row justify-content-between align-items-center">
              <div className="col-md-8">
                <h6 className="text-muted m-0">
                  <FaFilter className="mb-1 mx-3 text-muted" />
                  {page}
                </h6>
              </div>
              <div className="col-md-1">
                <button
                  className="btn btn-none fw-strong"
                  onClick={toggleSearchComponent}
                >
                  {showSearchComponent ? (
                    <FaAngleUp
                      size={20}
                      className="mx-3 text-primary fw-bold"
                    />
                  ) : (
                    <FaAngleDown
                      size={20}
                      className="mx-3 text-primary fw-bold"
                    />
                  )}
                </button>
              </div>
            </div>

            {showSearchComponent && <hr></hr>}
          </div>

          {showSearchComponent && (
            <div className="row search_component_main">
              {formFields.map((field, index) => (
                <div
                  key={index}
                  className={
                    field.large === true ? "col-md-12 mb-3" : "col-md-4 mb-3"
                  }
                >
                  <label htmlFor={field.name} className="form-label text-muted">
                    {field.label.includes("\n") && <br />}
                    {field.label}{" "}
                    {field.required && <span className="text-danger">*</span>}
                  </label>
                  {field.type === "select" ? (
                    <select
                      className="form-select form-control input-padding"
                      id={field.name}
                      name={field.name}
                      // value={formData[field.name]}
                      required={field.required}
                      disabled={field.disabled}
                    >
                      <option value="" selected disabled>
                        Select {field.label}
                      </option>
                      {field.options.map((option) => (
                        <option key={option.value} value={option.value}>
                          {option.label}
                        </option>
                      ))}
                    </select>
                  ) : field.type === "textarea" ? (
                    <textarea
                      className="form-control input-padding"
                      id={field.name}
                      name={field.name}
                      rows="1"
                      cols="50"
                      required={field.required}
                      disabled={field.disabled}
                    />
                  ) : (
                    <input
                      type={field.type}
                      className={
                        field.name === "date"
                          ? "form-control input-padding"
                          : "form-control datecss input-padding"
                      }
                      id={field.name}
                      name={field.name}
                      required={field.required}
                      disabled={field.disabled}
                    />
                  )}
                </div>
              ))}

              {showAdvancedFields ? (
                <div className="row">
                  {advancedFormFields.map((field, index) => (
                    <div key={index} className="col-md-4 mb-3">
                      <label
                        htmlFor={field.name}
                        className="form-label text-muted"
                      >
                        {field.label}{" "}
                        {field.required && (
                          <span className="text-danger">*</span>
                        )}
                      </label>
                      {field.type === "select" ? (
                        <select
                          className=" form-select form-control input-padding"
                          id={field.name}
                          name={field.name}
                          required={field.required}
                          disabled={field.disabled}
                        >
                          <option value="" selected disabled>
                            Select {field.label}
                          </option>
                          {field.options.map((option) => (
                            <option key={option.value} value={option.value}>
                              {option.label}
                            </option>
                          ))}
                        </select>
                      ) : field.type === "textarea" ? (
                        <textarea
                          className="form-control input-padding"
                          id={field.name}
                          name={field.name}
                          rows="4"
                          cols="50"
                          required={field.required}
                          disabled={field.disabled}
                        />
                      ) : (
                        <input
                          type={field.type}
                          className={
                            field.name === "date"
                              ? "form-control input-padding"
                              : "form-control datecss input-padding"
                          }
                          id={field.name}
                          name={field.name}
                          required={field.required}
                          disabled={field.disabled}
                        />
                      )}
                    </div>
                  ))}
                </div>
              ) : (
                <div></div>
              )}

              {advancedFormFields ? (
                <div>
                  <div className=" text-end">
                    <button
                      onClick={handleClick}
                      className="btn light btn-primary mx-1"
                    >
                      {buttonName ? buttonName : "Search"}
                    </button>
                    <button
                      type="button"
                      className="btn btn-info light mx-1"
                      onClick={toggleAdvancedFields}
                    >
                      {showAdvancedFields
                        ? "Collapse Advanced Search"
                        : "Advanced Search"}
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <div>
                    <div className=" text-end">
                      <button
                        onClick={handleClick}
                        type="submit"
                        className="btn light btn-primary mx-1"
                      >
                        {buttonName ? buttonName : "Search"}
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          )}
        </div>

        <LoadingOverlay isLoading={loading} />
        <Toast ref={toastRef} />
      </main>
    </>
  );
}
