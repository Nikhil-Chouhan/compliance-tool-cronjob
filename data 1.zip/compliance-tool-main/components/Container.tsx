"use client";

import { usePathname } from "next/navigation";
import Sidebar from "@/components/Sidebar";
import { useAtom } from "jotai";
import { sidebarAtom } from "@/atoms/sidebar";
import Navbar from "@/components/Navbar";

export default function Container({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  let isLoggedIn = true;

  if (pathname.includes("/login")) {
    isLoggedIn = false;
  }
  const [sidebarShown] = useAtom(sidebarAtom);
  console.log(sidebarShown);

  return (
    <>
      {isLoggedIn ? (
        <>
          <Navbar />
          <div className="justify-content-center">
            <div
              className={`row custom_row vh-100 ${
                sidebarShown ? "" : "sidebar-hidden"
              }`}
            >
              <div className={`col-md-${sidebarShown ? "2" : "1"} px-0`}>
                <Sidebar />
              </div>
              <div className={`col-md-${sidebarShown ? "10" : "11"} px-0 `}>
               <div className="p-4">{children}</div> 
              </div>
            </div>
          </div>
        </>
      ) : (
        <>
          <div className="custom_row row">
            <div className="col-md-12 px-0">{children}</div>
          </div>
        </>
      )}
    </>
  );
}
