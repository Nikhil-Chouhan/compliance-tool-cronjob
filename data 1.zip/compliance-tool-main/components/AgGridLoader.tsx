export default function AgGridLoader() {
  return (
    <div className="aggrid-loading-overlay">
      <div className="aggrid-loading-spinner"></div>
    </div>
  );
}
