import React, { useState } from "react";
import { Modal, Button, Nav } from "react-bootstrap";
import AgGridTableComponent from "@/components/AgGridTableComponent";
import ActivityModalForm from "@/components/ActivityModalFormComponent";
const CalenderPopup = ({ show, onHide }) => {
  const [activePage, setActivePage] = useState("activityDetails");

  const [showModal, setShowModal] = useState(false);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };

  const handlePageChange = (page) => {
    setActivePage(page);
  };

  const dataOrganogram = [
    { id: "Unit Activity ID", value: "D30400001717" },
    { id: "Entity", value: "Demo Entity Pvt Ltd" },
    { id: "Unit", value: "Corporate Office - Mumbai" },
    { id: "Function", value: "Secretarial" },
    { id: "Executor", value: "reguCheck user" },
    { id: "Evaluator", value: "reguCheck user" },
    { id: "Function Head", value: "reguCheck user" },
  ];

  const dataActivity = [
    {
      id: "Legislation",
      value: "The Central Goods and Services Tax Act, 2017",
    },
    { id: "Rule ", value: "The Central Goods and Services Tax Rules, 2017" },
    { id: "Reference ", value: "Rule 6(3)" },
    { id: "Who ", value: "Registered Person" },
    {
      id: "When ",
      value: "In case intends to withdraw from the composition scheme",
    },
    {
      id: "Compliance Activity ",
      value:
        "File an application in Form GST CMP-04, duly signed or verified through EVC, electronically on the Common Portal.",
    },
    { id: "Procedure ", value: "NA" },
    { id: "More Information ", value: "NA" },
    { id: "Prohibitive / Prescriptive ", value: "Prescriptive" },
    { id: "Frequency ", value: "Quarterly" },
    { id: "Form No ", value: "Form GST CMP-04" },
    { id: "Due date ", value: "NA" },
    { id: "Specific due date ", value: "NA" },
    { id: "Type of Activity ", value: "Submission" },
    { id: "Responsibility  ", value: "NA" },
    { id: "Corporate Level or Unit Level  ", value: "Corporate Level" },
    { id: "Exemption Criteria ", value: "NA" },
    { id: "Events  ", value: "NA" },
    { id: "Sub Event ", value: "NA" },
    {
      id: "Implications  ",
      value: "Penalty up to twenty-five thousand rupees ",
    },
    { id: "Imprisonment Duration ", value: "NA" },
    { id: "Imprisonment Applies to ", value: "NA" },
    { id: "Fine amount  ", value: " 25000" },
    { id: "Subsequent Amount per Day ", value: "0" },
    { id: "Impact  ", value: "Moderate" },
    { id: "Impact on Unit ", value: "Moderate" },
    { id: "Impact on organization ", value: "Low" },
    { id: "Interlinkage ", value: "NA" },
    { id: "Linked Activity ID ", value: "NA" },
    { id: "Weblink ", value: "NA" },
    { id: "ReguCheck Activity ID ", value: "T0022166" },
  ];
  const customColumns = [
    { headerName: "Executor", field: "executor" },
    { headerName: "Executor Date", field: "executor_date" },
    { headerName: "Evaluator Date", field: "evaluator_date" },
    { headerName: "Function Head Date", field: "function_head_date" },
    { headerName: "Unit Head Date", field: "unit_head_date" },
    { headerName: "Legal Date", field: "legal_date" },
    { headerName: "Edit Date", field: "edit_date" },
    { headerName: "Completed By", field: "completed_by" },
    { headerName: "Completed On", field: "completed_on" },
    { headerName: "Comments", field: "comments" },
    { headerName: "Activity Status", field: "activity_status" },
    { headerName: "Legal Activity Status", field: "legal_activity_status" },
    { headerName: "Document", field: "document" },
  ];

  const customRows = [
    {
      executor: "JFW Executor",
      executor_date: "18-01-2024",
      evaluator_date: "21-01-2024",
      function_head_date: "24-01-2024",
      unit_head_date: "27-01-2024",
      legal_date: "30-01-2024",
      edit_date: "none",
      completed_by: "Vishal",
      completed_on: "2-02-2024",
      comments: "",
      activity_status: "Active",
      legal_activity_status: "Pending",
      document: "",
    },
  ];

  const formFields_2 = [
    {
      label: "Completion Date",
      name: "completion_date",
      type: "date",
      required: false,
    },
    {
      label: "Remarks: ",
      name: "remarks",
      type: "text",
      required: false,
    },
    {
      label: "Upload proof of Compliance",
      name: "document",
      type: "file",
      required: false,
    },
  ];

  return (
    <Modal show={show} onHide={onHide} dialogClassName="large-modal">
      <Modal.Header closeButton>
        <h5>{"Activity Details"}</h5>
      </Modal.Header>
      <Modal.Body>
        <Nav variant="tabs" defaultActiveKey="activityDetails">
          <Nav.Item>
            <Nav.Link
              eventKey="activityDetails"
              onClick={() => handlePageChange("activityDetails")}
            >
              Activity Details
            </Nav.Link>
          </Nav.Item>
          <Nav.Item>
            <Nav.Link
              eventKey="activityHistory"
              onClick={() => handlePageChange("activityHistory")}
            >
              Activity History
            </Nav.Link>
          </Nav.Item>
        </Nav>
        {/* {event ? ( */}
        <>
          {activePage === "activityDetails" && (
            <>
              <div className="card mt-3 p-2">
                <div className="card-body ">
                  <h5 className="card-title mb-3">Organogram Information</h5>
                  <hr></hr>
                  {dataOrganogram.map((item, index) => (
                    <div className="row mb-1" key={index}>
                      <div className="col-md-4">
                        <p
                          className={`bg-${
                            index % 2 === 0 ? "white" : "light-blue"
                          } rounded mb-2 p-2`}
                        >
                          {item.id}:
                        </p>
                      </div>
                      <div className="col-md-8">
                        <p
                          className={`bg-${
                            index % 2 === 0 ? "white" : "light-blue"
                          } rounded mb-2 p-2`}
                        >
                          {item.value}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="card-body">
                  <h5 className="card-title mb-3">Activity Details</h5>
                  <hr></hr>
                  {dataActivity.map((item, index) => (
                    <div className="row mb-1" key={index}>
                      <div className="col-md-4">
                        <p
                          className={`bg-${
                            index % 2 === 0 ? "white" : "light-blue"
                          } mb-2 p-2`}
                        >
                          {item.id}:
                        </p>
                      </div>
                      <div className="col-md-8">
                        <p
                          className={`bg-${
                            index % 2 === 0 ? "white" : "light-blue"
                          } mb-2 p-2`}
                        >
                          {item.value}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </>
          )}
          {activePage === "activityHistory" && (
            <>
              <div className="card mt-3">
                <AgGridTableComponent
                  slug="/activity-mapping/assign-activity"
                  aggridPadding="p-0"
                  page="Activity History"
                  actionBtn={false}
                  edit="Complete"
                  customColumns={customColumns}
                  customRows={customRows}
                  onButtonClick={openModal}
                />
                <ActivityModalForm
                  slug="/repository"
                  page="Activity Completion:"
                  type="Submit"
                  show={showModal}
                  onHide={closeModal}
                  formFields={formFields_2}
                />
              </div>
            </>
          )}
        </>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="danger light" onClick={onHide}>
          Close
        </Button>
      </Modal.Footer>
    </Modal>
  );
};

export default CalenderPopup;
