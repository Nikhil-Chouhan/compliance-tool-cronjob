import * as z from "zod"

export const activity_mappingModel = z.object({
  id: z.number().int().nullish(),
  uuid: z.string().nullish(),
  unit_activity_id: z.number().int(),
  entity_id: z.number().int(),
  unit_id: z.number().int(),
  function_id: z.number().int(),
  executor_id: z.number().int(),
  evaluator_id: z.number().int(),
  function_head_id: z.number().int(),
  status: z.number().int().nullish(),
  created_at: z.date().nullish(),
  updated_at: z.date().nullish(),
  deleted_at: z.date().nullish(),
  deleted: z.boolean().nullish(),
})
