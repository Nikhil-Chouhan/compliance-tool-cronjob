import * as z from "zod"

export const entityModel = z.object({
  id: z.number().int().nullish(),
  uuid: z.string().nullish(),
  organisation_id: z.number().int(),
  name: z.string(),
  status: z.number().int().nullish(),
  created_at: z.date().nullish(),
  updated_at: z.date().nullish(),
  deleted_at: z.date().nullish(),
  deleted: z.boolean().nullish(),
})
