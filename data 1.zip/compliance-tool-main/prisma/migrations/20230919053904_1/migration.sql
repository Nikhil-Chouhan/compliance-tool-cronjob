-- CreateEnum
CREATE TYPE "designation" AS ENUM ('Director', 'Head - Legal Updates', 'Head - CRS', 'Head - Implementation', 'TeamLeader', 'Associate - CRS', 'Associate - Implementation');

-- CreateEnum
CREATE TYPE "law_category" AS ENUM ('Corporate Laws', 'Commercial Laws', 'Human Resources & Labour Laws', 'Environment Health & Safety Laws', 'Regulatory Laws', 'Direct Taxation Laws', 'Indirect Taxation Laws', 'Information Technology Laws', 'Intellectual Property Laws', 'Import & Export Laws', 'Local Laws', 'Conditions of Licenses/Consents', 'Cross Border Laws', 'Anti-bribery Laws', 'Internal Compliances', 'Contractual Compliances', 'Product Compliances', 'Transactional Compliances');

-- CreateEnum
CREATE TYPE "frequency" AS ENUM ('Onetime', 'Ongoing', 'event based', '10 yearly', '8 yearly', '5 yearly', '4 yearly', '3 yearly', '2 yearly', 'yearly', '10 monthly', '4 monthly', 'Half yearly', 'Quarterly', 'Bi-monthly', 'Monthly', 'Fortnightly', 'Weekly', 'event');

-- CreateEnum
CREATE TYPE "impact" AS ENUM ('Super Critical', 'Critical', 'High', 'Moderate', 'Low');

-- CreateEnum
CREATE TYPE "applies" AS ENUM ('Company', 'Product', 'Individual');

-- CreateEnum
CREATE TYPE "imprisonment_for" AS ENUM ('Managing Director', 'Managerial Person', 'General Manager', 'Occupier', 'Manager', 'Principal Employer', 'Employer', 'Contractor', 'Owner', 'Officer in default');

-- CreateTable
CREATE TABLE "role" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,

    CONSTRAINT "role_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "permission" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "uuid" TEXT,

    CONSTRAINT "permission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "role_permission" (
    "id" SERIAL NOT NULL,
    "role_id" INTEGER,
    "permission_id" INTEGER,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "uuid" TEXT,

    CONSTRAINT "role_permission_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user" (
    "id" SERIAL NOT NULL,
    "employee_id" TEXT NOT NULL,
    "first_name" TEXT NOT NULL,
    "middle_name" TEXT,
    "last_name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "mobile_no" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "role_id" INTEGER NOT NULL,
    "entity_id" INTEGER NOT NULL,
    "location_id" INTEGER NOT NULL,
    "function_id" INTEGER NOT NULL,
    "designation" "designation" NOT NULL,
    "address1" TEXT NOT NULL,
    "zipcode" TEXT NOT NULL,
    "country_id" INTEGER NOT NULL,
    "state_id" INTEGER NOT NULL,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "password_changed_at" TIMESTAMP(3),
    "uuid" TEXT,

    CONSTRAINT "user_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "user_otp" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER NOT NULL,
    "otp" TEXT NOT NULL,

    CONSTRAINT "user_otp_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "profile" (
    "id" SERIAL NOT NULL,
    "user_id" INTEGER,
    "language_id" INTEGER,
    "theme" TEXT,
    "timezone" TEXT,
    "photo_path" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "uuid" TEXT,

    CONSTRAINT "profile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "entity" (
    "id" SERIAL NOT NULL,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "entity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "location" (
    "id" SERIAL NOT NULL,
    "entity_id" INTEGER,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(3),
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,

    CONSTRAINT "location_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "function_department" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "function_department_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "country" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "name" TEXT NOT NULL,
    "short_name" TEXT NOT NULL,
    "country_code" TEXT,
    "timezone" TEXT,
    "uts_offset" TEXT,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "country_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "state" (
    "id" SERIAL NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "country_id" INTEGER,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "state_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "industry" (
    "id" SERIAL NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "industry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "language" (
    "id" SERIAL NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "language_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "compliance_type" (
    "id" SERIAL NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "compliance_type_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event" (
    "id" SERIAL NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "event_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_sub" (
    "id" SERIAL NOT NULL,
    "event_id" INTEGER NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "event_sub_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "event_question" (
    "id" SERIAL NOT NULL,
    "event_id" INTEGER NOT NULL,
    "event_sub_id" INTEGER NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "uuid" TEXT,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "event_question_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "legislation" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "country_id" INTEGER NOT NULL,
    "is_federal" BOOLEAN NOT NULL DEFAULT false,
    "state_id" INTEGER,
    "law_category" "law_category" NOT NULL,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "sources" TEXT,
    "effective_date" TIMESTAMP(3),
    "updated_date" TIMESTAMP(3),
    "documents" TEXT,
    "industry_id" INTEGER,
    "applies_to" "applies" NOT NULL,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "legislation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "rule" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "legislation_id" INTEGER,
    "code" TEXT,
    "name" TEXT NOT NULL,
    "applicability" TEXT,
    "sources" TEXT,
    "effective_date" TIMESTAMP(3),
    "updated_date" TIMESTAMP(3),
    "documents" TEXT NOT NULL,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "rule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "compliance_activity" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "legislation_id" INTEGER,
    "rule_id" INTEGER,
    "code" TEXT,
    "title" TEXT NOT NULL,
    "activity" TEXT NOT NULL,
    "reference" TEXT,
    "who" TEXT,
    "when" TEXT,
    "procedure" TEXT,
    "description" TEXT,
    "frequency" "frequency",
    "form_no" TEXT,
    "due_date" TIMESTAMP(3),
    "compliance_type" TEXT,
    "authority" TEXT,
    "exemption_criteria" TEXT,
    "event_id" INTEGER,
    "event_sub_id" INTEGER,
    "event_question_id" INTEGER,
    "implications" TEXT,
    "imprison_duration" TEXT,
    "imprison_applies_to" "imprisonment_for",
    "currency" TEXT,
    "fine" TEXT,
    "fine_per_day" TEXT,
    "impact" "impact",
    "impact_on_unit" TEXT,
    "impact_on_organization" TEXT,
    "linked_activity_ids" TEXT,
    "reference_link" TEXT,
    "sources" TEXT,
    "updated_date" TIMESTAMP(3),
    "documents" TEXT,
    "status" INTEGER DEFAULT 1,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "compliance_activity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "download" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "country_id" INTEGER,
    "state_id" INTEGER,
    "law_category" "law_category" NOT NULL,
    "legislation_id" INTEGER,
    "rule_id" INTEGER,
    "reason" TEXT,
    "approval_status" INTEGER DEFAULT 0,
    "approvet_at" TIMESTAMP(3),
    "approved_by" INTEGER,
    "status" INTEGER DEFAULT 1,
    "user_id" INTEGER,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),

    CONSTRAINT "download_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "download_activity" (
    "id" SERIAL NOT NULL,
    "compliance_activity_id" INTEGER,
    "download_id" INTEGER,

    CONSTRAINT "download_activity_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "action_log" (
    "id" SERIAL NOT NULL,
    "uuid" TEXT,
    "action_name" TEXT NOT NULL,
    "model_name" TEXT NOT NULL,
    "request_data" JSONB,
    "status" INTEGER DEFAULT 1,
    "ip_address" TEXT NOT NULL,
    "created_at" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "deleted_at" TIMESTAMP(3),
    "deleted" BOOLEAN DEFAULT false,
    "updated_at" TIMESTAMP(3),
    "user_id" INTEGER,
    "record_id" INTEGER,

    CONSTRAINT "action_log_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "role_uuid_key" ON "role"("uuid");

-- CreateIndex
CREATE INDEX "role_name_status_idx" ON "role"("name", "status");

-- CreateIndex
CREATE UNIQUE INDEX "role_name_deleted_deleted_at_key" ON "role"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "permission_uuid_key" ON "permission"("uuid");

-- CreateIndex
CREATE INDEX "permission_name_status_idx" ON "permission"("name", "status");

-- CreateIndex
CREATE UNIQUE INDEX "permission_name_deleted_deleted_at_key" ON "permission"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "role_permission_uuid_key" ON "role_permission"("uuid");

-- CreateIndex
CREATE INDEX "role_permission_role_id_permission_id_idx" ON "role_permission"("role_id", "permission_id");

-- CreateIndex
CREATE UNIQUE INDEX "user_email_key" ON "user"("email");

-- CreateIndex
CREATE UNIQUE INDEX "user_mobile_no_key" ON "user"("mobile_no");

-- CreateIndex
CREATE UNIQUE INDEX "user_uuid_key" ON "user"("uuid");

-- CreateIndex
CREATE INDEX "user_email_mobile_no_idx" ON "user"("email", "mobile_no");

-- CreateIndex
CREATE UNIQUE INDEX "user_email_mobile_no_deleted_deleted_at_key" ON "user"("email", "mobile_no", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "profile_user_id_key" ON "profile"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "profile_uuid_key" ON "profile"("uuid");

-- CreateIndex
CREATE INDEX "profile_timezone_idx" ON "profile"("timezone");

-- CreateIndex
CREATE UNIQUE INDEX "entity_uuid_key" ON "entity"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "entity_name_deleted_deleted_at_key" ON "entity"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "location_uuid_key" ON "location"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "location_name_deleted_deleted_at_key" ON "location"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "function_department_uuid_key" ON "function_department"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "function_department_name_deleted_deleted_at_key" ON "function_department"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "country_uuid_key" ON "country"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "country_short_name_key" ON "country"("short_name");

-- CreateIndex
CREATE UNIQUE INDEX "country_name_deleted_deleted_at_key" ON "country"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "state_code_key" ON "state"("code");

-- CreateIndex
CREATE UNIQUE INDEX "state_uuid_key" ON "state"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "state_name_deleted_deleted_at_key" ON "state"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "industry_code_key" ON "industry"("code");

-- CreateIndex
CREATE UNIQUE INDEX "industry_uuid_key" ON "industry"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "industry_name_deleted_deleted_at_key" ON "industry"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "language_code_key" ON "language"("code");

-- CreateIndex
CREATE UNIQUE INDEX "language_uuid_key" ON "language"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "language_name_deleted_deleted_at_key" ON "language"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_type_code_key" ON "compliance_type"("code");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_type_uuid_key" ON "compliance_type"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_type_name_deleted_deleted_at_key" ON "compliance_type"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "event_code_key" ON "event"("code");

-- CreateIndex
CREATE UNIQUE INDEX "event_uuid_key" ON "event"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "event_name_deleted_deleted_at_key" ON "event"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "event_sub_code_key" ON "event_sub"("code");

-- CreateIndex
CREATE UNIQUE INDEX "event_sub_uuid_key" ON "event_sub"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "event_sub_name_deleted_deleted_at_key" ON "event_sub"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "event_question_code_key" ON "event_question"("code");

-- CreateIndex
CREATE UNIQUE INDEX "event_question_uuid_key" ON "event_question"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "event_question_name_deleted_deleted_at_key" ON "event_question"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "legislation_uuid_key" ON "legislation"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "legislation_code_key" ON "legislation"("code");

-- CreateIndex
CREATE UNIQUE INDEX "legislation_name_deleted_deleted_at_key" ON "legislation"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "rule_uuid_key" ON "rule"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "rule_code_key" ON "rule"("code");

-- CreateIndex
CREATE UNIQUE INDEX "rule_name_deleted_deleted_at_key" ON "rule"("name", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_activity_uuid_key" ON "compliance_activity"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_activity_code_key" ON "compliance_activity"("code");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_activity_title_key" ON "compliance_activity"("title");

-- CreateIndex
CREATE UNIQUE INDEX "compliance_activity_title_deleted_deleted_at_key" ON "compliance_activity"("title", "deleted", "deleted_at");

-- CreateIndex
CREATE UNIQUE INDEX "download_uuid_key" ON "download"("uuid");

-- CreateIndex
CREATE UNIQUE INDEX "action_log_uuid_key" ON "action_log"("uuid");

-- AddForeignKey
ALTER TABLE "role_permission" ADD CONSTRAINT "role_permission_permission_id_fkey" FOREIGN KEY ("permission_id") REFERENCES "permission"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "role_permission" ADD CONSTRAINT "role_permission_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_country_id_fkey" FOREIGN KEY ("country_id") REFERENCES "country"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_entity_id_fkey" FOREIGN KEY ("entity_id") REFERENCES "entity"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_function_id_fkey" FOREIGN KEY ("function_id") REFERENCES "function_department"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_location_id_fkey" FOREIGN KEY ("location_id") REFERENCES "location"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_role_id_fkey" FOREIGN KEY ("role_id") REFERENCES "role"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user" ADD CONSTRAINT "user_state_id_fkey" FOREIGN KEY ("state_id") REFERENCES "state"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "user_otp" ADD CONSTRAINT "user_otp_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "profile" ADD CONSTRAINT "profile_language_id_fkey" FOREIGN KEY ("language_id") REFERENCES "language"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "profile" ADD CONSTRAINT "profile_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "location" ADD CONSTRAINT "location_entity_id_fkey" FOREIGN KEY ("entity_id") REFERENCES "entity"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "state" ADD CONSTRAINT "state_country_id_fkey" FOREIGN KEY ("country_id") REFERENCES "country"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_sub" ADD CONSTRAINT "event_sub_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_question" ADD CONSTRAINT "event_question_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "event"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "event_question" ADD CONSTRAINT "event_question_event_sub_id_fkey" FOREIGN KEY ("event_sub_id") REFERENCES "event_sub"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "legislation" ADD CONSTRAINT "legislation_country_id_fkey" FOREIGN KEY ("country_id") REFERENCES "country"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "legislation" ADD CONSTRAINT "legislation_industry_id_fkey" FOREIGN KEY ("industry_id") REFERENCES "industry"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "legislation" ADD CONSTRAINT "legislation_state_id_fkey" FOREIGN KEY ("state_id") REFERENCES "state"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "rule" ADD CONSTRAINT "rule_legislation_id_fkey" FOREIGN KEY ("legislation_id") REFERENCES "legislation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_activity" ADD CONSTRAINT "compliance_activity_event_id_fkey" FOREIGN KEY ("event_id") REFERENCES "event"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_activity" ADD CONSTRAINT "compliance_activity_event_question_id_fkey" FOREIGN KEY ("event_question_id") REFERENCES "event_question"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_activity" ADD CONSTRAINT "compliance_activity_event_sub_id_fkey" FOREIGN KEY ("event_sub_id") REFERENCES "event_sub"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_activity" ADD CONSTRAINT "compliance_activity_legislation_id_fkey" FOREIGN KEY ("legislation_id") REFERENCES "legislation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "compliance_activity" ADD CONSTRAINT "compliance_activity_rule_id_fkey" FOREIGN KEY ("rule_id") REFERENCES "rule"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_approved_by_fkey" FOREIGN KEY ("approved_by") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_country_id_fkey" FOREIGN KEY ("country_id") REFERENCES "country"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_legislation_id_fkey" FOREIGN KEY ("legislation_id") REFERENCES "legislation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_rule_id_fkey" FOREIGN KEY ("rule_id") REFERENCES "rule"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_state_id_fkey" FOREIGN KEY ("state_id") REFERENCES "state"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download" ADD CONSTRAINT "download_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download_activity" ADD CONSTRAINT "download_activity_compliance_activity_id_fkey" FOREIGN KEY ("compliance_activity_id") REFERENCES "compliance_activity"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "download_activity" ADD CONSTRAINT "download_activity_download_id_fkey" FOREIGN KEY ("download_id") REFERENCES "download"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "action_log" ADD CONSTRAINT "user_action_log" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE SET NULL ON UPDATE SET NULL;

-- AddForeignKey
ALTER TABLE "action_log" ADD CONSTRAINT "role_action_log" FOREIGN KEY ("record_id") REFERENCES "role"("id") ON DELETE SET NULL ON UPDATE SET NULL;
