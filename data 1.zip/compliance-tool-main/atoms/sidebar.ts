import { atom } from "jotai";

export const sidebarAtom = atom(true);
