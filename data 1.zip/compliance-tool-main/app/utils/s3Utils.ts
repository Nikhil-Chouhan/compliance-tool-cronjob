import { PutObjectCommand, GetObjectCommand } from "@aws-sdk/client-s3";
import { StreamingBlobPayloadInputTypes } from "@smithy/types";
import { S3Client } from "@aws-sdk/client-s3";

const REGION = "ap-south-1";

const client = new S3Client({ region: REGION });

const upload = async (Bucket: string, Key: string, Body: unknown) => {
  const body = Body as StreamingBlobPayloadInputTypes;
  const params = { Bucket, Key, Body: body };

  return await client.send(new PutObjectCommand(params));
};

const download = async (Bucket: string, Key: string) => {
  const params = { Bucket, Key };

  const result = await client.send(new GetObjectCommand(params));
  if (!result.Body) return "";
  return await result.Body.transformToString();
};

export { upload, download };
