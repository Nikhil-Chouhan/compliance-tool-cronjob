"use client";

import React, { useState, useRef, useCallback } from "react";
import ExpandSearchComponent from "@/components/ExpandSearchComponent";
import AgGridTableComponent from "@/components/AgGridTableComponent";
import FormComponent from "@/components/FormComponent";

import { law_category } from "@/app/utils/modelUtils";

export default function ActivityConfiguration() {
  const [showDiv, setShowDiv] = useState(false);
  const gridApiRef = useRef(null);

  const customColumns = [
    { headerName: "Activity ID", field: "activity_id" },
    { headerName: "ReguCheck Activity ID", field: "regucheck_activity_id" },
    { headerName: "Name of Legislation", field: "legislation" },
    { headerName: "Rule", field: "rule" },
    { headerName: "Reference", field: "reference" },
    { headerName: "Who", field: "who" },
    { headerName: "When", field: "when" },
    { headerName: "Activity", field: "activity" },
    { headerName: "Frequency", field: "frequency" },
    { headerName: "Impact", field: "impact" },
    { headerName: "Impact", field: "unit_impact" },
    { headerName: "Impact", field: "entity_impact" },
  ];

  const staticData = [
    {
      activity_id: "D07100000970",
      regucheck_activity_id: "C0005819",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(1)",
      who: "Company",
      when: "	On applicability of the Act",
      activity:
        "Prepare and keep books of account, other relevant books and papers, financial statement for every financial year which give a true and fair view of the state of the affairs of the Company at its registered office",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D07100000943",
      regucheck_activity_id: "C0005821",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(1) and Rule 3",
      who: "Company",
      when: "In case books of accounts are maintained in electronic form",
      activity:
        "Ensure that Company is complying with all the provisions as mentioned in the more information column",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D071000009764",
      regucheck_activity_id: "C0005823",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(3)",
      who: "Company",
      when: "	If books of account, other books and papers maintained by the Company within India",
      activity:
        "Ensure to keep open all books of accounts, other books and papers for inspection for any director at the registered office of the Company or at such other place in India during business hours",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D07100000934",
      regucheck_activity_id: "C0005825",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Reference",
      who: "Company",
      when: "Someone",
      activity: "Activity",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D071000009215",
      regucheck_activity_id: "C00058123",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(5)",
      who: "Company",
      when: "In case of period of not less than eight financial years immediately preceding a financial year, or where the company had been in existence for a period less than eight years",
      activity:
        "Maintain books of accounts in respect of all the preceding years together with the vouchers relevant to any entry in such books of account in good order",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D07100000964",
      regucheck_activity_id: "C0005826",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(1) and Rule 3",
      who: "Company",
      when: "In case books of accounts are maintained in electronic form",
      activity:
        "Ensure that Company is complying with all the provisions as mentioned in the more information column",
      frequency: "Ongoing",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D07100000925",
      regucheck_activity_id: "C0005827",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 137(1) and Rule 12",
      who: "Company",
      when: "After financial statements are duly adopted at the annual general meeting",
      activity:
        "File the financial statements with Registrar together with Form AOC-4 and the consolidated financial statements, if any, with form AOC-4 CFS within 30 days of the date of Annual General Meeting",
      frequency: "Yearly",
      impact: "Low",
      unit_impact: "Low",
      entity_impact: "Low",
    },
    {
      activity_id: "D07100000974",
      regucheck_activity_id: "C0005812",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(1) and Rule 3(6)",
      who: "Company",
      when: "In case books of accounts are maintained in electronic mode",
      activity:
        "Intimate to the Registrar on an annual basis at the time of filing of financial statement:- (a) the name of the service provider; (b) the internet protocol address of service provider; (c) the location of the service provider (wherever applicable); (d) where the books of account and other books and papers are maintained on cloud, such address as provided by the service provider",
      frequency: "Yearly",
      impact: "Major",
      unit_impact: "Major",
      entity_impact: "Major",
    },
    {
      activity_id: "D071000009245",
      regucheck_activity_id: "C0005811",
      legislation: "The Companies Act, 2013",
      rule: "The Companies (Accounts) Rules, 2014",
      reference: "Section 128(1)",
      who: "Company",
      when: "	On applicability of the Act",
      activity:
        "Prepare and keep books of account, other relevant books and papers, financial statement for every financial year which give a true and fair view of the state of the affairs of the Company at its registered office",
      frequency: "Monthly",
      impact: "Low",
      unit_impact: "Major",
      entity_impact: "Low",
    },
  ];

  const formFields = [
    {
      label: "Country ",
      name: "countryy_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "India" },
        { value: 2, label: "Pakistan " },
        { value: 3, label: "Nepal" },
        { value: 4, label: "Sri Lanka" },
      ],
    },
    {
      label: "Is Federal ",
      name: "is_federal",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "State ",
      name: "state",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Maharashtra" },
        { value: 2, label: "Uttar Pradesh " },
        { value: 3, label: "Gujrat" },
        { value: 4, label: "Madhya Pradesh" },
      ],
    },
    {
      label: "Category of Law ",
      name: "category_of_law",
      type: "select",

      required: false,
      options: Object.keys(law_category).map((key) => ({
        value: key,
        label: law_category[key],
      })),
    },
    {
      label: "Legislation ",
      name: "legislation",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "The Companies Act, 2013" },
        { value: 2, label: "The Payment of Bonus Act,1965" },
        {
          value: 3,
          label:
            "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013",
        },
        { value: 4, label: "The Central Goods and Services Tax Act, 2017" },
        { value: 5, label: "The Income Tax Act, 1961" },
        { value: 6, label: "GGL Internal Compliances" },
      ],
    },
    {
      label: "Rule ",
      name: "rule",
      type: "select",

      required: false,
      options: [
        {
          value: 1,
          label: "The Companies (Meetings of Board and its Powers) Rules, 2014",
        },
        { value: 2, label: "The Payment of Bonus Rules, 1975" },
        {
          value: 3,
          label:
            "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013",
        },
        { value: 4, label: "The Central Goods and Services Tax Rules, 2017" },
        { value: 5, label: "The Income Tax Rules, 1962" },
        {
          value: 6,
          label: "The Customs (Provisional Duty Assessment) Regulations, 2011",
        },
      ],
    },
    {
      label: "Entity ",
      name: "entity_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
      ],
    },
    {
      label: "Unit ",
      name: "unit",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Cooporate Office - Mumbai" },
        { value: 2, label: "Registered Office - Pune" },
      ],
    },
    {
      label: "Function ",
      name: "function",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Maintenance" },
        { value: 1, label: "MHuman Resource" },
      ],
    },
    {
      label: "Executor ",
      name: "executor",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Regucheck User" },
        { value: 2, label: "Executor Person2" },
        { value: 2, label: "Executor Person3" },
      ],
    },
    {
      label: "Evaluator ",
      name: "evaluator",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Regucheck User" },
        { value: 2, label: "Evaluator Person2" },
        { value: 2, label: "Evaluator Person3" },
      ],
    },
  ];
  const initialconfigFormData = {
    impact_on_entity: null,
    impact_on_unit: null,
    impact: null,
    document: null,
    historical: null,
    frequency: null,
    due_date_buffer: null,
  };
  const configformFields = [
    {
      label: "Impact On Entity ",
      name: "impact_on_entity",
      type: "select",
      required: false,
      options: [
        { value: 1, label: "Severe" },
        { value: 2, label: "Major" },
        { value: 3, label: "Moderate" },
        { value: 4, label: "Low" },
      ],
    },
    {
      label: "Impact On Unit ",
      name: "impact_on_unit",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Impact ",
      name: "impact",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Document ",
      name: "document",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Mandatory" },
        { value: 2, label: "Non-mandatory" },
      ],
    },
    {
      label: "Historical ",
      name: "historical",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Frequency ",
      name: "frequency",
      type: "select",

      required: false,
      options: [
        {
          value: 1,
          label: "One Time",
        },
        { value: 2, label: "Weekly" },
        {
          value: 3,
          label: "Fortnightly",
        },
        {
          value: 4,
          label: "Monthly",
        },
        {
          value: 5,
          label: "Two Monthly",
        },
        {
          value: 6,
          label: "Quarterly",
        },
        {
          value: 7,
          label: "Four Monthly",
        },
        {
          value: 8,
          label: "Half Yearly",
        },
        {
          value: 9,
          label: "Yearly",
        },
      ],
    },
    {
      label: "Due Date Buffer",
      name: "due_date_buffer",
      type: "text",

      required: false,
    },
    {
      label: "Prior Days For Alerts",
      name: "due_date_buffer:",
      type: "text",

      required: false,
    },
    {
      label: "Legal Due Date ",
      name: "due_date_buffer:",
      type: "date",

      required: false,
    },
    {
      label: "Unit Head Due Date ",
      name: "due_date_buffer:",
      type: "date",

      required: false,
    },
    {
      label: "Function Head Due Date",
      name: "due_date_buffer:",
      type: "date",

      required: false,
    },
    {
      label: "Evaluator Due Date",
      name: "due_date_buffer:",
      type: "date",

      required: false,
    },
    {
      label: "Executor Due Date",
      name: "due_date_buffer:",
      type: "date",

      required: false,
    },
  ];

  const handleCheckboxChange = useCallback(() => {
    const selectedNodes = gridApiRef.current.getSelectedNodes();
    if (selectedNodes.length > 0) {
      setShowDiv(true);
    } else {
      setShowDiv(false);
    }
  }, []);

  return (
    <div>
      <ExpandSearchComponent
        title="Activity Configuration"
        slug="/activity-mapping"
        page="Filter"
        formFields={formFields}
      />

      {showDiv && (
        <div>
          <FormComponent
            showbreadCrumb={false}
            slug="/config"
            type="Create"
            page="Activity Config"
            initialFormData={initialconfigFormData}
            formFields={configformFields}
          />
        </div>
      )}
      <AgGridTableComponent
        slug="/activity-mapping/activity-configuration"
        page="Activity Configuration"
        checkBox={true}
        customColumns={customColumns}
        customRows={staticData}
        customChangeMethod={handleCheckboxChange}
        gridApiRef={gridApiRef}
        rowClickSelection={true}
      />
    </div>
  );
}
