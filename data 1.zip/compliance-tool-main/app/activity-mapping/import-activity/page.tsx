"use client";

import React from "react";
import UploadComponent from "@/components/UploadComponent";

export default function ImportActivity() {
  return (
    <>
      <UploadComponent
        slug="/activity-mapping"
        api="/sample-data/SampleCSV.csv"
        type="Upload"
        page="Activity"
        previousPage="Activity Mapping"
        showbreadCrumb={true}
      />
    </>
  );
}
