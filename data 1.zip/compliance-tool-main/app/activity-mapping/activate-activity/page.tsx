"use client";

import React, { useState, useRef, useCallback, RefObject } from "react";
import ExpandSearchComponent from "@/components/ExpandSearchComponent";
import AgGridTableComponent from "@/components/AgGridTableComponent";
import { GridApi } from "ag-grid-community";
import ModalForm from "@/components/ModalFormComponent";
import { frequency } from "@/app/utils/modelUtils";

export default function ActivateActivity() {
  const [showCheckboxActivity, setShowCheckboxActivity] = useState(false);
  const [showModal, setShowModal] = useState(false);

  // const gridApiRef = useRef(null);
  const gridApiRef: RefObject<GridApi | undefined> = useRef<GridApi>();


  const customColumns = [
    { headerName: "Client Activity ID", field: "client_activity_id" },
    { headerName: "Company Activity ID", field: "company_activity_id" },
    { headerName: "Name of Legislation", field: "legislation" },
    { headerName: "Rule", field: "rule" },
    { headerName: "Reference", field: "reference" },
    { headerName: "Who", field: "who" },
    { headerName: "When", field: "when" },
    { headerName: "Activity", field: "activity" },
    { headerName: "Frequency", field: "frequency" },
    { headerName: "Executor", field: "executor" },
    { headerName: "Activate", field: "activate" },
  ];
  const staticData = [
    {
      client_activity_id: "D30400001659",
      company_activity_id: "L0017152",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Section 12 and Rule 21(1)(i)",
      who: "Employer",
      when: "On engaging an employee in any scheduled employment",
      activity:
        "Pay minimum rates of wages at a rate not less than the minimum rates of wages fixed of any scheduled employment",
      frequency: "Monthly",
      executor: "Rahul 4 R",
      activate: "Deactivate",
    },
    {
      client_activity_id: "D30400001660",
      company_activity_id: "L0017152",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Reference",
      who: "Submitted",
      when: "Someone",
      activity: "Activity",
      frequency: 1,
      executor: "Someone",
      activate: "Deactivate",
    },
    {
      client_activity_id: "D30400001661",
      company_activity_id: "L00171521",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Reference",
      who: "Submitted",
      when: "Someone",
      activity: "Activity",
      frequency: 1,
      executor: "Someone",
      activate: "Deactivate",
    },
    {
      client_activity_id: "D30400001658",
      company_activity_id: "L0017152",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Reference",
      who: "Submitted",
      when: "Someone",
      activity: "Activity",
      frequency: 1,
      executor: "Someone",
      activate: "Deactivate",
    },
    {
      client_activity_id: "D30400001657",
      company_activity_id: "L0017152",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Reference",
      who: "Submitted",
      when: "Someone",
      activity: "Activity",
      frequency: 1,
      executor: "Someone",
      activate: "Deactivate",
    },
    {
      client_activity_id: "D30400001656",
      company_activity_id: "L0017152",
      legislation: "The Minimum Wages Act, 1948",
      rule: "The Rajasthan Minimum Wages Rules,1959",
      reference: "Reference",
      who: "Submitted",
      when: "Someone",
      activity: "Activity",
      frequency: 1,
      executor: "Someone",
      activate: "Deactivate",
    },
  ];

  const formFields = [
    {
      label: "Entity :",
      name: "entity_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
      ],
    },
    {
      label: "Unit :",
      name: "unit",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Cooporate Office - Mumbai" },
        { value: 2, label: "Registered Office - Pune" },
      ],
    },
    {
      label: "Function :",
      name: "function",
      type: "select",

      required: false,
      options: [{ value: 1, label: "Compliance" }],
    },
    {
      label: "Executor :",
      name: "executor",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Aarav Sharma" },
        { value: 2, label: "Priya Patel" },
        { value: 2, label: "Aditya Singh" },
      ],
    },
    {
      label: "Evaluator :",
      name: "evaluator",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Ananya Gupta" },
        { value: 2, label: "Vikram Reddy" },
        { value: 2, label: "Aisha Khan" },
      ],
    },
    {
      label: "Active / Inactive  :",
      name: "active_inactive",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Active" },
        { value: 1, label: "InActive" },
      ],
    },
    {
      label: "Legislation :",
      name: "legislation",
      type: "select",
      large: true,
      required: false,
      options: [
        { value: 1, label: "The Companies Act, 2013" },
        { value: 2, label: "The Payment of Bonus Act,1965" },
        {
          value: 3,
          label:
            "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Act, 2013",
        },
        { value: 4, label: "The Central Goods and Services Tax Act, 2017" },
        { value: 5, label: "The Income Tax Act, 1961" },
        { value: 6, label: "GGL Internal Compliances" },
      ],
    },
    {
      label: "Rule :",
      name: "rule",
      type: "select",
      large: true,
      required: false,
      options: [
        {
          value: 1,
          label: "The Companies (Meetings of Board and its Powers) Rules, 2014",
        },
        { value: 2, label: "The Payment of Bonus Rules, 1975" },
        {
          value: 3,
          label:
            "The Sexual Harassment of Women at Workplace (Prevention, Prohibition and Redressal) Rules, 2013",
        },
        { value: 4, label: "The Central Goods and Services Tax Rules, 2017" },
        { value: 5, label: "The Income Tax Rules, 1962" },
        {
          value: 6,
          label: "The Customs (Provisional Duty Assessment) Regulations, 2011",
        },
      ],
    },
  ];
  const formFields_2 = [
    {
      label: "Impact on Entity",
      name: "impact_on_entity",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Severe" },
        { value: 2, label: "Non Complied " },
        { value: 3, label: "Moderate" },
        { value: 4, label: "Low" },
      ],
    },
    {
      label: "Impact on Unit",
      name: "impact_on_unit",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Severe" },
        { value: 2, label: "Non Complied " },
        { value: 3, label: "Moderate" },
        { value: 4, label: "Low" },
      ],
    },
    {
      label: "Impact",
      name: "impact",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Severe" },
        { value: 2, label: "Non Complied " },
        { value: 3, label: "Moderate" },
        { value: 4, label: "Low" },
      ],
    },
    {
      label: "Frequency",
      name: "frequency",
      type: "select",

      required: false,
      options: Object.keys(frequency).map((key) => ({
        value: key,
        label: frequency[key],
      })),
    },
    {
      label: "Alert Prior Days",
      name: "alert_prior_days",
      type: "text",

      required: false,
    },
    {
      label: "Document",
      name: "document",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Historical",
      name: "historical",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Task Maker Checker",
      name: "task_maker_checker",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Back Dates",
      name: "back_dates",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
    {
      label: "Extra Alert",
      name: "extra_alert",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Yes" },
        { value: 2, label: "No" },
      ],
    },
  ];

  const handleCheckboxChange = useCallback(() => {
    const selectedNodes = gridApiRef.current?.getSelectedNodes();
    if (selectedNodes && selectedNodes.length > 1) {
      setShowCheckboxActivity(true);
    } else {
      setShowCheckboxActivity(false);
    }
  }, []);

  const openModal = () => {
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
  };
  return (
    <>
      <ExpandSearchComponent
        title="Activate Activity"
        slug="/activity-mapping"
        page="Filter"
        formFields={formFields}
      />
      <AgGridTableComponent
        slug="/activity-mapping/activate-activity"
        page="Activities"
        checkboxActivity={showCheckboxActivity}
        edit="Edit"
        onButtonClick={openModal}
        // actionBtn={true}
        // extraActionBtn="Deactivate"
        checkBox={true}
        customColumns={customColumns}
        customRows={staticData}
        customChangeMethod={handleCheckboxChange}
        gridApiRef={gridApiRef}
        rowClickSelection={true}
      />
      <ModalForm
        slug="/activate-activity"
        page="Activate Activity"
        type="Configure"
        show={showModal}
        onHide={closeModal}
        formFields={formFields_2}
      />
    </>
  );
}
