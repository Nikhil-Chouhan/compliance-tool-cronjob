"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function EditUser() {
  const initialFormData = {
    id: null,
    first_name: null,
    middle_name: null,
    last_name: null,
    email: null,
    mobile_no: null,
    password: null,
    role_id: null,
    entity_id: null,
    location_id: null,
    function_id: null,
    designation: null,
    employee_id: null,
    address1: null,
    zipcode: null,
    state_id: null,
    country_id: null,
    status: 1,
  };
  const formFields = [
    {
      label: "Employee ID",
      name: "employee_id",
      type: "text",
    },
    {
      label: "First Name",
      name: "first_name",
      type: "text",
    },
    {
      label: "Middle Name",
      name: "middle_name",
      type: "text",
    },
    {
      label: "Last Name",
      name: "last_name",
      type: "text",
    },
    {
      label: "Designation",
      name: "designation",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Manager" },
        { value: 2, label: "Head of Department" },
        { value: 3, label: "Director" },
        { value: 4, label: "Legal Head" },
        { value: 5, label: "Compliance Officer" },
        { value: 6, label: "Company Secretary" },
        { value: 7, label: "Account Manager" },
        { value: 8, label: "CFO" },
        { value: 9, label: "CEO" },
        { value: 10, label: "Chief Compliance Officer" },
        { value: 11, label: "Head IT" },
        { value: 12, label: "Accountant" },
        { value: 13, label: "Function head" },
        { value: 14, label: "Function" },
        { value: 15, label: "Drafting" },
        { value: 16, label: "MD" },
        { value: 17, label: "Remote Admin" },
        { value: 18, label: "HEAD" },
        { value: 19, label: "Executive" },
      ],
    },
    {
      label: "Email",
      name: "email",
      type: "email",
    },
    {
      label: "Password",
      name: "password",
      type: "password",
    },
    {
      label: "Mobile Number",
      name: "mobile_no",
      type: "tel",
    },
    {
      label: "Address",
      name: "address1",
      type: "textarea",
    },
    {
      label: "Country",
      name: "country_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "India" },
        { value: 2, label: "Canada" },
        { value: 3, label: "USA" },
        { value: 4, label: "Japan" },
        { value: 5, label: "Australia" },
        { value: 6, label: "Germany" },
      ],
    },
    {
      label: "Zip Code",
      name: "zipcode",
      type: "text",
    },
    {
      label: "State",
      name: "state_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Andhra Pradesh" },
        { value: 2, label: "Arunachal Pradesh" },
        { value: 3, label: "Assam" },
        { value: 4, label: "Bihar" },
        { value: 5, label: "Chandigarh" },
        { value: 6, label: "Chattisgarh" },
      ],
    },
    {
      label: "Entity :",
      name: "entity_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
      ],
    },
    {
      label: "Unit :",
      name: "unit",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Cooporate Office - Mumbai" },
        { value: 2, label: "Registered Office - Pune" },
      ],
    },
    {
      label: "Function : ",
      name: "function_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Administration" },
        { value: 2, label: "Secretrial" },
        { value: 3, label: "Human Resources" },
        { value: 4, label: "Information Technology" },
      ],
    },
    {
      label: "Role",
      name: "role_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Executor" },
        { value: 2, label: "Evaluator" },
        { value: 3, label: "Function Head" },
        { value: 4, label: "Unit Head" },
        { value: 5, label: "Entity Head" },
        { value: 6, label: "Administrator" },
        { value: 7, label: "Superadmin" },
        { value: 8, label: "Chief Function Head" },
        { value: 9, label: "Compliance Officer" },
        { value: 9, label: "Chief Compliance Head" },
        { value: 9, label: "Internal Auditor" },
        { value: 9, label: "Auditor" },
        { value: 9, label: "CFO" },
        { value: 9, label: "MD" },
      ],
    },
    {
      label: "Location",
      name: "location_id",
      type: "select",

      requried: true,
      options: [
        { value: 1, label: "Mumbai" },
        { value: 2, label: "Pune" },
        { value: 3, label: "Kolkata" },
        { value: 4, label: "Delhi" },
        { value: 5, label: "Nasik" },
        { value: 6, label: "Uttar pradesh" },
      ],
    },
  ];
  return (
    <>
      <FormComponent
        slug="/user"
        type="Edit"
        page="User"
        initialFormData={initialFormData}
        formFields={formFields}
      />
    </>
  );
}
