"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function ViewUser() {
  const initialFormData = {
    id: null,
    first_name: null,
    middle_name: null,
    last_name: null,
    email: null,
    mobile_no: null,
    password: null,
    role_id: null,
    entity_id: null,
    location_id: null,
    function_id: null,
    designation: null,
    employee_id: null,
    address1: null,
    zipcode: null,
    state_id: null,
    country_id: null,
    status: 1,
  };
  const formFields = [
    {
      label: "Employee ID",
      name: "employee_id",
      type: "text",
      required: false,
      disabled: true,
    },
    {
      label: "First Name",
      name: "first_name",
      type: "text",
      required: false,
      disabled: true,
    },
    {
      label: "Middle Name",
      name: "middle_name",
      type: "text",
      required: false,
      disabled: true,
    },
    {
      label: "Last Name",
      name: "last_name",
      type: "text",
      required: false,
      disabled: true,
    },
    {
      label: "Designation",
      name: "designation",
      type: "text",

      apitype: "enum",
      required: true,
      disabled: true,
    },
    {
      label: "Email",
      name: "email",
      type: "email",
      required: false,
      disabled: true,
    },
    {
      label: "Mobile Number",
      name: "mobile_no",
      type: "tel",
      required: false,
      disabled: true,
    },
    {
      label: "Address",
      name: "address1",
      type: "textarea",
      required: false,
      disabled: true,
    },
    {
      label: "Country",
      name: "country_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "State",
      name: "state_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "Zip Code",
      name: "zipcode",
      type: "input",
      required: false,
      disabled: true,
    },
    {
      label: "Role",
      name: "role_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "Entity",
      name: "entity_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "Location",
      name: "location_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "Function",
      name: "function_id",
      type: "text",

      required: false,
      disabled: true,
    },
    {
      label: "Status",
      name: "status",
      type: "select",

      required: false,
      disabled: true,
      options: [
        { value: 1, label: "Active" },
        { value: 2, label: "Inactive" },
      ],
    },
  ];
  return (
    <>
      <FormComponent
        slug="/user"
        type="View"
        page="User"
        initialFormData={initialFormData}
        formFields={formFields}
      />
    </>
  );
}
