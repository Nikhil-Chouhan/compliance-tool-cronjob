"use client";

import AgGridTableComponent from "@/components/AgGridTableComponent";

export default function User() {
  const customColumns = [
    { headerName: "Employee ID", field: "employee_id" },
    { headerName: "First Name", field: "first_name" },
    { headerName: "Last Name", field: "last_name" },
    { headerName: "Email", field: "email" },
    { headerName: "Mobile Number", field: "mobile_no" },
    { headerName: "Role", field: "role" },
  ];

  const customRows = [
    {
      employee_id: "1003",
      first_name: "Vishal",
      last_name: "Chakravarty",
      email: "vishal.chakravarty@gmail.com",
      mobile_no: "9907963478",
      role: "Super Admin",
    },
    {
      employee_id: "1004",
      first_name: "Sayli",
      last_name: "Shringarpure",
      email: "Sayli.Dighe@gmail.com",
      mobile_no: "9907963478",
      role: "Function Head",
    },
    {
      employee_id: "1005",
      first_name: "Arpita",
      last_name: "Singh",
      email: "arpita.singh@gmail.com",
      mobile_no: "9907963478",
      role: "	Executor",
    },
    {
      employee_id: "1006",
      first_name: "Rupal",
      last_name: "joshi",
      email: "rupal.joshi@gmail.com",
      mobile_no: "9907963478",
      role: "Evaluator",
    },
  ];

  return (
    <AgGridTableComponent
      slug="/user"
      page="Users"
      importBtn={true}
      actionBtn={true}
      addBtn={true}
      customColumns={customColumns}
      customRows={customRows}
    />
  );
}
