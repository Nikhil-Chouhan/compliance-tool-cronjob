"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function EditFunction() {
  const formFields = [
    {
      label: "Function",
      name: "function_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/function"
        type="Edit"
        showbreadCrumb={true}
        page="Function"
        formFields={formFields}
      />
    </>
  );
}
