"use client";
import AgGridTableComponent from "@/components/AgGridTableComponent";
import React from "react";

export default function Function() {
  const customColumns = [
    { headerName: "Function Name", field: "Function_name" },
  ];
  const funcationNames = [
    {
      Function_name: "Human Resources",
    },
    {
      Function_name: "Secretarial",
    },
    {
      Function_name: "EHS",
    },
    {
      Function_name: "Information Technology",
    },
    {
      Function_name: "Administration",
    },
    {
      Function_name: "Commercial",
    },
    {
      Function_name: "Regulatory Laws",
    },
    {
      Function_name: "Maintenance",
    },
    {
      Function_name: "HR",
    },
    {
      Function_name: "HEALTH",
    },
    {
      Function_name: "production",
    },
    {
      Function_name: "prakhar",
    },
    {
      Function_name: "ankit",
    },
    {
      Function_name: "VAGAD",
    },
    {
      Function_name: "Research and Development",
    },
    {
      Function_name: "Compliance",
    },
    {
      Function_name: "Technician",
    },
    {
      Function_name: "Spot girl",
    },
    {
      Function_name: "Assistant",
    },
    {
      Function_name: "Safety",
    },
  ];

  return (
    <>
      <AgGridTableComponent
        slug="/function"
        page="Function"
        actionBtn={true}
        importBtn={true}
        addBtn={true}
        customColumns={customColumns}
        customRows={funcationNames}
      />
    </>
  );
}
