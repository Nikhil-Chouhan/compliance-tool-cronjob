"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function AddFunction() {
  const formFields = [
    {
      label: "Function",
      name: "Function_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/function"
        type="Add"
        showbreadCrumb={true}
        page="Function"
        formFields={formFields}
      />
    </>
  );
}
