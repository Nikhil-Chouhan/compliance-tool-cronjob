"use client";

import Image from "next/image";
import { inputStyles } from "../styles/constants";
import Link from "next/link";
import "app/loginstyles.css";
import { FaEnvelope, FaUserLock } from "react-icons/fa";
export default function Login() {
  return (
    <div className="LoginPageContainer">
      <div className="row LoginPageInnerContainer">
        <div className="col-md-6 ImageContianer">
          <Image
            className="position-relative GroupImage"
            src="/compliance_login1.png"
            alt="Sign In Image"
            fill={true}
          />
        </div>
        <div className="col-md-6 LoginFormContainer justify-content-center">
          <div className="LoginFormInnerContainer ">
            <div className="LogoContainer d-flex justify-content-center">
              <Image
                className="logo "
                src="/regucheck_logo1.png"
                alt="ReguCheck"
                width="260"
                height="500"
              />
            </div>
            <header className="header text-center">
              <b>Sign In</b>
            </header>
            <header className="subHeade text-secondary text-center">
              Welcome to <b>ReguCheck!</b>
            </header>

            <form>
              <div className="form-group inputContainer justify-content-center">
                <label className="label">
                  <FaEnvelope size={20} className="mx-3" />
                  <span>Email Address</span>
                </label>
                <input
                  type="text"
                  name={"username"}
                  className="form-control pt-3 pb-3 border"
                  style={inputStyles}
                  id="username"
                  placeholder="Enter your Email Address"
                  required
                />
              </div>
              <div className="inputContainer">
                <label className="label">
                  <FaUserLock size={25} className="mx-3" />
                  <span>Password</span>
                </label>
                <input
                  type="password"
                  className="form-control pt-3 pb-3 border"
                  style={inputStyles}
                  name={"password"}
                  placeholder="Enter your Password"
                  id="password"
                  required
                />
              </div>
              <div className="OptionsContainer">
                <div className="checkboxContainer">
                  <input type="checkbox" id="RememberMe" className="checkbox" />{" "}
                  <label>
                    <b>Remember me</b>
                  </label>
                </div>
                <a href="#" className="ForgotPasswordLink">
                  Forgot Password?
                </a>
              </div>
              <Link
                href="/"
                className="col-md-12 mt-4 btn light btn-info btn-lg btn-rounded"
              >
                <b>Log In</b>
              </Link>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
