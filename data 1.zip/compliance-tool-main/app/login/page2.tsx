"use client";

import { useRef } from "react";
import Image from "next/image";
import { inputStyles } from "../styles/constants";
import Toast, { ToastType } from "@/components/Toast_old";
import Link from "next/link";

export default function Login() {
  const toastRef = useRef<ToastType>();

  return (
    <main className="row justify-content-center ">
      <div className="card rounded-corner col-md-11">
        <div className="row h-100 justify-content-center align-items-center">
          <div className="col-md-6 d-flex flex-wrap justify-content-center">
            <div className="col-md-11 ">
              <Image
                className="position-relative w-100 h-100 p-2"
                src="/compliance_login3.jpg"
                alt="Sign In Image"
                fill={true}
              />
            </div>
          </div>

          <div className="col-md-6 d-flex flex-wrap justify-content-center">
            <div className="col-md-8 h-100 justify-content-center">
              <div className="col-md-12 d-flex mt-5 mb-5 ">
                <div className="col-md-10 justify-content-center align-items-center">
                  <h1 className="card-title text-center">
                    <b>Sign In</b>
                  </h1>
                  <p className="card-text text-center mb-4 text-secondary">
                    <b>Sign up on internal platform</b>
                  </p>
                  <form className="mt-4 mb-4 needs-validation">
                    <div className="form-group mt-3 mb-3">
                      <input
                        type="text"
                        name={"username"}
                        className="form-control pt-3 pb-3 border-2"
                        style={inputStyles}
                        id="username"
                        placeholder="Username"
                        required
                      />
                    </div>
                    <div className="form-group mt-3 mb-3">
                      <input
                        type="password"
                        className="form-control pt-3 pb-3 border-2"
                        style={inputStyles}
                        name={"password"}
                        placeholder="Password"
                        id="password"
                        required
                      />
                    </div>
                    <div className="form-check mb-3 col-md-12 d-flex justify-content-between">
                      <div>
                        <input
                          type="checkbox"
                          className="form-check-input border border-3"
                          id="rememberMe"
                        />
                        <label
                          className="form-check-label"
                          htmlFor="rememberMe"
                        >
                          Remember me
                        </label>
                      </div>
                    </div>
                    <Link
                      href="/user"
                      className="col-md-12 mt-2 btn light btn-info btn-lg btn-rounded"
                    >
                      SIGN IN
                    </Link>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
        <Toast ref={toastRef} />
      </div>
    </main>
  );
}
