"use client";

import ExpandSearchComponent from "@/components/ExpandSearchComponent";
import React, { useState } from "react";
import { Calendar, momentLocalizer } from "react-big-calendar";
import moment from "moment";
import "react-big-calendar/lib/css/react-big-calendar.css";
import CalenderPopup from "@/components/CalenderPopup";

const localizer = momentLocalizer(moment);

const generateRandomEvents = (setId, count) => {
  const events = [];

  for (let i = 1; i <= count; i++) {
    const startDate = new Date(
      Date.parse("2023-11-01T00:00:00") +
        Math.floor(Math.random() * 30) * 24 * 60 * 60 * 1000
    );
    const endDate = new Date(
      startDate.getTime() + Math.floor(Math.random() * 5) * 60 * 60 * 1000
    );

    events.push({
      id: setId,
      title: `ActivityID C${setId}4379${i}`,
      start: startDate,
      end: endDate,
    });
  }

  return events;
};

export default function ComplianceCalender() {
  const [events] = useState(generateRandomEvents(1, 20));

  const formFields = [
    {
      label: "Entity :",
      name: "entity_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
      ],
    },
    {
      label: "Unit :",
      name: "unit",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Cooporate Office - Mumbai" },
        { value: 2, label: "Registered Office - Pune" },
      ],
    },
    {
      label: "Function : ",
      name: "function_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Administration" },
        { value: 2, label: "Secretrial" },
        { value: 3, label: "Human Resources" },
        { value: 4, label: "Information Technology" },
      ],
    },
    {
      label: "Executor :",
      name: "executor_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "executor" },
        { value: 2, label: "Non Executor" },
        { value: 3, label: "Delayed" },
        { value: 4, label: "N/A" },
      ],
    },
    {
      label: "Evaluator :",
      name: "evaluator_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Severe" },
        { value: 2, label: "Major" },
        { value: 3, label: "Moderate" },
        { value: 4, label: "Low" },
      ],
    },
    {
      label: "Function Head :",
      name: "functionhead_id",
      type: "select",

      required: false,
      options: [
        { value: 1, label: "Function Head" },
        { value: 2, label: "Non Function Head" },
        { value: 3, label: "Delayed" },
        { value: 4, label: "N/A" },
      ],
    },
  ];

  const [showModal, setShowModal] = useState(false);
  const [selectedEvent, setSelectedEvent] = useState(null);

  const openModal = (event) => {
    setSelectedEvent(event);
    setShowModal(true);
  };

  const closeModal = () => {
    setSelectedEvent(null);
    setShowModal(false);
  };

  return (
    <>
      <div>
        <ExpandSearchComponent slug="/" page="Filter" formFields={formFields} />
      </div>
      <div className="container-fluid">
        <div className="row custom_row bg-white rounded-corner h-100 p-4">
          <div className="col-md-12 px-0">
            <Calendar
              localizer={localizer}
              events={events}
              startAccessor="start"
              endAccessor="end"
              style={{ height: 580 }}
              onSelectEvent={openModal}
            />
          </div>
        </div>
      </div>
      <CalenderPopup
        show={showModal}
        onHide={closeModal}
        event={selectedEvent}
      />
    </>
  );
}
