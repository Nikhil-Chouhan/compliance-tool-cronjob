"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function AddFunction() {
  const formFields = [
    {
      label: "Parent Entity:",
      name: "Parent Entity",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
        { value: 5, label: "Administration" },
        { value: 6, label: "Secretrial" },
        { value: 7, label: "Human Resources" },
        { value: 8, label: "Information Technology" },
      ],
    },
    {
      label: "Entity",
      name: "entity_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/entity"
        showbreadCrumb={true}
        type="Add"
        page="Entity"
        formFields={formFields}
      />
    </>
  );
}
