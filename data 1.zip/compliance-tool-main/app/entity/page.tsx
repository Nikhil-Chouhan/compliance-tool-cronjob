"use client";

import React from "react";
import AgGridTableComponent from "@/components/AgGridTableComponent";

export default function Entity() {
 

  const customColumns = [
    { headerName: "Entity", field: "entity" },
    { headerName: "Parent", field: "parent" },
  ];
  const staticData = [
    {
      entity: "Demo Entity Pvt Ltd",
      parent: "NA",
    },
    {
      entity: "ABC Mining Pvt Ltd",
      parent: "NA",
    },
    {
      entity: "NBFC India Ltd",
      parent: "NA",
    },
    {
      entity: "Entity Data",
      parent: "NA",
    },
    {
      entity: "JFW Limited",
      parent: "Demo Entity Pvt Ltd",
    },
    {
      entity: "Grupo_Demo",
      parent: "NA",
    },
    {
      entity: "Entity Data",
      parent: "NA",
    },
    {
      entity: "Entity Data",
      parent: "NA",
    },
    {
      entity: "Entity Data",
      parent: "NA",
    },
    {
      entity: "Entity Data",
      parent: "NA",
    },
  ];

  return (
    <>
      <AgGridTableComponent
        actionBtn={true}
        slug="/entity"
        page="Entity List"
        addBtn={true}
        importBtn={true}
        customColumns={customColumns}
        customRows={staticData}
      />
    </>
  );
}
