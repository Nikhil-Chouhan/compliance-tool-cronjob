"use client";

import AgGridTableComponent from "@/components/AgGridTableComponent";
import React from "react";

export default function NoticeManagement() {
  const customColumns = [
    { headerName: "Designation Name", field: "Designation_name" },
  ];
  const designationNames = [
    {
      Designation_name: "Head of Department",
    },
    {
      Designation_name: "Director",
    },
    {
      Designation_name: "Legal Head",
    },
    {
      Designation_name: "Compliance Officer",
    },
    {
      Designation_name: "Company Secretary",
    },
    {
      Designation_name: "Account Manager",
    },
    {
      Designation_name: "CFO",
    },
    {
      Designation_name: "CEO",
    },
    {
      Designation_name: "Chief Compliance Officer",
    },
    {
      Designation_name: "Head IT",
    },
    {
      Designation_name: "Accountant",
    },
    {
      Designation_name: "Function head",
    },
    {
      Designation_name: "Function",
    },
    {
      Designation_name: "Drafting",
    },
    {
      Designation_name: "MD",
    },
    {
      Designation_name: "Remote Admin",
    },
    {
      Designation_name: "HEAD",
    },
    {
      Designation_name: "Executive",
    },
  ];
  return (
    <>
      <AgGridTableComponent
        slug="/designations"
        page="Designations"
        actionBtn={true}
        addBtn={true}
        customColumns={customColumns}
        customRows={designationNames}
      />
    </>
  );
}
