"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function EditDesignations() {
  const formFields = [
    {
      label: "Designations",
      name: "designation_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/designations"
        type="Edit"
        page="Designation"
        formFields={formFields}
      />
    </>
  );
}
