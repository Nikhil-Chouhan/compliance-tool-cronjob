"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function AddDesignations() {
  const formFields = [
    {
      label: "Designation",
      name: "designation_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/designations"
        type="Add"
        page="Designation"
        formFields={formFields}
        showbreadCrumb={true}
      />
    </>
  );
}
