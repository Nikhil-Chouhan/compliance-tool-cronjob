"use client";

import AgGridTableComponent from "@/components/AgGridTableComponent";
import React from "react";

export default function EntityMapping() {
  const customColumns = [
    { headerName: "Entity", field: "entity_name" },
    { headerName: "Unit", field: "unit_name" },
    { headerName: "Function", field: "function_name" },
  ];
  const funcationNames = [
    {
      entity_name: "Demo Entity Pvt Ltd",
      unit_name: "Corporate Office - Mumbai",
      function_name: "Human Resources",
    },
    {
      entity_name: "Demo Entity -2",
      unit_name: "Corporate Office - Mumbai",
      function_name: "Secretarial",
    },
    {
      entity_name: "NBFC India Ltd",
      unit_name: "Corporate",
      function_name: "EHS",
    },
    {
      entity_name: "JFW Limited",
      unit_name: "Registered Office - Pune",
      function_name: "Information Technology",
    },
    {
      entity_name: "MMSclC",
      unit_name: "Registered Office - Pune",
      function_name: "Administration",
    },
    {
      entity_name: "R Ltd",
      unit_name: "Registered Office - Pune",
      function_name: "Commercial",
    },
    {
      entity_name: "VAGAD LTD",
      unit_name: "Registered Office - Pune",
      function_name: "Regulatory Laws",
    },
    {
      entity_name: "CROMA",
      unit_name: "Registered Office - Pune",
      function_name: "Maintenance",
    },
    {
      entity_name: "Nike",
      unit_name: "Registered Office - Pune",
      function_name: "HR",
    },
    {
      entity_name: "Zara",
      unit_name: "Registered Office - Pune",
      function_name: "HEALTH",
    },
    {
      entity_name: "H&M",
      unit_name: "Registered Office - Pune",
      function_name: "production",
    },
    {
      entity_name: "Adidas",
      unit_name: "Registered Office",
      function_name: "prakhar",
    },
    {
      entity_name: "Puma",
      unit_name: "Registered Office",
      function_name: "ankit",
    },
    {
      entity_name: "Suprime",
      unit_name: "Registered Office ",
      function_name: "VAGAD",
    },
    {
      entity_name: "MeCard",
      unit_name: "DBTPL - Mumbai",
      function_name: "Research and Development",
    },
    {
      entity_name: "DBTPL",
      unit_name: "DBTPL - Mumbai",
      function_name: "Compliance",
    },
    {
      entity_name: "Deepija telecome pvt ltd",
      unit_name: "Deepija - Mumbai",
      function_name: "Technician",
    },
    {
      entity_name: "BOB",
      unit_name: "BOB - Delhi",
      function_name: "Spot girl",
    },
    {
      entity_name: "ICICI",
      unit_name: "ICICI - Kolkata",
      function_name: "Assistant",
    },
    {
      entity_name: "Canara",
      unit_name: "Canara - Pune",
      function_name: "Safety",
    },
  ];

  return (
    <>
      <AgGridTableComponent
        slug="/entity-mapping"
        page="Entity Mapping"
        actionBtn={true}
        importBtn={true}
        addBtn={true}
        customColumns={customColumns}
        customRows={funcationNames}
      />
    </>
  );
}
