"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function EditEntityMapping() {
  
  const formFields = [
    {
      label: "Entity :",
      name: "entity_id",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Demo entity Pvt Ltd" },
        { value: 2, label: "NBFC ltd " },
        { value: 3, label: "JFW ltd" },
        { value: 4, label: "Demo Entity 2 Pvt Ltd" },
      ],
    },
    {
      label: "Unit :",
      name: "unit",
      type: "select",

      required: true,
      options: [
        { value: 1, label: "Cooporate Office - Mumbai" },
        { value: 2, label: "Registered Office - Pune" },
      ],
    },
    {
      label: "Function : ",
      name: "function_id",
      type: "select",
      multiselect: true,
      required: true,
      options: [
        { value: 1, label: "Administration" },
        { value: 2, label: "Secretrial" },
        { value: 3, label: "Human Resources" },
        { value: 4, label: "Information Technology" },
      ],
    },
  ];
  return (
    <>
      <FormComponent
        title="Entity Mapping"
        slug="/entity-mapping"
        type="Edit"
        showbreadCrumb={true}
        page="Entity Mapping"
        formFields={formFields}
      />
    </>
  );
}
