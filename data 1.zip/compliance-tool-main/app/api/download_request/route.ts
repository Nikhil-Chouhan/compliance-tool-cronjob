import { NextRequest, NextResponse } from "next/server";
import { prisma, Prisma } from "@/app/utils/prisma.server";
import { downloadModel, download_activityModel } from "@/prisma/zod";
import { z } from "zod";
import { getToken } from "next-auth/jwt";
import { sendEmail, EmailOptions } from "../../utils/email";
import {
  handleError,
  removeUnderscoreAndAddSpace,
} from "@/app/utils/modelUtils";

export type downloadT = z.infer<typeof downloadModel>;
export type downloadActivity = z.infer<typeof download_activityModel>;

interface downloadType extends downloadT {
  compliance_activity_id: number[];
}
interface TokenContext {
  req: NextRequest;
}
interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}

export async function GET(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);
  const queryParams = {
    page: request.nextUrl.searchParams.get("page"),
    pageSize: request.nextUrl.searchParams.get("pageSize"),
    filterid: request.nextUrl.searchParams.get("filterId"),
    filtercountry_id: request.nextUrl.searchParams.get("filterCountryId"),
    filterstate_id: request.nextUrl.searchParams.get("filterStateId"),
    filterlaw_category: request.nextUrl.searchParams.get("filterLawCategoryId"),
    filterlegislation_id: request.nextUrl.searchParams.get(
      "filterLegislationId"
    ),
    filterrule_id: request.nextUrl.searchParams.get("filterRuleId"),
  };

  const { page, pageSize } = queryParams;

  let offset = 0;
  let take = undefined;
  if (pageSize != "-1") {
    take = Number(pageSize);
    offset = (Number(page) - 1) * Number(pageSize);
  }
  const filterProperties = [
    "filterid",
    "filtercountry_id",
    "filterstate_id",
    "filterlaw_category",
    "filterlegislation_id",
    "filterrule_id",
  ];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};
      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      acc.push(condition);
    }
    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.downloadWhereInput = {
    deleted: false,
    user_id: token?.sub ? parseInt(token.sub) : undefined,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.downloadWhereInput["AND"])
        : undefined,
  };

  try {
    const downloadList = await prisma.download.findMany({
      where: prismaWhereClause,
      skip: offset,
      take: take,
      orderBy: {
        created_at: "desc", // or 'asc' for ascending order
      },
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        approved: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        country: {
          select: {
            name: true,
          },
        },
        state: {
          select: {
            name: true,
          },
        },
        legislation: {
          select: {
            name: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
        download_activity: {
          include: {
            compliance_activity: {
              select: {
                title: true,
              },
            },
          },
        },
      },
    });

    const totalCount = await prisma.download.count({
      where: prismaWhereClause,
    });

    return NextResponse.json({ downloadList, totalCount }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading download", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);
  console.log(token);

  const body: downloadType = await request.json();
  type body_download = Omit<downloadType, "compliance_activity_id">;
  const newDownload: body_download = { ...body };

  if ("compliance_activity_id" in newDownload) {
    delete newDownload.compliance_activity_id;
  }

  const result = downloadModel.safeParse(newDownload);
  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const downloadRes = await prisma.download.create({
      data: {
        ...newDownload,
        user_id: token?.sub ? parseInt(token.sub) : 0,
      } as Prisma.downloadCreateInput,
      include: {
        country: true,
        state: true,
      },
    });

    let createdDataPromises;
    if (downloadRes) {
      const download_activity = body?.compliance_activity_id || [];

      createdDataPromises = download_activity.map(async (record: number) => {
        const downloadactivtyRes = await prisma.download_activity.create({
          data: {
            compliance_activity_id: record,
            download_id: downloadRes.id,
          },
        });
        return downloadactivtyRes;
      });
    }

    let download_activity;
    if (createdDataPromises) {
      download_activity = await Promise.all(createdDataPromises);
    }

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "downloadRequestandApprovedEmailTemplates",
        to: process.env.ADMIN_EMAIL,
        subject: "New Download Request Added In CRS",
        data: {
          message: `Following New Download Request Is Added In CRS by user : ${token?.user.first_name} ${token?.user.last_name}`,
          country: downloadRes.country?.name,
          centralOrState: downloadRes.state?.name,
          lawCategory: removeUnderscoreAndAddSpace(downloadRes.law_category),
          uploadedByUser: `${token?.user.first_name} ${token?.user.last_name}`,
        },
      };
      const result = await sendEmail(emailOptions);
    } else {
      console.error("SMTP enable is not present or disabled.");
    }
    console.log("Email sent successfully", result);

    return NextResponse.json(
      {
        response: { downloadRes, download_activity },
        message: "Email sent successfully",
      },
      { status: 200 }
    );
  // } catch (e) {
  //   console.error("Error sending email:", e);
  //   console.log("exception is", e);
  //   return NextResponse.json(
  //     {
  //       errors: [
  //         { error: "An error occurred while sending the email", status: 500 },
  //         { response: , status: 500 },
  //       ],
  //     },
  //     { status: 500 }
  //   );
  } catch (e) {
    return handleError(e,"error creating download", 500);
  } finally {
    await prisma.$disconnect();
  }
}
