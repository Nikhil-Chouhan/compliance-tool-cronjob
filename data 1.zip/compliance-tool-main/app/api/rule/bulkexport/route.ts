import { prisma } from "@/app/utils/prisma.server";
import {
  transformKeys,
  transformFields,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import * as XLSX from "xlsx";
import { ruleModel } from "@/prisma/zod/rule";
import { z } from "zod";
import { legislation } from "@prisma/client";

export type rule = z.infer<typeof ruleModel>;

export type ColumnType = {
  id: boolean;
  uuid: boolean;
  legislation: boolean;
  legislation_id: boolean;
  code: boolean;
  name: boolean;
  applicability: boolean;
  sources: boolean;
  effective_date: boolean;
  updated_date: boolean;
  documents: boolean;
  status: boolean;
  created_at: boolean;
};

export async function GET() {
  try {
    const rule: rule = await prisma.rule.findFirstOrThrow();

    if (!rule) {
      return NextResponse.json({ error: "rule not found" }, { status: 404 });
    }

    // Convert the rule object to key-value pairs
    const ruleFields = transformKeys(rule);

    return NextResponse.json({ fields: ruleFields }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading rule", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const fields = body.fields || [];

  const type = request.nextUrl.searchParams.get("type") || "csv";

  const filterName = request.nextUrl.searchParams.get("filterName");

  let whereClause = { deleted: false };
  if (filterName) {
    // Apply filtering based on the provided filterName
    whereClause = {
      ...whereClause,
      AND: [
        {
          name: { contains: filterName.toString(), mode: "insensitive" },
        },
      ],
    };
  }

  try {
    const selectedFields = fields.reduce(
      (columns: ColumnType, field: keyof ColumnType) => {
        if (field === "legislation_id") {
          columns.legislation = true;
        } else {
          columns[field] = true;
        }
        return columns;
      },
      {}
    );

    const rules = await prisma.rule.findMany({
      select: selectedFields,
      where: whereClause,
    });

    const capitalizedWithSpaceFields = transformFields(fields);

    const rulesWithCapitalizedAndSpacedKeys = rules.map((rule) => {
      return fields.reduce(
        (columns: ColumnType, field: keyof ColumnType, index: number) => {
          const updatedKeys = capitalizedWithSpaceFields[index];
          if (field === "legislation_id") {
            const legislation = rule?.legislation as unknown as legislation;
            columns[updatedKeys] = legislation?.name;
          } else {
            columns[updatedKeys] = rule[field];
          }
          return columns;
        },
        {}
      );
    });

    const ws = XLSX.utils.json_to_sheet(rulesWithCapitalizedAndSpacedKeys, {
      header: capitalizedWithSpaceFields,
    });

    // Create the Excel workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "rule");

    // Write the Excel file to a buffer
    let workBookOutput;
    if (type == "xlsx") {
      workBookOutput = XLSX.write(wb, { bookType: "xlsx", type: "buffer" });
    } else {
      workBookOutput = XLSX.write(wb, { bookType: "csv", type: "buffer" });
    }
    const buffer = Buffer.from(workBookOutput);

    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "rule-download.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "rule-download.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error uploading rule data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
