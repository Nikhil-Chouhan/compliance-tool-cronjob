import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { ruleModel } from "@/prisma/zod/rule";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type rule = z.infer<typeof ruleModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const ruleRow = await prisma.rule.findUnique({
      where: { uuid: uuid, deleted: false },
      include: {
        legislation: {
          select: {
            name: true,
            country: true,
            industry: true,
            state: true,
          },
        },
      },
    });
    return NextResponse.json({ ruleRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading rule", 500);
  } finally {
    await prisma.$disconnect();
  }
}
