import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { userModel } from "@/prisma/zod/user";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type user = z.infer<typeof userModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const userRow = await prisma.user.findUnique({
      where: { uuid: uuid, deleted: false },
      include: {
        country: {
          select: {
            id: true,
            name: true,
          },
        },
        state: {
          select: {
            id: true,
            name: true,
          },
        },
        role: {
          select: {
            id: true,
            name: true,
          },
        },
        entity: {
          select: {
            id: true,
            name: true,
          },
        },
        location: {
          select: {
            id: true,
            name: true,
          },
        },
        function_department: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    return NextResponse.json({ userRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading user", 500);
  } finally {
    await prisma.$disconnect();
  }
}
