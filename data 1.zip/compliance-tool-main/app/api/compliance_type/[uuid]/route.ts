import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { compliance_typeModel } from "@/prisma/zod/compliance_type";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type compliance_type = z.infer<typeof compliance_typeModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const compliance_typeRow = await prisma.compliance_type.findUnique({
      where: { uuid: uuid, deleted: false },
    });
    return NextResponse.json({ compliance_typeRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading compliance_type", 500);
  } finally {
    await prisma.$disconnect();
  }
}
