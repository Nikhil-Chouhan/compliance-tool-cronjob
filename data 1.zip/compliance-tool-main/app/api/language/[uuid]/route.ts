import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { languageModel } from "@/prisma/zod/language";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type language = z.infer<typeof languageModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const languageRow = await prisma.language.findUnique({
      where: { uuid: uuid, deleted: false },
    });
    return NextResponse.json({ languageRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading language", 500);
  } finally {
    await prisma.$disconnect();
  }
}
