import { NextResponse, NextRequest } from "next/server";
import { sendEmail, EmailOptions } from "../../utils/email";
import { handleError } from "@/app/utils/modelUtils";

export async function GET(request: NextRequest) {
  try {
    const emailOptions: EmailOptions = {
      template: "emailTemplate",
      to: "sandip.gupta@dbtpl.com",
      subject: "Test Email",
      message: "This is a test email from CRS Tool",
      data: {
        name: "Test Name",
        message: "Test Message from CRS",
      },
    };
    const result = await sendEmail(emailOptions);
    console.log("Email sent successfully", result);
    return NextResponse.json(
      { message: "Email sent successfully" },
      { status: 200 }
    );
  }catch (e) {
    return handleError(e, "An error occurred while sending the email", 500);
  }
}
