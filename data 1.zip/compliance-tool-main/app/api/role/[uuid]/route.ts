import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { roleModel } from "@/prisma/zod/role";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type role = z.infer<typeof roleModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const roleRow = await prisma.role.findUnique({
      where: { uuid: uuid, deleted: false },
    });
    return NextResponse.json({ roleRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading role", 500);
  } finally {
    await prisma.$disconnect();
  }
}
