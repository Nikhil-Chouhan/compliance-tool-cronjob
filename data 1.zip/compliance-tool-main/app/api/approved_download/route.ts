import { NextRequest, NextResponse } from "next/server";
import { prisma, Prisma } from "@/app/utils/prisma.server";
import { downloadModel } from "@/prisma/zod";
import { z } from "zod";
import { getToken } from "next-auth/jwt";
import { patchType } from "@/app/utils/typesUtils";
import { EmailOptions, sendEmail } from "@/app/utils/email";
import {
  handleError,
  removeUnderscoreAndAddSpace,
} from "@/app/utils/modelUtils";

export type download = z.infer<typeof downloadModel>;
interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}
interface TokenContext {
  req: NextRequest;
}

export async function GET(request: NextRequest) {
  console.log(
    "request query--->",
    request.nextUrl.searchParams.get("filterName")
  );
  const queryParams = {
    page: request.nextUrl.searchParams.get("page"),
    pageSize: request.nextUrl.searchParams.get("pageSize"),
    filterid: request.nextUrl.searchParams.get("filterId"),
    filtercountry_id: request.nextUrl.searchParams.get("filterCountryId"),
    filterstate_id: request.nextUrl.searchParams.get("filterStateId"),
    filterrule_id: request.nextUrl.searchParams.get("filterRuleId"),
    filterlegislation_id: request.nextUrl.searchParams.get(
      "filterLegislationId"
    ),
    filterlaw_category: request.nextUrl.searchParams.get("filterLawCategory"),
    filteruser_id: request.nextUrl.searchParams.get("filterUserId"),
  };

  const { page, pageSize } = queryParams;

  let offset = 0;
  let take: number | undefined = undefined;
  if (pageSize !== "-1") {
    take = Number(pageSize);
    offset = (Number(page) - 1) * Number(pageSize);
  }

  const filterProperties = [
    "filterid",
    "filtercountry_id",
    "filterstate_id",
    "filterrule_id",
    "filterlegislation_id",
    "filterlaw_category",
    "filteruser_id",
  ];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};
      console.log(property);

      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      console.log("condition---> ", condition);
      acc.push(condition);
    }
    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.downloadWhereInput = {
    deleted: false,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.downloadWhereInput["AND"])
        : undefined,
  };

  try {
    const downloadList = await prisma.download.findMany({
      where: prismaWhereClause,
      skip: offset,
      take: take,
      orderBy: {
        created_at: "desc", // or 'asc' for ascending order
      },
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        approved: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        country: {
          select: {
            name: true,
          },
        },
        state: {
          select: {
            name: true,
          },
        },
        legislation: {
          select: {
            name: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
        download_activity: {
          include: {
            compliance_activity: {
              select: {
                title: true,
              },
            },
          },
        },
      },
    });

    const totalCount = await prisma.download.count({
      where: prismaWhereClause,
    });

    return NextResponse.json({ downloadList, totalCount }, { status: 200 });
  } catch (e) {
    console.log("exception is", e);
    return handleError(e, "error reading download", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);

  const body: download = await request.json();

  try {
    const download = await prisma.download.findUnique({
      where: { id: body?.id || 0 },
    });
    if (download && download.id) {
      const updateddownload = await prisma.download.update({
        where: { id: download.id },
        data: {
          approval_status: body.approval_status,
          approved_by: token?.sub ? parseInt(token.sub) : 0,
          approvet_at: new Date(),
        },
        include: {
          country: true,
          state: true,
          legislation: {
            select: {
              law_category: true,
            },
          },
        },
      });

      let emailOptions: EmailOptions;
      if (process.env.SMTP_ENABLE === "enable") {
        console.log("status updated ======>", updateddownload.approval_status);
        if (updateddownload.approval_status === 2) {
          emailOptions = {
            template: "downloadRequestandApprovedEmailTemplates",
            to: token?.user.email,
            subject: "Download Request Approved In CRS",
            data: {
              message: `Download Request for user : ${token?.user.first_name} ${token?.user.last_name} is rejected`,
              country: updateddownload.country?.name,
              centralOrState: updateddownload.state?.name,
              lawCategory: removeUnderscoreAndAddSpace(
                updateddownload.legislation?.law_category
              ),
              uploadedByUser: `${token?.user.first_name} ${token?.user.last_name}`,
            },
          };
        } else if (updateddownload.approval_status === 1) {
          emailOptions = {
            template: "downloadRequestandApprovedEmailTemplates",
            to: token?.user.email,
            cc: process.env.ADMIN_EMAIL,
            subject: "Download Request Approved In CRS",
            data: {
              message: `Download Request for user : ${token?.user.first_name} ${token?.user.last_name} is approved `,
              country: updateddownload.country?.name,
              centralOrState: updateddownload.state?.name,
              lawCategory: removeUnderscoreAndAddSpace(
                updateddownload.legislation?.law_category
              ),
              uploadedByUser: `${token?.user.first_name} ${token?.user.last_name}`,
            },
          };
        }
        const result = await sendEmail(emailOptions);
        console.log("Email sent successfully", result);
      } else {
        console.log("smtp not enable");
        console.error("SMTP is not present or disabled");
      }

      return NextResponse.json(updateddownload, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "download details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error creating download", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function PATCH(request: NextRequest) {
  const body: patchType = await request.json();
  console.log("request body: ", body);
  console.log("request body type: ", body.type); // patch | delete
  if (!body.id || !body.type) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  if (body.type == "patch" && !body.status) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  try {
    const downloadData = await prisma.download.findUnique({
      where: {
        id: body?.id,
      },
    });

    if (downloadData && downloadData.id) {
      let updateddownload = null;
      if (body.type == "delete") {
        updateddownload = await prisma.download.update({
          where: { id: downloadData.id },
          data: {
            deleted_at: new Date(), // Soft delete by setting isDeleted to true
            deleted: true,
          },
        });
      } else if (body.type == "patch") {
        updateddownload = await prisma.download.update({
          where: { id: downloadData.id },
          data: {
            status: body.status,
          },
        });
      } else {
        return NextResponse.json(
          { response: "Invalid request" },
          { status: 400 }
        );
      }

      return NextResponse.json(updateddownload, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "download details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error updating download", 500);
  } finally {
    await prisma.$disconnect();
  }
}
