import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { downloadModel } from "@/prisma/zod/download";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type download = z.infer<typeof downloadModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const downloadRow = await prisma.download.findUnique({
      where: { uuid: uuid, deleted: false },
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        approved: {
          select: {
            first_name: true,
            last_name: true,
            middle_name: true,
            mobile_no: true,
          },
        },
        country: {
          select: {
            name: true,
          },
        },
        state: {
          select: {
            name: true,
          },
        },
        legislation: {
          select: {
            name: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
        download_activity: {
          include: {
            compliance_activity: {
              select: {
                title: true,
              },
            },
          },
        },
      },
    });
    return NextResponse.json({ downloadRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading download", 500);
  } finally {
    await prisma.$disconnect();
  }
}
