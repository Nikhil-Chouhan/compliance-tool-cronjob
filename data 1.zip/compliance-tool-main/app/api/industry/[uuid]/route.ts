import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { industryModel } from "@/prisma/zod/industry";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type industry = z.infer<typeof industryModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const industryRow = await prisma.industry.findUnique({
      where: { uuid: uuid, deleted: false },
    });
    return NextResponse.json({ industryRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading industry", 500);
  } finally {
    await prisma.$disconnect();
  }
}
