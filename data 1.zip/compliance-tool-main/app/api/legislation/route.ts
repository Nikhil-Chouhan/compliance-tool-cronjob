import { prisma, Prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { legislationModel } from "@/prisma/zod/legislation";
import { z } from "zod";
import {
  generateUniqueCode,
  handleError,
  removeUnderscoreAndAddSpace,
} from "@/app/utils/modelUtils";
import { patchType } from "@/app/utils/typesUtils";
import { getToken } from "next-auth/jwt";
import { sendEmail, EmailOptions } from "@/app/utils/email";
import { error } from "console";

export type legislation = z.infer<typeof legislationModel>;
interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}
interface TokenContext {
  req: NextRequest;
}

export async function GET(request: NextRequest) {
  console.log(
    "request query--->",
    request.nextUrl.searchParams.get("filterName")
  );
  const queryParams = {
    page: request.nextUrl.searchParams.get("page"),
    pageSize: request.nextUrl.searchParams.get("pageSize"),
    filtername: request.nextUrl.searchParams.get("filterName"),
    filterid: request.nextUrl.searchParams.get("filterId"),
    filtersources: request.nextUrl.searchParams.get("filterSources"),
    filtercountry_id: request.nextUrl.searchParams.get("filterCountryId"),
    filterstate_id: request.nextUrl.searchParams.get("filterStateId"),
    filterindustry_id: request.nextUrl.searchParams.get("filterIndustryId"),
    filterapplies_to: request.nextUrl.searchParams.get("filterAppliesTo"),
    filterlaw_category: request.nextUrl.searchParams.get("filterLawCategory"),
    country_id: request.nextUrl.searchParams.get("country_id"),
    is_federal: request.nextUrl.searchParams.get("is_federal"),
    state_id: request.nextUrl.searchParams.get("state_id"),
  };

  const { page, pageSize } = queryParams;

  let offset = 0;
  let take: number | undefined = undefined;
  if (pageSize !== "-1") {
    take = Number(pageSize);
    offset = (Number(page) - 1) * Number(pageSize);
  }

  const filterProperties = [
    "filtername",
    "filterid",
    "filtersources",
    "filtercountry_id",
    "filterstate_id",
    "filterindustry_id",
    "filterapplies_to",
    "filterlaw_category",
  ];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};

      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      console.log("condition---> ", condition);
      acc.push(condition);
    }
    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.legislationWhereInput = {
    deleted: false,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.legislationWhereInput["AND"])
        : undefined,
    country_id: queryParams.country_id
      ? parseInt(queryParams.country_id, 10)
      : undefined,
    is_federal: queryParams.is_federal
      ? queryParams.is_federal === "true"
        ? true
        : false
      : undefined,
    state_id: queryParams.state_id
      ? parseInt(queryParams.state_id, 10)
      : undefined,
  };

  try {
    const legislationList = await prisma.legislation.findMany({
      where: prismaWhereClause,
      skip: offset,
      take: take,
      orderBy: {
        created_at: "desc", // or 'asc' for ascending order
      },
      include: {
        country: {
          select: {
            name: true,
          },
        },
        industry: {
          select: {
            name: true,
          },
        },
        state: {
          select: {
            name: true,
          },
        },
      },
    });

    const totalCount = await prisma.legislation.count({
      where: prismaWhereClause,
    });

    return NextResponse.json({ legislationList, totalCount }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);

  const body: legislation = await request.json();

  body.effective_date = body.effective_date
    ? new Date(body.effective_date)
    : null;
  body.updated_date = body.updated_date ? new Date(body.updated_date) : null;

  const result = legislationModel.safeParse(body);
  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const existRecord = await prisma.legislation.findFirst({
      where: {
        deleted: false,
        name: {
          equals: body.name,
          mode: "insensitive",
        },
      },
    });
    if (existRecord) {
      return NextResponse.json(
        { response: "Legislation name already exists!" },
        { status: 400 }
      );
    }

    const autoGeneratedCode = generateUniqueCode("legislation");
    const legislationRes = await prisma.legislation.create({
      data: {
        ...body,
        code: autoGeneratedCode,
      } as Prisma.legislationCreateInput,
      include: {
        country: true,
        state: true,
      },
    });

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "legislationemailTemplates",
        // to: token?.user?.email,
        to: process.env.ADMIN_EMAIL || "",
        subject: "New Legislations Added In CRS",
        message: "Following new legislations is added in CRS",
        data: {
          country: legislationRes.country?.name,
          centralOrState: legislationRes.state?.name,
          lawCategory: removeUnderscoreAndAddSpace(legislationRes.law_category),
          legislationName: legislationRes.name,
          uploadedByUser: `${token?.user.first_name} ${token?.user.last_name}`,
        },
      };
      const result = await sendEmail(emailOptions);
      console.log("Email sent successfully", result);
    } else {
      console.error("SMTP enable is not present or disabled.");
    }

    return NextResponse.json({ response: legislationRes }, { status: 200 });
  } catch (e) {
    return handleError(e, "error cretaing legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(request: NextRequest) {
  const body: legislation = await request.json();

  body.effective_date = body.effective_date
    ? new Date(body.effective_date)
    : null;
  body.updated_date = body.updated_date ? new Date(body.updated_date) : null;

  const result = legislationModel.safeParse(body);
  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const legislation = await prisma.legislation.findUnique({
      where: { id: body.id || undefined },
    });
    if (legislation && legislation.id) {
      const updatedlegislation = await prisma.legislation.update({
        where: { id: legislation.id },
        data: body as Prisma.legislationUpdateInput,
      });

      return NextResponse.json(updatedlegislation, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "legislation details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error creating legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}
// export async function DELETE(request: NextRequest)
export async function PATCH(request: NextRequest) {
  const body: patchType = await request.json();
  console.log("request body: ", body);
  console.log("request body: ", body.type); // patch | delete
  if (!body.id || !body.type) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  if (body.type == "patch" && !body.status) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  try {
    const legislationData = await prisma.legislation.findUnique({
      where: {
        id: body.id,
      },
    });

    if (legislationData && legislationData.id) {
      let updatedlegislation = null;
      if (body.type == "delete") {
        updatedlegislation = await prisma.legislation.update({
          where: { id: legislationData.id },
          data: {
            deleted_at: new Date(), // Soft delete by setting isDeleted to true
            deleted: true,
          },
        });
      } else if (body.type == "patch") {
        updatedlegislation = await prisma.legislation.update({
          where: { id: legislationData.id },
          data: {
            status: body.status,
          },
        });
      } else {
        return NextResponse.json(
          { response: "Invalid request" },
          { status: 400 }
        );
      }

      return NextResponse.json(updatedlegislation, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "legislation details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error updating legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}
