import { prisma } from "@/app/utils/prisma.server";
import {
  transformKeys,
  transformFields,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import * as XLSX from "xlsx";
import { legislationModel } from "@/prisma/zod/legislation";
import { z } from "zod";
import { country, state } from "@prisma/client";

export type legislation = z.infer<typeof legislationModel>;

export type ColumnType = {
  id: boolean;
  uuid: boolean;
  law_category: boolean;
  country_id: boolean;
  country: boolean;
  state_id: boolean;
  state: boolean;
  is_federal: boolean;
  code: boolean;
  name: boolean;
  sources: boolean;
  effective_date: boolean;
  updated_date: boolean;
  documents: boolean;
  industry_id: boolean;
  applies_to: boolean;
  status: boolean;
  created_at: boolean;
};

export async function GET() {
  try {
    const legislation: legislation =
      await prisma.legislation.findFirstOrThrow();

    if (!legislation) {
      return NextResponse.json(
        { error: "legislation not found" },
        { status: 404 }
      );
    }

    // Convert the legislation object to key-value pairs
    const legislationFields = transformKeys(legislation);

    return NextResponse.json({ fields: legislationFields }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}
export async function POST(request: NextRequest) {
  const body = await request.json();
  const fields = body.fields || [];

  const type = request.nextUrl.searchParams.get("type") || "csv";

  const filterName = request.nextUrl.searchParams.get("filterName");

  let whereClause = { deleted: false };
  if (filterName) {
    // Apply filtering based on the provided filterName
    whereClause = {
      ...whereClause,
      AND: [
        {
          name: { contains: filterName.toString(), mode: "insensitive" },
        },
      ],
    };
  }

  try {
    const selectedFields = fields.reduce(
      (columns: ColumnType, field: keyof ColumnType) => {
        if (field === "country_id") {
          columns.country = true;
        } else if (field === "state_id") {
          columns.state = true;
        } else {
          columns[field] = true;
        }
        return columns;
      },
      {}
    );

    const legislations = await prisma.legislation.findMany({
      select: selectedFields,
      where: whereClause,
    });

    const capitalizedWithSpaceFields = transformFields(fields);

    const legislationsWithCapitalizedAndSpacedKeys = legislations.map(
      (legislation) => {
        return fields.reduce(
          (columns: ColumnType, field: keyof ColumnType, index: number) => {
            const updatedKeys = capitalizedWithSpaceFields[index];
            if (field === "country_id") {
              const country = legislation?.country as unknown as country;
              columns[updatedKeys] = country?.name;
            } else if (field === "state_id") {
              const state = legislation?.state as unknown as state;
              columns[updatedKeys] = state?.name; // Assuming state relation exists and has an id
            } else {
              columns[updatedKeys] = legislation[field];
            }
            return columns;
          },
          {}
        );
      }
    );

    const ws = XLSX.utils.json_to_sheet(
      legislationsWithCapitalizedAndSpacedKeys,
      {
        header: capitalizedWithSpaceFields,
      }
    );

    // Create the Excel workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Legislation");

    // Write the Excel file to a buffer
    let workBookOutput;
    if (type == "xlsx") {
      workBookOutput = XLSX.write(wb, { bookType: "xlsx", type: "buffer" });
    } else {
      workBookOutput = XLSX.write(wb, { bookType: "csv", type: "buffer" });
    }
    const buffer = Buffer.from(workBookOutput);

    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "legislation-download.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "legislation-download.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error uploading legislation data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
