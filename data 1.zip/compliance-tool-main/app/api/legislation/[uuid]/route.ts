import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { legislationModel } from "@/prisma/zod/legislation";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type legislation = z.infer<typeof legislationModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const legislationRow = await prisma.legislation.findUnique({
      where: { uuid: uuid, deleted: false },
      include: {
        country: {
          select: {
            name: true,
          },
        },
        industry: {
          select: {
            name: true,
          },
        },
        state: {
          select: {
            name: true,
          },
        },
      },
    });
    return NextResponse.json({ legislationRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}
