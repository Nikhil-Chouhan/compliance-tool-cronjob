import { prisma } from "@/app/utils/prisma.server";
import {
  law_categoryEnum,
  law_category,
  applies,
  getKeyByValue,
  generateUniqueCode,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import fs from "fs";
import path from "path";
import * as XLSX from "xlsx";
import moment from "moment";
import { exportExcelWithHeaders } from "@/app/utils/exportXlHeaders";
import { z } from "zod";
import { legislationImportType } from "@/app/utils/typesUtils";
import { legislationModel } from "@/prisma/zod/legislation";
import { EmailOptions, sendEmail } from "@/app/utils/email";

export type legislation = z.infer<typeof legislationModel>;

const formatDate = (date: string) => moment(date, "DD-MM-YYYY").format();

export async function GET(request: NextRequest) {
  const type = request.nextUrl.searchParams.get("type") || "csv";
  try {
    const headers = [
      "law_category",
      "country",
      "is_federal",
      "state",
      "name",
      "sources",
      "effective_date",
      "updated_date",
      "industry",
      "applies_to",
    ]; // Define your headers here

    const buffer = exportExcelWithHeaders(headers, type);
    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "legislation-sample.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "legislation-sample.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error reading legislation", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const f = formData.get("file");

  if (!f) {
    return NextResponse.json(
      { response: "Invalid file uploaded." },
      { status: 400 }
    );
  }

  try {
    const file = f as File;

    // const destinationDirPath = path.join(
    //   process.cwd(),
    //   "/public/upload/legislation/importexcel"
    // );

    let destinationDirPath: string;
    if (process.env.APP_ENV && process.env.APP_ENV === "development") {
      destinationDirPath = path.join(process.cwd(), `/tmp/`);
    } else {
      destinationDirPath = "/tmp/";
    }
    console.log("DESTINATION PATH =============>", destinationDirPath);

    const fileArrayBuffer = await file.arrayBuffer();

    if (!fs.existsSync(destinationDirPath)) {
      fs.mkdirSync(destinationDirPath, { recursive: true });
    }

    const filename = `${Date.now()}-${file.name}`; // moment().format('YYYYMMDD-HHmmss') + "-" + file.name;
    const filePath = path.join(destinationDirPath, filename);
    await fs.writeFileSync(filePath, Buffer.from(fileArrayBuffer));

    // const workbook = XLSX.read(fileArrayBuffer, { type: "buffer" });
    const workbook = XLSX.read(filePath, { type: "file" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData: legislationImportType[] =
      XLSX.utils.sheet_to_json(worksheet);

    // Mapping object to define the fields you want to extract
    const fieldMappings = {
      country: "country",
      state: "state",
    };

    // Initialize an object to hold the unique values
    const uniqueData = Object.fromEntries(
      Object.values(fieldMappings).map((field) => [field, new Set()])
    );

    // Populate the uniqueData object in a single loop
    jsonData.forEach((record: legislationImportType) => {
      Object.keys(fieldMappings).forEach((field) => {
        uniqueData[field].add(record[field]);
      });
    });

    // Convert the unique sets to arrays of strings
    const uniqueDataArrays = Object.fromEntries(
      Object.entries(uniqueData).map(([field, set]) => [
        field,
        Array.from(set).map(String),
      ])
    );

    // Destructure the arrays if needed
    const { country: uniqueCountries, state: uniqueStates } = uniqueDataArrays;

    const countries = await prisma.country.findMany({
      where: {
        name: { in: uniqueCountries, mode: "insensitive" },
        deleted: false,
      },
    });

    const states = await prisma.state.findMany({
      where: {
        name: { in: uniqueStates, mode: "insensitive" },
        deleted: false,
      },
    });

    let saveCnt = 0,
      errorCnt = 0;

    const updatedJsonData = [];
    for (const record of jsonData) {
      let responseMsg = "";
      let industry = null;
      if (record.industry) {
        industry = await prisma.industry.findFirst({
          where: {
            deleted: false,
            name: {
              equals: record.industry,
              mode: "insensitive",
            },
          },
        });
        console.log("Industry Exists--->", industry);

        if (industry === null || industry === undefined) {
          const autoGeneratedCodeIndustry = generateUniqueCode("industry");
          industry = await prisma.industry.create({
            data: {
              code: autoGeneratedCodeIndustry,
              name: record.industry,
            },
          });
          console.log("Industry create--->", industry);
        }
      }
      console.log("Industry final for save--->", industry);

      const country = countries.find(
        (c) => c.name.toLowerCase() === record.country.toLowerCase()
      );
      if (!country) errorCnt++, (responseMsg = "Country Missing!");

      const state = states.find(
        (s) => s.name.toLowerCase() === record.state.toLowerCase()
      );
      if (!state) errorCnt++, (responseMsg = "State Missing!");

      const existingLegislation = await prisma.legislation.findFirst({
        where: { name: record.name ? record.name : undefined },
      });
      if (existingLegislation)
        errorCnt++, (responseMsg = "Legislation Name already exists!");

      // check valid date
      let effective_date = null;
      if (record.effective_date) {
        effective_date = formatDate(record.effective_date);
        if (effective_date == "Invalid date")
          errorCnt++,
            (responseMsg =
              "Invalid date format for effective_date use dd-mm-yyyy");
      }

      let updated_date = null;
      if (record.updated_date) {
        updated_date = formatDate(record.updated_date);
        if (updated_date == "Invalid date")
          errorCnt++,
            (responseMsg =
              "Invalid date format for updated_date use dd-mm-yyyy");
      }

      if (errorCnt == 0) {
        const autoGeneratedCode = generateUniqueCode("compliance_activity");
        const recordRes = await prisma.legislation.create({
          data: {
            code: autoGeneratedCode,
            law_category: getKeyByValue(
              law_category,
              record.law_category
            ) as law_categoryEnum,
            country_id: country?.id ? country?.id : 0,
            is_federal: record?.is_federal === "yes",
            state_id: record?.is_federal === "yes" ? null : state?.id,
            industry_id: industry?.id,
            name: record.name,
            sources: record.sources,
            effective_date: formatDate(record.effective_date),
            updated_date: formatDate(record.updated_date),
            applies_to: getKeyByValue(applies, record.applies_to) as applies,
            status: record?.status ? 1 : 2,
            documents: record?.documents || "",
          },
        });
        responseMsg = "Record Added.";
        if (recordRes && recordRes.id) {
          saveCnt++;
        }
      }

      updatedJsonData.push({
        ...record,
        response: responseMsg,
      });
    }

    // Exporting to Excel
    const ws = XLSX.utils.json_to_sheet(updatedJsonData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Responses");
    XLSX.writeFile(wb, filePath);

    const downloadPath =
      process.env.APP_URL + "/public/upload/legislation/importexcel" + filename;

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "bulkLegislationEmailTemplate",
        to: process.env.ADMIN_EMAIL || "",
        subject: "New Legislations Added In CRS",
        message: "Following new legislations are added in CRS",
        data: {
          saveCnt,
          errorCnt,
          downloadPath,
        },
      };
      const result = await sendEmail(emailOptions);
      console.log("Email sent successfully", result);
    }

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "bulkLegislationEmailTemplate",
        to: process.env.ADMIN_EMAIL,
        subject: "New Legislations Added In CRS",
        message: "Following new legislations are added in CRS",
        data: {
          saveCnt,
          errorCnt,
          downloadPath,
        },
      };
      const result = await sendEmail(emailOptions);
      console.log("Email sent successfully", result);
    } else {
      console.error("SMTP enable is not present or disabled.");
    }

    return NextResponse.json(
      { saveCnt: saveCnt, errorCnt: errorCnt, responseFile: downloadPath },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error uploading legislation data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
