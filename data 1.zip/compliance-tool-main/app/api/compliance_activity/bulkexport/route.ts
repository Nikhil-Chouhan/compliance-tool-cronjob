import { prisma } from "@/app/utils/prisma.server";
import {
  transformKeys,
  transformFields,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import * as XLSX from "xlsx";
import { compliance_activityModel } from "@/prisma/zod/compliance_activity";
import { z } from "zod";
import {
  Prisma,
  country,
  law_category,
  legislation,
  rule,
  state,
} from "@prisma/client";

export type compliance_activity = z.infer<typeof compliance_activityModel>;

interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}

export type ColumnType = {
  id: boolean;
  uuid: boolean;
  law_category: boolean;
  country: boolean;
  state: boolean;
  legislation: boolean;
  rule: boolean;
  legislation_id: boolean;
  rule_id: boolean;
  code: boolean;
  title: boolean;
  activity: boolean;
  reference: boolean;
  who: boolean;
  when: boolean;
  procedure: boolean;
  description: boolean;
  frequency: boolean;
  form_no: boolean;
  due_date: boolean;
  compliance_type: boolean;
  authority: boolean;
  exemption_criteria: boolean;
  event_id: boolean;
  event_sub_id: boolean;
  event_question_id: boolean;
  implications: boolean;
  imprison_duration: boolean;
  imprison_applies_to: boolean;
  currency: boolean;
  fine: boolean;
  fine_per_day: boolean;
  impact: boolean;
  impact_on_unit: boolean;
  impact_on_organization: boolean;
  linked_activity_ids: boolean;
  reference_link: boolean;
  sources: boolean;
  updated_date: boolean;
  documents: boolean;
  status: boolean;
  created_at: boolean;
  deleted_at: boolean;
  updated_at: boolean;
  event: boolean;
  event_sub: boolean;
  event_question: boolean;
  download_activity: boolean;
};

export async function GET() {
  try {
    const compliance_activity: compliance_activity =
      await prisma.compliance_activity.findFirstOrThrow();

    if (!compliance_activity) {
      return NextResponse.json(
        { error: "compliance_activity not found" },
        { status: 404 }
      );
    }

    // Convert the compliance_activity object to key-value pairs
    const compliance_activityFields = transformKeys(compliance_activity);

    return NextResponse.json(
      { fields: compliance_activityFields },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error reading compliance_activity", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const fields = body.fields || [];

  const type = request.nextUrl.searchParams.get("type") || "csv";

  const queryParams = {
    filterid: request.nextUrl.searchParams.get("filterId"),
    filterlegislation_id: request.nextUrl.searchParams.get(
      "filterLegislationId"
    ),
    filterrule_id: request.nextUrl.searchParams.get("filterRuleId"),
    filtertitle: request.nextUrl.searchParams.get("filterTitles"),
    filteractivity: request.nextUrl.searchParams.get("filterActivity"),
    filterreference: request.nextUrl.searchParams.get("filterReference"),
    filterwho: request.nextUrl.searchParams.get("filterWho"),
    filterwhen: request.nextUrl.searchParams.get("filterWhen"),
    filterprocedure: request.nextUrl.searchParams.get("filterProcedure"),
    filterdescription: request.nextUrl.searchParams.get("filterDescription"),
    filterform_no: request.nextUrl.searchParams.get("filterFormNo"),
    filtercompliance_type: request.nextUrl.searchParams.get(
      "filterComplianceType"
    ),
    filterauthority: request.nextUrl.searchParams.get("filterAuthority"),
    filterexemption_criteria: request.nextUrl.searchParams.get(
      "filterExemptionCriteria"
    ),
    filterevent_id: request.nextUrl.searchParams.get("filterEventId"),
    filterevent_sub_id: request.nextUrl.searchParams.get("filterEventSubId"),
    filterevent_question_id: request.nextUrl.searchParams.get(
      "filterEventQuestionId"
    ),
    filterimplications: request.nextUrl.searchParams.get("filterImplications"),
    filterreference_link: request.nextUrl.searchParams.get(
      "filterReferenceLink"
    ),
    filtersources: request.nextUrl.searchParams.get("filterSources"),
  };

  const filterProperties = [
    "filterid",
    "filterlegislation_id",
    "filterrule_id",
    "filtertitle",
    "filteractivity",
    "filterreference",
    "filterwho",
    "filterwhen",
    "filterdescription",
    "filterprocedure",
    // frequency enum
    "filterform_no",
    "filtercompliance_type",
    "filterauthority",
    "filterexemption_criteria",
    "filterevent_id",
    "filterevent_sub_id",
    "filterevent_question_id",
    "filterimplications",
    // imprison_applies_to enum
    "filterreference_link",
    "filtersources",
  ];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};
      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      acc.push(condition);
    }
    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.compliance_activityWhereInput = {
    deleted: false,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.compliance_activityWhereInput["AND"])
        : undefined,
  };

  try {
    const compliance_activitys = await prisma.compliance_activity.findMany({
      include: {
        legislation: {
          select: {
            id: true,
            name: true,
            law_category: true,
            country: {
              select: {
                name: true,
              },
            },
            state: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
      },
      where: prismaWhereClause,
    });
    // console.log("compliance======>", compliance_activitys);

    const appendfields = ["law_category", "country", "state"];
    fields.splice(2, 0, ...appendfields);
    console.log("<---fields-->", fields);

    const capitalizedWithSpaceFields = transformFields(fields);
    console.log(
      "Capitalized Wtih Space Fields =====> ",
      capitalizedWithSpaceFields
    );

    const compliance_activitysWithCapitalizedAndSpacedKeys =
      compliance_activitys.map((compliance_activity) => {
        return fields.reduce(
          (columns: ColumnType, field: keyof ColumnType, index: number) => {
            const updatedKeys = capitalizedWithSpaceFields[index];
            if (field === "legislation_id") {
              const legislation =
                compliance_activity.legislation as unknown as legislation;
              columns[updatedKeys] = legislation.name;
            } else if (field === "rule_id") {
              const rule = compliance_activity.rule as unknown as rule;
              columns[updatedKeys] = rule.name;
            } else if (field === "country") {
              const country = compliance_activity.legislation?.country
                ?.name as unknown as country;
              // console.log("country", country, "<----");
              columns[updatedKeys] = country;
            } else if (field === "state") {
              const state = compliance_activity.legislation?.state
                ?.name as unknown as state;
              // console.log("state", state, "<----");
              columns[updatedKeys] = state;
            } else if (field === "law_category") {
              const law_category = compliance_activity.legislation
                ?.law_category as unknown as law_category;
              // console.log("law category", law_category, "<----");
              columns[updatedKeys] = law_category;
            } else {
              columns[updatedKeys] = compliance_activity[field];
            }
            return columns;
          },
          {}
        );
      });

    const ws = XLSX.utils.json_to_sheet(
      compliance_activitysWithCapitalizedAndSpacedKeys,
      {
        header: capitalizedWithSpaceFields,
      }
    );

    // Create the Excel workbook
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "compliance_activity");

    // Write the Excel file to a buffer
    let workBookOutput;
    if (type == "xlsx") {
      workBookOutput = XLSX.write(wb, { bookType: "xlsx", type: "buffer" });
    } else {
      workBookOutput = XLSX.write(wb, { bookType: "csv", type: "buffer" });
    }
    const buffer = Buffer.from(workBookOutput);

    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "compliance_activity-download.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "compliance_activity-download.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error uploading compliance_activity data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
