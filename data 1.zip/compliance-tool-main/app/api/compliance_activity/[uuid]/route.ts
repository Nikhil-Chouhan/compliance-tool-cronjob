import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { compliance_activityModel } from "@/prisma/zod/compliance_activity";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type compliance_activity = z.infer<typeof compliance_activityModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const compliance_activityRow = await prisma.compliance_activity.findUnique({
      where: { uuid: uuid, deleted: false },
      include: {
        event: {
          select: {
            name: true,
          },
        },
        event_question: {
          select: {
            name: true,
          },
        },
        event_sub: {
          select: {
            name: true,
          },
        },
        legislation: {
          select: {
            id: true,
            name: true,
            law_category: true,
            country: true,
            state: true,
            is_federal: true,
            industry: true,
          },
        },
        rule: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });
    return NextResponse.json({ compliance_activityRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading compliance_activity", 500);
  }
}
