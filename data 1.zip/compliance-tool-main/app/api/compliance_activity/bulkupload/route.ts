import { prisma } from "@/app/utils/prisma.server";
import {
  frequency,
  impact,
  getKeyByValue,
  generateUniqueCode,
  frequencyEnum,
  impactEnum,
  imprisonment_forEnum,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import fs from "fs";
import path from "path";
import * as XLSX from "xlsx";
import { exportExcelWithHeaders } from "@/app/utils/exportXlHeaders";
import { compliance_activityModel } from "@/prisma/zod/compliance_activity";
import { z } from "zod";
import { activityImportType } from "@/app/utils/typesUtils";
import { EmailOptions, sendEmail } from "@/app/utils/email";

export type compliance_activity = z.infer<typeof compliance_activityModel>;

export async function GET(request: NextRequest) {
  const type = request.nextUrl.searchParams.get("type") || "csv";
  try {
    const headers = [
      // "law_category",
      // "country",
      // "state",
      "legislation",
      "rule",
      "title",
      "activity",
      "reference",
      "who",
      "when",
      "procedure",
      "description",
      "frequency",
      "form_no",
      "compliance_type",
      "authority",
      "exemption_criteria",
      "event",
      "event_sub",
      "event_question",
      "implications",
      "imprison_duration",
      "imprison_applies_to",
      "fine",
      "fine_per_day",
      "impact",
      "impact_on_unit",
      "impact_on_organization",
      "linked_activity_ids",
      "reference_link",
      "sources",
      "documents",
    ]; // Define your headers here

    const buffer = exportExcelWithHeaders(headers, type);
    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "compliance_activity-sample.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "compliance_activity-sample.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error reading compliance_activity", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const f = formData.get("file");

  if (!f) {
    return NextResponse.json(
      { response: "Invalid file uploaded." },
      { status: 400 }
    );
  }

  try {
    const file = f as File;

    // const destinationDirPath = path.join(
    //   process.cwd(),
    //   "/public/upload/compliance_activity/importexcel"
    // );

    let destinationDirPath: string;
    if (process.env.APP_ENV && process.env.APP_ENV === "development") {
      destinationDirPath = path.join(process.cwd(), `/tmp/`);
    } else {
      destinationDirPath = "/tmp/";
    }
    console.log("DESTINATION PATH =============>", destinationDirPath);
    const fileArrayBuffer = await file.arrayBuffer();

    if (!fs.existsSync(destinationDirPath)) {
      fs.mkdirSync(destinationDirPath, { recursive: true });
    }

    const filename = `${Date.now()}-${file.name}`; // moment().format('YYYYMMDD-HHmmss') + "-" + file.name;
    const filePath = path.join(destinationDirPath, filename);
    fs.writeFileSync(filePath, Buffer.from(fileArrayBuffer));

    // const workbook = XLSX.read(fileArrayBuffer, { type: "buffer" });
    const workbook = XLSX.read(filePath, { type: "file" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData: activityImportType[] = XLSX.utils.sheet_to_json(worksheet);

    // Mapping object to define the fields you want to extract
    const fieldMappings = {
      legislation: "legislation",
      rule: "rule",
    };

    // Initialize an object to hold the unique values
    const uniqueData = Object.fromEntries(
      Object.values(fieldMappings).map((field) => [field, new Set()])
    );

    // Populate the uniqueData object in a single loop
    jsonData.forEach((record: activityImportType) => {
      Object.keys(fieldMappings).forEach((field) => {
        uniqueData[field].add(record[field]);
      });
    });

    // Convert the unique sets to arrays of strings
    const uniqueDataArrays = Object.fromEntries(
      Object.entries(uniqueData).map(([field, set]) => [
        field,
        Array.from(set).map(String),
      ])
    );

    // Destructure the arrays if needed
    const { legislation: uniqueLegislation, rule: uniqueRules } =
      uniqueDataArrays;

    const legislations = await prisma.legislation.findMany({
      where: { name: { in: uniqueLegislation, mode: "insensitive" } },
    });

    const rules = await prisma.rule.findMany({
      where: { name: { in: uniqueRules, mode: "insensitive" } },
    });

    let saveCnt = 0,
      errorCnt = 0;
    const updatedJsonData = [];
    for (const record of jsonData) {
      let responseMsg = "";
      const legislation = legislations.find(
        (s) => s.name.toLowerCase() === record.legislation.toLowerCase()
      );
      if (!legislation) errorCnt++, (responseMsg = "Legislation Missing!");

      const rule = rules.find(
        (s) => s.name.toLowerCase() === record.rule.toLowerCase()
      );
      if (!rule) errorCnt++, (responseMsg = "Rule Missing!");

      let event = null;
      if (record.event) {
        event = await prisma.event.findFirst({
          where: {
            deleted: false,
            name: {
              equals: record.event,
              mode: "insensitive",
            },
          },
        });
        console.log("event ====>", event);
        if (event === null || event === undefined) {
          console.log("event to save====>", event);
          const autoGeneratedCodeEvent = generateUniqueCode("event");
          event = await prisma.event.create({
            data: {
              code: autoGeneratedCodeEvent,
              name: record.event,
            },
          });
        }
      }

      let eventsub = null;
      if (record.event_sub) {
        eventsub = await prisma.event_sub.findFirst({
          where: {
            event_id: event?.id,
            deleted: false,
            name: {
              equals: record.event_sub,
              mode: "insensitive",
            },
          },
        });
        console.log("event sub =====>", eventsub);
        if (event && (eventsub === null || eventsub === undefined)) {
          console.log("event sub Save=====>", eventsub);
          const autoGeneratedCodeEvent = generateUniqueCode("event_sub");
          eventsub = await prisma.event_sub.create({
            data: {
              code: autoGeneratedCodeEvent,
              event_id: event?.id,
              name: record.event_sub,
            },
          });
        }
      }
      let eventquestion = null;
      if (record.event_question) {
        eventquestion = await prisma.event_question.findFirst({
          where: {
            event_id: event?.id,
            event_sub_id: eventsub?.id,
            deleted: false,
            name: {
              equals: record.event_question,
              mode: "insensitive",
            },
          },
        });
        if (
          event &&
          eventsub &&
          (eventquestion === null || eventquestion === undefined)
        ) {
          const autoGeneratedCodeEventQuestion =
            generateUniqueCode("event_question");
          eventquestion = await prisma.event_question.create({
            data: {
              code: autoGeneratedCodeEventQuestion,
              event_id: event?.id,
              event_sub_id: eventsub?.id,
              name: record.event_question,
            },
          });
        }
      }

      const existingCompliance_activity =
        await prisma.compliance_activity.findFirst({
          where: { title: record.title },
        });
      if (existingCompliance_activity)
        errorCnt++, (responseMsg = "Title already exists!");

      if (errorCnt == 0) {
        const autoGeneratedCode = generateUniqueCode("compliance_activity");
        const recordRes = await prisma.compliance_activity.create({
          data: {
            legislation_id: legislation?.id,
            rule_id: rule?.id,
            code: autoGeneratedCode,
            title: record.title,
            activity: record.activity,
            reference: record?.reference,
            who: record?.who,
            when: record?.when,
            procedure: record?.procedure,
            description: record?.description,
            frequency: record?.frequency
              ? (getKeyByValue(frequency, record.frequency) as frequencyEnum)
              : null,
            form_no: record.form_no,
            compliance_type: record.compliance_type,
            authority: record.authority,
            exemption_criteria: record.exemption_criteria,
            event_id: event?.id,
            event_sub_id: eventsub?.id,
            event_question_id: eventquestion?.id,
            implications: record.implications,
            imprison_duration: record?.imprison_duration?.toString(),
            imprison_applies_to:
              record?.imprison_applies_to as imprisonment_forEnum,
            fine: (record?.fine || null)?.toString(),
            fine_per_day: record?.imprison_applies_to,
            impact: getKeyByValue(impact, record.impact) as impactEnum,
            impact_on_unit: record?.impact_on_unit,
            impact_on_organization: record?.impact_on_organization,
            linked_activity_ids: record?.linked_activity_ids
              ? record.linked_activity_ids.toString()
              : null,
            reference_link: record.reference_link,
            sources: record.sources || "",
            documents: record.documents || "",
          },
        });
        responseMsg = "Record Added.";
        if (recordRes && recordRes.id) {
          saveCnt++;
        }
      }

      updatedJsonData.push({
        ...record,
        response: responseMsg,
      });
      console.log("updated json data ==========>", updatedJsonData);
      // return {
      //   ...record,
      //   response: responseMsg,
      // };
    }

    // const updatedJsonDataPromises = jsonData.map(
    //   async (record: activityImportType) => {}
    // );

    // const updatedJsonData = await Promise.all(updatedJsonDataPromises);
    // Exporting to Excel
    const ws = XLSX.utils.json_to_sheet(updatedJsonData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Responses");
    XLSX.writeFile(wb, filePath);

    const downloadPath =
      process.env.APP_URL +
      "/public/upload/compliance_activity/importexcel" +
      filename;

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "bulkUploadComplianceActivityEmailTemplate",
        to: process.env.ADMIN_EMAIL || "",
        subject: "New Compliance Activity Added In CRS",
        message: "Following New Compliance Activity Are Added In CRS",
        data: {
          saveCnt,
          errorCnt,
          downloadPath,
        },
      };
      const result = await sendEmail(emailOptions);
      console.log("Email sent successfully", result);
    } else {
      console.error("SMTP enable is not present or disabled.");
    }

    return NextResponse.json(
      { saveCnt: saveCnt, errorCnt: errorCnt, responseFile: downloadPath },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error uploading compliance_activity data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
