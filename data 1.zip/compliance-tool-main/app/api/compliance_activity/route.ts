import { Prisma, prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { compliance_activityModel } from "@/prisma/zod/compliance_activity";
import { z } from "zod";
import {
  generateUniqueCode,
  handleError,
  removeUnderscoreAndAddSpace,
} from "@/app/utils/modelUtils";
import { patchType } from "@/app/utils/typesUtils";
import { EmailOptions, sendEmail } from "@/app/utils/email";
import { getToken } from "next-auth/jwt";

export type compliance_activity = z.infer<typeof compliance_activityModel>;

interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}

interface TokenContext {
  req: NextRequest;
}
export async function GET(request: NextRequest) {
  const queryParams = {
    page: request.nextUrl.searchParams.get("page"),
    pageSize: request.nextUrl.searchParams.get("pageSize"),
    filterid: request.nextUrl.searchParams.get("filterId"),
    filtername: request.nextUrl.searchParams.get("filterName"),
    filterlegislation_id: request.nextUrl.searchParams.get(
      "filterLegislationId"
    ),
    filterrule_id: request.nextUrl.searchParams.get("filterRuleId"),
    filtertitle: request.nextUrl.searchParams.get("filterTitles"),
    filteractivity: request.nextUrl.searchParams.get("filterActivity"),
    filterreference: request.nextUrl.searchParams.get("filterReference"),
    filterwho: request.nextUrl.searchParams.get("filterWho"),
    filterwhen: request.nextUrl.searchParams.get("filterWhen"),
    filterprocedure: request.nextUrl.searchParams.get("filterProcedure"),
    filterdescription: request.nextUrl.searchParams.get("filterDescription"),
    filterform_no: request.nextUrl.searchParams.get("filterFormNo"),
    filtercompliance_type: request.nextUrl.searchParams.get(
      "filterComplianceType"
    ),
    filterauthority: request.nextUrl.searchParams.get("filterAuthority"),
    filterexemption_criteria: request.nextUrl.searchParams.get(
      "filterExemptionCriteria"
    ),
    filterevent_id: request.nextUrl.searchParams.get("filterEventId"),
    filterevent_sub_id: request.nextUrl.searchParams.get("filterEventSubId"),
    filterevent_question_id: request.nextUrl.searchParams.get(
      "filterEventQuestionId"
    ),
    filterimplications: request.nextUrl.searchParams.get("filterImplications"),
    filterreference_link: request.nextUrl.searchParams.get(
      "filterReferenceLink"
    ),
    filtersources: request.nextUrl.searchParams.get("filterSources"),
  };
  const { page, pageSize } = queryParams;

  let offset = 0;
  let take = undefined;
  if (pageSize != "-1") {
    take = Number(pageSize);
    offset = (Number(page) - 1) * Number(pageSize);
  }
  const filterProperties = [
    "filterid",
    "filtername",
    "filtersources",
    "filterlegislation_id",
    "filterrule_id",
    "filtertitle",
    "filteractivity",
    "filterreference",
    "filterwho",
    "filterwhen",
    "filterdescription",
    "filterprocedure",
    //frequency enum
    "filterform_no",
    "filtercompliance_type",
    "filterauthority",
    "filterexemption_criteria",
    "filterevent_id",
    "filterevent_sub_id",
    "filterevent_question_id",
    "filterimplications",
    // imprison_applies_to enum
    "filterreference_link",
  ];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};
      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      acc.push(condition);
    }
    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.compliance_activityWhereInput = {
    deleted: false,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.compliance_activityWhereInput["AND"])
        : undefined,
  };

  try {
    const compliance_activityList = await prisma.compliance_activity.findMany({
      where: prismaWhereClause,
      skip: offset,
      take: take,
      orderBy: {
        created_at: "desc", // or 'asc' for ascending order
      },
      include: {
        event: {
          select: {
            name: true,
          },
        },
        event_question: {
          select: {
            name: true,
          },
        },
        event_sub: {
          select: {
            name: true,
          },
        },
        legislation: {
          select: {
            id: true,
            name: true,
            law_category: true,
            country: true,
            state: true,
            is_federal: true,
            industry: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
      },
    });

    const totalCount = await prisma.compliance_activity.count({
      where: prismaWhereClause,
    });

    return NextResponse.json(
      { compliance_activityList, totalCount },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error reading compliance_activity", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);

  const body: compliance_activity = await request.json();

  console.log("request body: ", body);

  const result = compliance_activityModel.safeParse(body);

  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const existRecord = await prisma.compliance_activity.findFirst({
      where: {
        deleted: false,
        title: {
          contains: body.title,
          mode: "insensitive",
        },
      },
    });
    if (existRecord) {
      return NextResponse.json(
        { response: "Compliance activty name already exists!" },
        { status: 400 }
      );
    }
    const autoGeneratedCode = generateUniqueCode("compliance activty");
    const compliance_activityRes = await prisma.compliance_activity.create({
      data: {
        ...body,
        code: autoGeneratedCode,
      } as Prisma.compliance_activityCreateInput,
      include: {
        legislation: {
          select: {
            country: true,
            state: true,
            is_federal: true,
            name: true,

            law_category: true,
          },
        },
        rule: {
          select: {
            name: true,
          },
        },
      },
    });

    if (process.env.SMTP_ENABLE === "enable") {
      const emailOptions: EmailOptions = {
        template: "ComplianceActivityEmailTemplates",
        to: process.env.ADMIN_EMAIL || "",
        subject: "New Legislations Added In CRS",
        message: "Following new legislations are added in CRS",
        data: {
          country: compliance_activityRes.legislation?.country?.name,
          centralOrState:
            compliance_activityRes.legislation?.state?.name ||
            compliance_activityRes.legislation?.is_federal,
          lawCategory: removeUnderscoreAndAddSpace(
            compliance_activityRes.legislation?.law_category || ""
          ),
          legislationName: compliance_activityRes.legislation?.name,
          ruleName: compliance_activityRes.rule?.name,
          complianceActivityCount: 1,
          uploadedByUser: `${token?.user.first_name} ${token?.user.last_name}`,
        },
      };
      const result = await sendEmail(emailOptions);
      console.log("Email sent successfully", result);
    } else {
      console.error("SMTP enable is not present or disabled.");
    }

    return NextResponse.json(
      { response: compliance_activityRes },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error creating Compliance Activity ", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(request: NextRequest) {
  const body: compliance_activity = await request.json();
  console.log("request body: ", body);

  const result = compliance_activityModel.safeParse(body);
  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const compliance_activity = await prisma.compliance_activity.findUnique({
      where: { id: body.id || undefined },
    });
    if (compliance_activity && compliance_activity.id) {
      const updatedcompliance_activity =
        await prisma.compliance_activity.update({
          where: { id: compliance_activity.id },
          data: body as Prisma.compliance_activityUpdateInput,
        });

      return NextResponse.json(updatedcompliance_activity, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "compliance_activity details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error creating compliance_activity", 500);
  } finally {
    await prisma.$disconnect();
  }
}

// export async function DELETE(request: NextRequest)
export async function PATCH(request: NextRequest) {
  const body: patchType = await request.json();
  console.log("request body: ", body);
  console.log("request body: ", body.type); // patch | delete
  if (!body.id || !body.type) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  if (body.type == "patch" && !body.status) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  try {
    const compliance_activityData = await prisma.compliance_activity.findUnique(
      {
        where: {
          id: body.id,
        },
      }
    );

    if (compliance_activityData && compliance_activityData.id) {
      let updatedcompliance_activity = null;
      if (body.type == "delete") {
        updatedcompliance_activity = await prisma.compliance_activity.update({
          where: { id: compliance_activityData.id },
          data: {
            deleted_at: new Date(), // Soft delete by setting isDeleted to true
            deleted: true,
          },
        });
      } else if (body.type == "patch") {
        updatedcompliance_activity = await prisma.compliance_activity.update({
          where: { id: compliance_activityData.id },
          data: {
            status: body.status,
          },
        });
      } else {
        return NextResponse.json(
          { response: "Invalid request" },
          { status: 400 }
        );
      }

      return NextResponse.json(updatedcompliance_activity, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "compliance_activity details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error updating compliance_activity", 500);
  } finally {
    await prisma.$disconnect();
  }
}
