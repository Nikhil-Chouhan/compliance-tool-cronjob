import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { entityModel } from "@/prisma/zod/entity";
import { z } from "zod";
import { handleError } from "@/app/utils/modelUtils";

export type entity = z.infer<typeof entityModel>;

export async function GET(request: NextRequest) {
  const pathname = request.nextUrl.pathname;
  // console.log("request pathname ----> ", pathname);
  const uuid = pathname.split("/").pop();

  try {
    const entityRow = await prisma.entity.findUnique({
      where: { uuid: uuid, deleted: false },
    });
    return NextResponse.json({ entityRow }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading entity", 500);
  }
}
