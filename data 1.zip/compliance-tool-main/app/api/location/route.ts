import { prisma, Prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { locationModel } from "@/prisma/zod/location";
import { z } from "zod";
import { patchType } from "@/app/utils/typesUtils";
import { handleError } from "@/app/utils/modelUtils";

export type location = z.infer<typeof locationModel>;

interface Condition {
  [key: string]: string | number | { contains: string; mode: string };
}

export async function GET(request: NextRequest) {
  console.log(
    "request query--->",
    request.nextUrl.searchParams.get("filterName")
  );
  const queryParams = {
    page: request.nextUrl.searchParams.get("page"),
    pageSize: request.nextUrl.searchParams.get("pageSize"),
    filtername: request.nextUrl.searchParams.get("filterName"),
    filterid: request.nextUrl.searchParams.get("filterId"),
    filterentity_id: request.nextUrl.searchParams.get("filterEntityId"),
    entity_id: request.nextUrl.searchParams.get("entity_id"),
  };

  const { page, pageSize } = queryParams;

  let offset = 0;
  let take: number | undefined = undefined;
  if (pageSize !== "-1") {
    take = Number(pageSize);
    offset = (Number(page) - 1) * Number(pageSize);
  }

  const filterProperties = ["filterid", "filtername", "filterentity_id"];

  const conditions: Condition[] = filterProperties.reduce((acc, property) => {
    const paramValue = queryParams[property as keyof typeof queryParams];
    if (paramValue) {
      const condition: Condition = {};

      if (!isNaN(Number(paramValue))) {
        condition[property.substring(6)] = parseInt(paramValue, 10);
      } else {
        condition[property.substring(6)] = {
          contains: paramValue,
          mode: "insensitive",
        };
      }
      console.log("condition---> ", condition);
      acc.push(condition);
    }

    return acc;
  }, [] as Condition[]);

  const prismaWhereClause: Prisma.locationWhereInput = {
    deleted: false,
    AND:
      conditions.length > 0
        ? (conditions as Prisma.locationWhereInput["AND"])
        : undefined,
    entity_id: queryParams.entity_id
      ? parseInt(queryParams.entity_id, 10)
      : undefined,
  };

  try {
    const locationList = await prisma.location.findMany({
      where: prismaWhereClause,
      skip: offset,
      take: take,
      orderBy: {
        created_at: "desc", // or 'asc' for ascending order
      },
      include: {
        entity: {
          select: {
            name: true,
          },
        },
      },
    });

    const totalCount = await prisma.location.count({
      where: prismaWhereClause,
    });

    return NextResponse.json({ locationList, totalCount }, { status: 200 });
  } catch (e) {
    return handleError(e, "error reading location", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function POST(request: NextRequest) {
  const body: location = await request.json();
  console.log("request body: ", body);

  const result = locationModel.safeParse(body);

  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const existRecord = await prisma.location.findFirst({
      where: {
        deleted: false,
        name: {
          equals: body.name,
          mode: "insensitive",
        },
      },
    });
    if (existRecord) {
      return NextResponse.json(
        { response: "Location name already exists!" },
        { status: 400 }
      );
    }

    const locationRes = await prisma.location.create({
      data: body as Prisma.locationCreateInput,
    });
    return NextResponse.json({ response: locationRes }, { status: 200 });
  } catch (e) {
    return handleError(e, "error creating location", 500);
  } finally {
    await prisma.$disconnect();
  }
}

export async function PUT(request: NextRequest) {
  const body: location = await request.json();
  console.log("request body: ", body);

  const result = locationModel.safeParse(body);
  if (!result.success) {
    const { errors } = result.error;

    return NextResponse.json(
      { response: "Invalid request", errors },
      { status: 400 }
    );
  }

  try {
    const location = await prisma.location.findUnique({
      where: { id: body.id || undefined },
    });
    if (location && location.id) {
      const updatedlocation = await prisma.location.update({
        where: { id: location.id },
        data: body as Prisma.locationUpdateInput,
      });

      return NextResponse.json(updatedlocation, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "location details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error creating location", 500);
  } finally {
    await prisma.$disconnect();
  }
}
// export async function DELETE(request: NextRequest)
export async function PATCH(request: NextRequest) {
  const body: patchType = await request.json();
  console.log("request body: ", body);
  console.log("request body: ", body.type); // patch | delete
  if (!body.id || !body.type) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  if (body.type == "patch" && !body.status) {
    return NextResponse.json(
      { response: "Invalid request, kindly check your request!" },
      { status: 400 }
    );
  }

  try {
    const locationData = await prisma.location.findUnique({
      where: {
        id: body.id,
      },
    });

    if (locationData && locationData.id) {
      let updatedlocation = null;
      if (body.type == "delete") {
        updatedlocation = await prisma.location.update({
          where: { id: locationData.id },
          data: {
            deleted_at: new Date(), // Soft delete by setting isDeleted to true
            deleted: true,
          },
        });
      } else if (body.type == "patch") {
        updatedlocation = await prisma.location.update({
          where: { id: locationData.id },
          data: {
            status: body.status,
          },
        });
      } else {
        return NextResponse.json(
          { response: "Invalid request" },
          { status: 400 }
        );
      }

      return NextResponse.json(updatedlocation, { status: 200 });
    } else {
      return NextResponse.json(
        { response: "location details not found!" },
        { status: 404 }
      );
    }
  } catch (e) {
    return handleError(e, "error updating location", 500);
  } finally {
    await prisma.$disconnect();
  }
}
