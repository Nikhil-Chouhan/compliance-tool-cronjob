import { prisma } from "@/app/utils/prisma.server";
import {
  law_category,
  applies,
  getKeyByValue,
  handleError,
} from "@/app/utils/modelUtils";
import { NextResponse, NextRequest } from "next/server";
import fs from "fs/promises";
import { existsSync } from "fs";
import path from "path";
import * as XLSX from "xlsx";
import moment from "moment";
import { exportExcelWithHeaders } from "@/app/utils/exportXlHeaders";
import { downloadModel } from "@/prisma/zod/download";
import { z } from "zod";
import { time } from "console";

export type download = z.infer<typeof downloadModel>;

export async function GET(request: NextRequest) {
  const type = request.nextUrl.searchParams.get("type") || "csv";
  try {
    const headers = [
      "code",
      "legislation",
      "law_category",
      "country",
      "state",
      "name",
      "sources",
      "effective_date",
      "updated_date",
      "industry",
      "applies_to",
      "status",
      "applicability",
    ]; // Define your headers here

    const buffer = exportExcelWithHeaders(headers, type);
    const res = new NextResponse(buffer);

    let filename;
    if (type == "xlsx") {
      filename = "download-sample.xlsx";
      res.headers.set(
        "Content-Type",
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
      );
    } else {
      filename = "download-sample.csv";
      res.headers.set("Content-Type", "text/csv");
    }
    res.headers.set("Content-Disposition", "attachment; filename=" + filename);

    return res;
  } catch (e) {
    return handleError(e, "error reading download", 500);
  }
}

export async function POST(request: NextRequest) {
  const formData = await request.formData();
  const f = formData.get("file");

  if (!f) {
    return NextResponse.json(
      { response: "Invalid file uploaded." },
      { status: 400 }
    );
  }

  try {
    const file = f as File;

    const destinationDirPath = path.join(
      process.cwd(),
      "public/upload/download/importexcel"
    );

    const fileArrayBuffer = await file.arrayBuffer();

    if (!existsSync(destinationDirPath)) {
      await fs.mkdir(destinationDirPath, { recursive: true });
    }

    const filename = `${Date.now()}-${file.name}`; // moment().format('YYYYMMDD-HHmmss') + "-" + file.name;
    const filePath = path.join(destinationDirPath, filename);
    await fs.writeFile(filePath, Buffer.from(fileArrayBuffer));

    // const workbook = XLSX.read(fileArrayBuffer, { type: "buffer" });
    const workbook = XLSX.read(filePath, { type: "file" });
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(worksheet);

    const formatDate = (date: string) => moment(date, "DD-MM-YYYY").format();

    const uniqueIndustries = [
      ...new Set(jsonData.map((record) => record.industry)),
    ];

    const uniqueCountries = [
      ...new Set(jsonData.map((record) => record.country)),
    ];

    const uniqueStates = [...new Set(jsonData.map((record) => record.state))];

    const uniqueLegislation = [
      ...new Set(jsonData.map((record) => record.legislation)),
    ];

    const industries = await prisma.industry.findMany({
      where: { name: { in: uniqueIndustries, mode: "insensitive" } },
    });

    const countries = await prisma.country.findMany({
      where: { name: { in: uniqueCountries, mode: "insensitive" } },
    });

    const states = await prisma.state.findMany({
      where: { name: { in: uniqueStates, mode: "insensitive" } },
    });

    const legislations = await prisma.legislation.findMany({
      where: { name: { in: uniqueLegislation, mode: "insensitive" } },
    });

    let saveCnt = 0,
      errorCnt = 0;
    const updatedJsonDataPromises = jsonData.map(async (record: any) => {
      let responseMsg: string;

      const industry = industries.find(
        (ind) => ind.name.toLowerCase() === record.industry.toLowerCase()
      );
      if (!industry) errorCnt++, (responseMsg = "Industry Missing!");

      const country = countries.find(
        (c) => c.name.toLowerCase() === record.country.toLowerCase()
      );
      if (!country) errorCnt++, (responseMsg = "Country Missing!");

      const state = states.find(
        (s) => s.name.toLowerCase() === record.state.toLowerCase()
      );
      if (!state) errorCnt++, (responseMsg = "State Missing!");

      const legislation = legislations.find(
        (s) => s.name.toLowerCase() === record.legislation.toLowerCase()
      );
      if (!legislation) errorCnt++, (responseMsg = "Legislation Missing!");

      const existingdownload = await prisma.download.findFirst({
        where: { code: record.code },
      });
      if (existingdownload) errorCnt++, (responseMsg = "Code already exists!");

      if (errorCnt == 0) {
        const recordRes = await prisma.download.create({
          data: {
            code: record.code,
            law_category: getKeyByValue(law_category, record.law_category),
            country_id: country?.id,
            state_id: state?.id,
            industry_id: industry?.id,
            legislation_id: legislation?.id,
            name: record.name,
            sources: record.sources,
            effective_date: formatDate(record.effective_date),
            updated_date: formatDate(record.updated_date),
            applies_to: getKeyByValue(applies, record.applies_to),
            status: record.status ? 1 : 2,
            applicability: record.applicability,
            documents: record.documents || "",
          },
        });
        responseMsg = "Record Added.";
        if (recordRes && recordRes.id) {
          saveCnt++;
        }
      }

      return {
        ...record,
        response: responseMsg, // Use the async value in the new property
      };
    });

    const updatedJsonData = await Promise.all(updatedJsonDataPromises);
    // Exporting to Excel
    const ws = XLSX.utils.json_to_sheet(updatedJsonData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Responses");
    XLSX.writeFile(wb, filePath);

    const downloadPath =
      process.env.APP_URL + "/public/upload/download/importexcel/" + filename;
    return NextResponse.json(
      { saveCnt: saveCnt, errorCnt: errorCnt, responseFile: downloadPath },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error uploading download data!", 500);
  } finally {
    await prisma.$disconnect();
  }
}
