import { prisma } from "@/app/utils/prisma.server";
import { NextResponse, NextRequest } from "next/server";
import { downloadModel } from "@/prisma/zod/download";
import * as XLSX from "xlsx";
import { compliance_activityModel } from "@/prisma/zod/compliance_activity";
import { z } from "zod";
import { getToken } from "next-auth/jwt";
import {
  transformFields,
  removeUnderscoreAndCapitalize,
  handleError,
} from "@/app/utils/modelUtils";

export type download = z.infer<typeof downloadModel>;
export type compliance_activity = z.infer<typeof compliance_activityModel>;

export type ColumnType = {
  legislation: boolean;
  rule: boolean;
  legislation_id: boolean;
  rule_id: boolean;
  code: boolean;
  title: boolean;
  activity: boolean;
  reference: boolean;
  who: boolean;
  when: boolean;
  procedure: boolean;
  description: boolean;
  frequency: boolean;
  form_no: boolean;
  due_date: boolean;
  compliance_type: boolean;
  authority: boolean;
  exemption_criteria: boolean;
  event_id: boolean;
  event_sub_id: boolean;
  event_question_id: boolean;
  implications: boolean;
  imprison_duration: boolean;
  imprison_applies_to: boolean;
  currency: boolean;
  fine: boolean;
  fine_per_day: boolean;
  impact: boolean;
  impact_on_unit: boolean;
  impact_on_organization: boolean;
  linked_activity_ids: boolean;
  reference_link: boolean;
  sources: boolean;
  updated_date: boolean;
  event: boolean;
  event_sub: boolean;
  event_question: boolean;
  download_activity: boolean;
};

interface TokenContext {
  req: NextRequest;
}

export async function GET(request: NextRequest) {
  const requestContext: TokenContext = {
    req: request,
  };
  const token = await getToken(requestContext);

  try {
    const pathname = request.nextUrl.pathname;
    const uuid = pathname.split("/").pop();

    const downloadRow = await prisma.download.findUnique({
      where: {
        uuid: uuid,
        approval_status: 1,
        deleted: false,
        user_id: token?.sub ? parseInt(token.sub) : 0,
      },
      include: {
        download_activity: {
          select: {
            id: true,
            compliance_activity_id: true,
          },
        },
      },
    });
    if (downloadRow) {
      const fields = [
        "law_category",
        "country",
        "state",
        "legislation_id",
        "rule_id",
        "code",
        "title",
        "activity",
        "reference",
        "who",
        "when",
        "procedure",
        "description",
        "frequency",
        "form_no",
        "due_date",
        "compliance_type",
        "authority",
        "exemption_criteria",
        "event_id",
        "event_sub_id",
        "event_question_id",
        "implications",
        "imprison_duration",
        "imprison_applies_to",
        "currency",
        "fine",
        "fine_per_day",
        "impact",
        "impact_on_unit",
        "impact_on_organization",
        "linked_activity_ids",
        "reference_link",
        "sources",
        "updated_date",
      ];

      // const additionalColumns = ["law_category", "country", "state"];

      // Extract compliance_activity_id from downloadRow
      const complianceActivityIds =
        downloadRow?.download_activity.map(
          (item) => item.compliance_activity_id
        ) || undefined;
      const whereClause = {
        deleted: false,
        id: { in: complianceActivityIds as number[] },
      };

      const compliance_activitys = await prisma.compliance_activity.findMany({
        where: whereClause,
        include: {
          legislation: {
            select: {
              id: true,
              name: true,
              law_category: true,
              country: true,
              state: true,
            },
            // include: {
            //   country: {
            //     select: {
            //       name: true,
            //     },
            //   },
            //   state: {
            //     select: {
            //       name: true,
            //     },
            //   },
            // },
          },
          rule: {
            select: {
              name: true,
            },
          },
        },
      });

      const capitalizedWithSpaceFields = transformFields(fields);

      const compliance_activitysWithCapitalizedAndSpacedKeys =
        compliance_activitys.map((compliance_activity) => {
          console.log(
            "compliance_activity row",
            compliance_activity.legislation
          );

          const transformedEntry: Record<string, never> = {};

          fields.forEach((field, index) => {
            const updatedKey = capitalizedWithSpaceFields[index];

            if (field === "law_category") {
              const law_category =
                compliance_activity?.legislation?.law_category || "";
              transformedEntry[updatedKey] =
                removeUnderscoreAndCapitalize(law_category);
            } else if (field === "country") {
              transformedEntry[updatedKey] =
                compliance_activity?.legislation?.country?.name;
            } else if (field === "state") {
              transformedEntry[updatedKey] =
                compliance_activity?.legislation?.state?.name;
            } else if (field === "legislation_id") {
              transformedEntry[updatedKey] =
                compliance_activity.legislation?.name;
            } else if (field === "rule_id") {
              transformedEntry[updatedKey] = compliance_activity?.rule?.name;
            } else {
              transformedEntry[updatedKey] = compliance_activity[field];
            }
          });

          return transformedEntry;
        });

      const ws = XLSX.utils.json_to_sheet(
        compliance_activitysWithCapitalizedAndSpacedKeys,
        {
          header: capitalizedWithSpaceFields,
        }
      );

      // Create the Excel workbook
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "compliance_activity");

      // Write the Excel file to a buffer
      const workBookOutput = XLSX.write(wb, {
        bookType: "csv",
        type: "buffer",
      });
      const buffer = Buffer.from(workBookOutput);

      const res = new NextResponse(buffer);

      const filename = "activity-approved-download.csv";
      res.headers.set("Content-Type", "text/csv");

      res.headers.set(
        "Content-Disposition",
        "attachment; filename=" + filename
      );

      return res;
    }

    return NextResponse.json(
      { response: "Compliance Activity Data not found!" },
      { status: 404 }
    );
  } catch (e) {
    return handleError(e, "error reading download", 500);
  } finally {
    await prisma.$disconnect();
  }
}
