import { handleError } from "@/app/utils/modelUtils";
import { prisma, getCount } from "@/app/utils/prisma.server";
import { NextResponse } from "next/server";

export async function GET() {
  const today = new Date();
  const startOfMonth = new Date(today.getFullYear(), today.getMonth(), 1);
  // console.log("start of month =========> ", startOfMonth);
  const endOfMonth = new Date(today.getFullYear(), today.getMonth() + 1, 0);
  // console.log("end of month =========> ", endOfMonth);

  try {
    const currentMonthLegislationCount = await getCount(
      "legislation",
      startOfMonth,
      endOfMonth
    );
    const totalLegislationCount = await getCount(
      "legislation",
      undefined,
      undefined
    );
    const currentMonthRuleCount = await getCount(
      "rule",
      startOfMonth,
      endOfMonth
    );
    const totalRuleCount = await getCount("rule", undefined, undefined);
    const currentMonthComplianceActivityCount = await getCount(
      "compliance_activity",
      startOfMonth,
      endOfMonth
    );
    const totalComplianceActivityCount = await getCount(
      "compliance_activity",
      undefined,
      undefined
    );

    return NextResponse.json(
      {
        Current_Month_Legislation_Count: currentMonthLegislationCount,
        Total_Legislation_Count: totalLegislationCount,
        Current_Month_Rule_Count: currentMonthRuleCount,
        Total_Rule_Count: totalRuleCount,
        Current_Month_Compliance_Activity_Count:
          currentMonthComplianceActivityCount,
        Total_Compliance_Activity_Count: totalComplianceActivityCount,
      },
      { status: 200 }
    );
  } catch (e) {
    return handleError(e, "error counting data", 500);
  } finally {
    // Disconnect Prisma client after the request is processed
    await prisma.$disconnect();
  }
}
