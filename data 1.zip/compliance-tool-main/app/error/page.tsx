"use client";

export default function Error() {
  return (
    <main className="container-fluid d-flex justify-content-center p-5 ">
      <div>
        <h1>Error</h1>
        Something is not right
      </div>
    </main>
  );
}
