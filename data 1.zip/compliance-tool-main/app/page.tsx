"use client";

import React, { useState, useCallback, useRef } from "react";
import DownloadComponent from "@/components/DownloadComponent";
import AgGridTableComponent from "@/components/AgGridTableComponent";

import {
  Chart as ChartJS,
  ArcElement,
  Tooltip,
  Legend,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
} from "chart.js";
import { Doughnut, Pie, Bar } from "react-chartjs-2";
import { Button, Modal } from "react-bootstrap";
import Image from "next/image";

ChartJS.register(
  ArcElement,
  CategoryScale,
  LinearScale,
  BarElement,
  Title,
  Tooltip,
  Legend
);

export default function Dashboard() {
  const [showModal, setShowModal] = useState(false);

  const closeModal = () => {
    setShowModal(false);
  };

  const gridApiRef = useRef(null);

  const [selectedOption, setSelectedOption] = useState("Overall");

  const overallData = {
    labels: [
      "Complied",
      "Escalated",
      "Non-Complied",
      "Delayed",
      "Delayed Reported",
      "Approval Pending",
      "Re-Assigned",
    ],
    datasets: [
      {
        data: [247, 45, 112, 13, 18, 13, 7],
        backgroundColor: [
          "#00bf00",
          "hsl(43, 84%, 65%)",
          "#FF0000",
          "#9400d3",
          "#0000ff",
          "hsl(195, 74%, 62%)",
          "#ff7f00",
        ],
        borderColor: [
          "#00bf00",
          "hsl(43, 84%, 65%)",
          "#FF0000",
          "#9400d3",
          "#0000ff",
          "hsl(195, 74%, 62%)",
          "#ff7f00",
        ],
        borderWidth: 1,
      },
    ],
  };

  const riskData = {
    labels: ["Severe", "High", "Moderate", "Low", "Minor"],
    datasets: [
      {
        data: Array.from({ length: 5 }, () => Math.floor(Math.random() * 112)),
        backgroundColor: [
          "#ce141e",
          "#ff0000",
          "#fb6363",
          "#f89191",
          "#fcb3b3",
        ],
        borderColor: ["#ce141e", "#ff0000", "#fb6363", "#f89191", "#fcb3b3"],
        borderWidth: 1,
      },
    ],
  };

  const legalEntityData = {
    labels: [
      "Demo Entity Pvt Ltd",
      "ABC Mining Pvt Ltd	",
      "JFW Limited",
      "R Ltd",
    ],
    datasets: [
      {
        label: "Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#00bf00",
      },
      {
        label: "Escalated",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(43, 84%, 65%)",
      },
      {
        label: "Non-Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#FF0000",
      },
      {
        label: "Delayed",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#9400d3",
      },
      {
        label: "Delayed Reported",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#0000ff",
      },
      {
        label: "Approval Pending",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(195, 74%, 62%)",
      },
      {
        label: "Re-Assigned",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#ff7f00",
      },
    ],
  };

  const unitData = {
    labels: [
      "Corporate Office - Mumbai",
      "Mining Unit",
      "Registered Office - Pune",
      "JFW pune",
    ],
    datasets: [
      {
        label: "Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#00bf00",
      },
      {
        label: "Escalated",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(43, 84%, 65%)",
      },
      {
        label: "Non-Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#FF0000",
      },
      {
        label: "Delayed",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#9400d3",
      },
      {
        label: "Delayed Reported",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#0000ff",
      },
      {
        label: "Approval Pending",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(195, 74%, 62%)",
      },
      {
        label: "Re-Assigned",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#ff7f00",
      },
    ],
  };

  const functionData = {
    labels: [
      "Secretarial",
      "Regulatory Laws",
      "Human Resources",
      "Maintenance",
    ],
    datasets: [
      {
        label: "Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#00bf00",
      },
      {
        label: "Escalated",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(43, 84%, 65%)",
      },
      {
        label: "Non-Complied",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#FF0000",
      },
      {
        label: "Delayed",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#9400d3",
      },
      {
        label: "Delayed Reported",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#0000ff",
      },
      {
        label: "Approval Pending",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "hsl(195, 74%, 62%)",
      },
      {
        label: "Re-Assigned",
        data: Array.from({ length: 7 }, () => Math.floor(Math.random() * 1000)),
        backgroundColor: "#ff7f00",
      },
    ],
  };

  const unitOptions = {
    responsive: true,

    scales: {
      x: {
        stacked: true,
      },
      y: {
        stacked: true,
      },
    },
  };

  // const regionData = {
  //   labels: ["January", "February", "March", "April", "May", "June", "July"],
  //   datasets: [
  //     {
  //       label: "Dataset 1",
  //       data: [752, 421, 635, 189, 874, 567, 321],
  //       borderColor: "rgb(255, 99, 132)",
  //       backgroundColor: "rgba(255, 99, 132, 0.5)",
  //     },
  //     {
  //       label: "Dataset 2",
  //       data: [456, 789, 234, 567, 890, 123, 678],
  //       borderColor: "rgb(53, 162, 235)",
  //       backgroundColor: "rgba(53, 162, 235, 0.5)",
  //     },
  //   ],
  // };

  // const stateData = {
  //   labels: ["January", "February", "March", "April", "May", "June", "July"],
  //   datasets: [
  //     {
  //       label: "Dataset 1",
  //       data: [325, 789, 456, 123, 567, 890, 234],
  //       backgroundColor: "rgb(255, 99, 132)",
  //     },
  //     {
  //       label: "Dataset 2",
  //       data: [325, 789, 456, 123, 567, 890, 234],
  //       backgroundColor: "rgb(75, 192, 192)",
  //     },
  //     {
  //       label: "Dataset 3",
  //       data: [456, 789, 234, 567, 890, 123, 678],
  //       backgroundColor: "rgb(53, 162, 235)",
  //     },
  //   ],
  // };

  // const legalEntityOptions = {
  //   responsive: true,
  //   plugins: {
  //     legend: {
  //       position: "top" as const,
  //     },
  //     title: {
  //       display: true,
  //       text: "Legal Entity",
  //     },
  //   },
  // };

  // const regionOptions = {
  //   indexAxis: "y" as const,
  //   elements: {
  //      : {
  //       borderWidth: 2,
  //     },
  //   },
  //   responsive: true,
  //   plugins: {
  //     legend: {
  //       position: "right" as const,
  //     },
  //     title: {
  //       display: true,
  //       text: "Chart.js Horizontal Bar Chart",
  //     },
  //   },
  // };

  // const stateOptions = {
  //   plugins: {
  //     title: {
  //       display: true,
  //       text: "Chart.js Bar Chart - Stacked",
  //     },
  //   },
  //   responsive: true,
  //   scales: {
  //     x: {
  //       stacked: true,
  //     },
  //     y: {
  //       stacked: true,
  //     },
  //   },
  // };

  // const functionOptions = {
  //   responsive: true,
  //   plugins: {
  //     legend: {
  //       position: "top" as const,
  //     },
  //     title: {
  //       display: true,
  //       text: "Chart.js Bar Chart",
  //     },
  //   },
  // };

  const handleButtonClick = (option) => {
    setSelectedOption(option);
  };

  const getDataForGraph = () => {
    switch (selectedOption) {
      case "Overall":
        return overallData;
      case "Legal Entity":
        return legalEntityData;
      // case "Region":
      //   return regionData;
      // case "State":
      //   return stateData;
      case "Unit / Location":
        return unitData;
      case "Function":
        return functionData;
      default:
        return overallData;
    }
  };

  const getGraphOption = () => {
    switch (selectedOption) {
      case "Legal Entity":
        return unitOptions;
      // case "Region":
      //   return unitOptions;
      // case "State":
      //   return unitOptions;
      case "Unit / Location":
        return unitOptions;
      case "Function":
        return unitOptions;
      default:
        return unitOptions;
    }
  };

  const generateColumnData = (additionalColumn = {}) =>
    [
      { headerName: "Sr No", field: "sr_no" },
      additionalColumn.header
        ? {
            headerName: additionalColumn.header,
            field: additionalColumn.field,
          }
        : null,
      { headerName: "Complied", field: "complied" },
      { headerName: "Escalated", field: "escalated" },
      { headerName: "Non Complied", field: "non_complied" },
      { headerName: "Delayed", field: "delayed" },
      { headerName: "Delayed Reported", field: "delayed_reported" },
      { headerName: "Approval Pending", field: "approval_pending" },
      { headerName: "Re-Assigned", field: "re_assigned" },
    ].filter(Boolean);

  const overallColData = generateColumnData();
  const entityColData = generateColumnData({
    header: "Entity",
    field: "entity",
  });
  const unitColData = generateColumnData({ header: "Unit", field: "unit" });
  const functionColData = generateColumnData({
    header: "Function Name",
    field: "function_name",
  });

  const regionColData = generateColumnData({
    header: "Function Name",
    field: "function_name",
  });

  const stateColData = generateColumnData({
    header: "Function Name",
    field: "function_name",
  });

  const overallrowData = [
    {
      sr_no: 1,
      complied: 67,
      posing: 93,
      non_complied: 154,
      delayed: 14,
      delayed_reported: 6,
      wfa: 12,
      re_opened: 5,
    },
  ];

  const entityrowData = [
    {
      sr_no: 1,
      entity: "Demo Entity Pvt Ltd",
      complied: 2,
      posing: 120,
      non_complied: 260,
      delayed: 2,
      delayed_reported: 2,
      wfa: 4,
      re_opened: 0,
    },
    {
      sr_no: 2,
      entity: "ABC Mining Pvt Ltd",
      complied: 0,
      posing: 0,
      non_complied: 80,
      delayed: 0,
      delayed_reported: 0,
      wfa: 2,
      re_opened: 0,
    },
    {
      sr_no: 3,
      entity: "Demo Entity -2",
      complied: 1,
      posing: 0,
      non_complied: 45,
      delayed: 1,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 4,
      entity: "JFW Limited",
      complied: 1,
      posing: 0,
      non_complied: 41,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 5,
      entity: "R Ltd",
      complied: 1,
      posing: 1,
      non_complied: 3,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 6,
      entity: "S Limited",
      complied: 1,
      posing: 9,
      non_complied: 15,
      delayed: 1,
      delayed_reported: 0,
      wfa: 1,
      re_opened: 0,
    },
  ];

  const unitrowData = [
    {
      sr_no: 1,
      unit: "Corporate Office - Mumbai",
      complied: 2,
      posing: 12,
      non_complied: 93,
      delayed: 3,
      delayed_reported: 2,
      wfa: 4,
      re_opened: 0,
    },
    {
      sr_no: 2,
      unit: "Mining Unit",
      complied: 0,
      posing: 0,
      non_complied: 80,
      delayed: 0,
      delayed_reported: 0,
      wfa: 2,
      re_opened: 0,
    },
    {
      sr_no: 3,
      unit: "Registered Office - Pune",
      complied: 1,
      posing: 108,
      non_complied: 214,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 4,
      unit: "JFW Pune",
      complied: 1,
      posing: 0,
      non_complied: 41,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 5,
      unit: "Office branch-Mumbai",
      complied: 1,
      posing: 1,
      non_complied: 3,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 6,
      unit: "Main office-Delhi",
      complied: 1,
      posing: 9,
      non_complied: 15,
      delayed: 1,
      delayed_reported: 0,
      wfa: 1,
      re_opened: 0,
    },
  ];

  const functionrowData = [
    {
      sr_no: 1,
      function_name: "Secretarial",
      complied: 2,
      posing: 12,
      non_complied: 93,
      delayed: 3,
      delayed_reported: 2,
      wfa: 4,
      re_opened: 0,
    },
    {
      sr_no: 2,
      function_name: "Regulatory Laws",
      complied: 0,
      posing: 0,
      non_complied: 80,
      delayed: 0,
      delayed_reported: 0,
      wfa: 2,
      re_opened: 0,
    },
    {
      sr_no: 3,
      function_name: "Human Resources",
      complied: 5,
      posing: 122,
      non_complied: 282,
      delayed: 1,
      delayed_reported: 0,
      wfa: 1,
      re_opened: 0,
    },
    {
      sr_no: 4,
      function_name: "Maintenance",
      complied: 0,
      posing: 0,
      non_complied: 8,
      delayed: 0,
      delayed_reported: 0,
      wfa: 1,
      re_opened: 1,
    },
    {
      sr_no: 5,
      function_name: "VAGAD",
      complied: 0,
      posing: 0,
      non_complied: 8,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
    {
      sr_no: 6,
      function_name: "Research and Development",
      complied: 0,
      posing: 0,
      non_complied: 82,
      delayed: 0,
      delayed_reported: 0,
      wfa: 0,
      re_opened: 0,
    },
  ];

  const regionrowData = [
    {
      sr_no: 1,
      function_name: "test",
      complied: 2,
      posing: 4,
      non_complied: 6,
      delayed: 8,
      delayed_reported: 10,
      wfa: 12,
      re_opened: 15,
    },
  ];

  const staterowData = [
    {
      sr_no: 1,
      function_name: "test",
      complied: 2,
      posing: 4,
      non_complied: 6,
      delayed: 8,
      delayed_reported: 10,
      wfa: 12,
      re_opened: 15,
    },
  ];

  const getHeight = () => {
    switch (selectedOption) {
      case "Overall":
        return "250px";
      default:
        return "550px";
    }
  };

  const getColData = () => {
    switch (selectedOption) {
      case "Overall":
        return overallColData;
      case "Legal Entity":
        return entityColData;
      case "Region":
        return regionColData;
      case "State":
        return stateColData;
      case "Unit / Location":
        return unitColData;
      case "Function":
        return functionColData;
      default:
        return overallColData;
    }
  };

  const getRowData = () => {
    switch (selectedOption) {
      case "Overall":
        return overallrowData;
      case "Legal Entity":
        return entityrowData;
      case "Region":
        return regionrowData;
      case "State":
        return staterowData;
      case "Unit / Location":
        return unitrowData;
      case "Function":
        return functionrowData;
      default:
        return overallrowData;
    }
  };

  const customColumns = [
    { headerName: "Client Task ID", field: "client_task_id" },
    { headerName: "Entity", field: "entity" },
    { headerName: "Unit", field: "unit" },
    { headerName: "Function", field: "function" },

    { headerName: "Legislation", field: "legislation" },
    { headerName: "Rule", field: "rule" },
    { headerName: "Reference", field: "reference" },
    { headerName: "Who", field: "who" },
    { headerName: "When", field: "when" },
    { headerName: " Activity", field: "activity" },
    { headerName: "Impact", field: "impact" },
    { headerName: "Executor", field: "executor" },
    { headerName: "Legal Due Date", field: "legal_due_date" },
    { headerName: "Ttrn ID", field: "ttrn_id" },
    { headerName: "Comments", field: "comments" },
    { headerName: "Event_Not_Occured (Yes / No)", field: "event_not_occured" },
  ];
  const staticData = [
    {
      client_task_id: "D03040000273",
      entity: "ABC Mining Pvt Ltd",
      unit: "Corporate Office - Mumbai",
      function: "Secretarial",
      legislation: "The Customs Act, 1962",
      rule: "The Special Economic Zones (Customs Procedures) Regulations, 2003	",
      reference: "Rule 13(2)",
      who: "Zone Unit",
      when: "On export of goods by special economic zone unit",
      activity:
        "Export goods by post subject to the normal procedure applicable to export through Foreign Post Office",
      impact: "Low",
      executor: "Regucheck user",
      legal_due_date: "08-11-2023	",
      ttrn_id: "12916",
      comments: "Complied",
      event_not_occured: "Open",
    },
  ];

  const handleRowClick = useCallback(() => {
    setShowModal(true);
  }, []);
  return (
    <div className="pb-4">
      <div className="container-fluid">
        <div className="custom-dashboard container">
          <div className="row justify-content-center">
            {/* <div className="col-xl-3 col-sm-6 col-md-12 mb-4 "> */}
            <div className="col-md-3 mb-4">
              <div className="card green">
                <div className="card-icon">
                  {" "}
                  <Image
                    className="logo "
                    src="/checked.png"
                    alt="compliance"
                    width="40"
                    height="40"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-green">247</div>
                    <div className="card-prev text-green">Complied</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card yellow">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/exclamation-bulb.png"
                    alt="compliance"
                    width="40"
                    height="40"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-warning">45</div>
                    <div className="card-prev text-warning">Escalated</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card red">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/exclamation_alert.png"
                    alt="compliance"
                    width="35"
                    height="35"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-red">112</div>
                    <div className="card-prev text-red">Non Complied</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card voilet">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/watch.png"
                    alt="compliance"
                    width="40"
                    height="40"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-voilet">13</div>
                    <div className="card-prev text-voilet">Delayed</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card peach">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/order-history.png"
                    alt="compliance"
                    width="40"
                    height="40"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-navy-blue">18</div>
                    <div className="card-prev text-navy-blue">
                      Delayed Reported
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card blue">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/order-history.png"
                    alt="compliance"
                    width="40"
                    height="40"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-info">13</div>
                    <div className="card-prev text-info">Approval Pending</div>
                  </div>
                </div>
              </div>
            </div>

            <div className="col-md-3">
              <div className="card orange">
                <div className="card-icon">
                  <Image
                    className="logo "
                    src="/reuse.png"
                    alt="compliance"
                    width="35"
                    height="35"
                  />
                </div>
                <div className="card-info">
                  <div className="card-hrs-wrapper">
                    <div className="card-hrs text-orange">7</div>
                    <div className="card-prev text-orange">Re-Assigned</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-md-12 bg-white rounded-corner mt-4">
          <div className="d-flex justify-content-space-between align-items-center p-2">
            <div className="col-md-6  px-0">
              <button
                className={`btn btn-primary light m-2 ${
                  selectedOption === "Overall" ? "active" : ""
                }`}
                onClick={() => handleButtonClick("Overall")}
              >
                Overall
              </button>
              <button
                className={`btn btn-primary light m-2 ${
                  selectedOption === "Legal Entity" ? "active" : ""
                }`}
                onClick={() => handleButtonClick("Legal Entity")}
              >
                Legal Entity
              </button>
              <button
                className={`btn btn-primary light m-2 ${
                  selectedOption === "Unit / Location" ? "active" : ""
                }`}
                onClick={() => handleButtonClick("Unit / Location")}
              >
                Unit / Location
              </button>
              <button
                className={`btn btn-primary light m-2 ${
                  selectedOption === "Function" ? "active" : ""
                }`}
                onClick={() => handleButtonClick("Function")}
              >
                Function
              </button>
            </div>
            <div className="col-md-5 text-end">
              <DownloadComponent
                url={"/sample-data/SampleCSV.csv"}
                text={"Export"}
              />
            </div>
          </div>

          <div className="row custom_row justify-content-center p-4">
            {selectedOption === "Overall" ? (
              <div className="row justify-content-space-evenly ">
                <div className="col-md-4">
                  <h5 className="px-0 mb-2 text-center text-muted fw-bold">
                    <u>Status-Wise</u>
                  </h5>

                  <Doughnut
                    options={{
                      responsive: true,
                    }}
                    data={getDataForGraph()}
                  />
                </div>
                <div className="col-md-4 p-2 ">
                  <h5 className="px-0 mb-2 text-center text-muted fw-bold">
                    <u>Impact-Wise</u>
                  </h5>

                  <Pie
                    options={{
                      responsive: true,
                    }}
                    data={riskData}
                  />
                </div>
              </div>
            ) : (
              <>
                {selectedOption === "Unit / Location" ? (
                  <div className="row custom_row justify-content-center px-0 mb-4">
                    <div className="col-md-2 ">
                      <select className="form-select btn light btn-primary">
                        <option selected>Select Entity</option>
                        <option value="1">ABC Mining Pvt Ltd</option>
                        <option value="2">JFW Limited</option>
                        <option value="4">R Pvt Ltd</option>
                        <option value="3">Demo Entity Pvt Ltd</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  ""
                )}
                {selectedOption === "Function" ? (
                  <div className="row custom_row justify-content-center px-0 mb-4">
                    <div className="col-md-2 ">
                      <select className="form-select btn light btn-primary">
                        <option selected>Select Entity</option>
                        <option value="1">ABC Mining Pvt Ltd</option>
                        <option value="2">JFW Limited</option>
                        <option value="4">R Pvt Ltd</option>
                        <option value="3">Demo Entity Pvt Ltd</option>
                      </select>
                    </div>
                    <div className="col-md-2 ">
                      <select className="form-select btn light btn-primary">
                        <option selected>Select Unit</option>
                        <option value="1">Coorporate Office - Mumbai</option>
                        <option value="2">Mining Unit</option>
                        <option value="3">Registered Office - Pune</option>
                        <option value="4">JFW - Pune</option>
                      </select>
                    </div>
                  </div>
                ) : (
                  ""
                )}
                <div className="row custom_row px-0 justify-content-center">
                  <div className="col-md-8 p-3">
                    <Bar options={getGraphOption()} data={getDataForGraph()} />
                  </div>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
      <div>
        <AgGridTableComponent
          aggridHeight={getHeight()}
          customColumns={getColData()}
          customRows={getRowData()}
          handleRowClick={handleRowClick}
          gridApiRef={gridApiRef}
          rowClickSelection={true}
        />
      </div>
      <Modal show={showModal} onHide={closeModal} dialogClassName="large-modal">
        <Modal.Header closeButton>
          <h5>{"Activities"}</h5>
        </Modal.Header>
        <Modal.Body className="p-4">
          {/* <Nav variant="tabs" defaultActiveKey="mainActivities">
            <Nav.Item>
              <Nav.Link
                eventKey="mainActivities"
                onClick={() => handlePageChange("mainActivities")}
              >
                Main Activities
              </Nav.Link>
            </Nav.Item>
          </Nav> */}

          <div className="card">
            <AgGridTableComponent
              slug="/activity_history"
              aggridPadding="p-0"
              page="Main Activities"
              customColumns={customColumns}
              customRows={staticData}
            />
          </div>
        </Modal.Body>
        <Modal.Footer>
          {/* <Button variant="primary light">Save changes</Button> */}
          <Button variant="danger light" onClick={closeModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
}
