import React from "react";
import PreLoaderComponent from "@/components/PreLoaderComponent";
const LoadingPage = () => {
  return (
    <div>
      <PreLoaderComponent />
    </div>
  );
};
export default LoadingPage;
