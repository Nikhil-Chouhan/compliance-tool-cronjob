"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";

export default function AddUnit() {
  const formFields = [
    {
      label: "Unit",
      name: "Unit_id",
      type: "text",
      required: true,
    },
  ];
  return (
    <>
      <FormComponent
        slug="/unit"
        type="Add"
        showbreadCrumb={true}
        page="Unit"
        formFields={formFields}
      />
    </>
  );
}
