"use client";

import React from "react";
import AgGridTableComponent from "@/components/AgGridTableComponent";

export default function Unit() {
  const customColumns = [{ headerName: "Unit Name", field: "unit" }];
  const staticData = [
    {
      unit: "Corporate Office - Mumbai",
    },
    {
      unit: "Registered Office - Pune",
    },
    {
      unit: "Mining Unit",
    },
    {
      unit: "JFW pune",
    },
    {
      unit: "Grupo_Pune",
    },
    {
      unit: "VAGAD FACTORY 2",
    },
    {
      unit: "CROMA_Pune",
    },
    {
      unit: "Manopatra",
    },
    {
      unit: "Unit Data",
    },
  ];
  return (
    <>
      <AgGridTableComponent
        slug="/unit"
        page="Unit List"
        actionBtn={true}
        addBtn={true}
        importBtn={true}
        customColumns={customColumns}
        customRows={staticData}
      />
    </>
  );
}
