export const inputStyles = {
    borderColor: '#c6c6c6',
    color: '#000',
};


    