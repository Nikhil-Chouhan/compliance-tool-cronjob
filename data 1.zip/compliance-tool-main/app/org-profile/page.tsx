"use client";

import React from "react";
import FormComponent from "@/components/FormComponent";
import Image from "next/image";

export default function OrgProfile() {
  const formFields = [
    {
      label: "Organization Name :",
      name: "Organization_name",
      type: "text",

      required: true,
    },
    {
      label: "Industry :",
      name: "Industry_id",
      type: "select",
      required: true,

      options: [
        { value: 1, label: "Health Care" },
        { value: 2, label: "Manufacturing" },
        { value: 3, label: "Consulting" },
        { value: 4, label: "IT & ITES" },
        { value: 5, label: "Telecom" },
        { value: 6, label: "Retail" },
        { value: 7, label: "Startups" },
        { value: 8, label: "Manpower Services" },
      ],
    },
    {
      label: "Business Type :",
      name: "Business_type",
      type: "select",
      required: true,

      options: [
        { value: 1, label: "Shops and Commercial Establishments" },
        { value: 2, label: "Factory" },
        { value: 3, label: "Warehouse" },
        { value: 4, label: "Security Services" },
        { value: 5, label: "Health Care" },
        { value: 6, label: "Bank" },
      ],
    },
    {
      label: "Company Address (Line 1) :",
      name: "entity_id",
      type: "textarea",
      required: true,
    },
    {
      label: "Company Address (Line 2) :",
      name: "entity_id",
      type: "textarea",
      required: false,
    },
    {
      label: "Country :",
      name: "country_id",
      type: "select",
      required: true,
      options: [
        { value: 1, label: "India" },
        { value: 2, label: "Canada" },
        { value: 3, label: "United Kingdom" },
        { value: 4, label: "Australia" },
        { value: 5, label: "United States of America" },
        { value: 6, label: "France" },
        { value: 7, label: "Germany" },
        { value: 8, label: "Japan" },
      ],
    },
    {
      label: "State :",
      name: "State_id",
      type: "select",
      required: true,
      options: [
        { value: 1, label: "Andhra Pradesh" },
        { value: 2, label: "Arunachal Pradesh" },
        { value: 3, label: "Assam" },
        { value: 4, label: "Bihar" },
        { value: 5, label: "Chhattisgarh" },
      ],
    },
    {
      label: "City :",
      name: "City_id",
      type: "select",
      required: true,
      options: [
        { value: 1, label: "Hyderabad" },
        { value: 2, label: "Guwahati" },
        { value: 3, label: "Patna" },
        { value: 4, label: "Raipur" },
        { value: 5, label: "Bangalore" },
      ],
    },
    {
      label: "Area Code 1 :",
      name: "area_code1",
      type: "select",
      required: true,
      options: [
        { value: 1, label: " +91 India" },
        { value: 2, label: " +1 USA" },
        { value: 3, label: " +1 Canada" },
        { value: 4, label: "+44 UK" },
        { value: 5, label: "+61 Australia" },
        { value: 6, label: "+81 Japan" },
      ],
    },
    {
      label: "Area Code 2 :",
      name: "area_code2",
      type: "select",
      required: false,
      options: [
        { value: 1, label: " +91 India" },
        { value: 2, label: " +1 USA" },
        { value: 3, label: " +1 Canada" },
        { value: 4, label: "+44 UK" },
        { value: 5, label: "+61 Australia" },
        { value: 6, label: "+81 Japan" },
      ],
    },
    {
      label: "Phone Number 1 :",
      name: "Phone_number1",
      type: "tel",
      required: true,
    },
    {
      label: "Phone Number 2 :",
      name: "Phone_number2",
      type: "tel",
      required: false,
    },
    {
      label: "Email Address 1 :",
      name: "email_address1",
      type: "email",
      required: true,
    },
    {
      label: "Email Address 2 :",
      name: "email_address2",
      type: "email",
      required: false,
    },
    {
      label: "Brand Primary Color :",
      name: "Brandprimary_color",
      type: "color",
      required: true,
    },
    {
      label: "Brand Secondary Color :",
      name: "Brandsecondary_color",
      type: "color",
      required: true,
    },
    {
      label: "Button Text Color :",
      name: "Buttontext_color",
      type: "color",
      required: true,
    },
  ];
  return (
    <>
      <div className="container-fluid">
        <div className="bg-white rounded-corner p-4">
          <h3 className="fw-strong px-1 mb-3">Organization Profile</h3>
          <hr />
          <div className="row custom_row d-flex justify-content-center align-items-center">
            <div className="col-md-7 my-auto px-0">
              <div className="align-items-center">
                <div className="row custom_row justify-content-center">
                  <Image
                    className="supportImage p-0"
                    src="/compliancetoollogo.png"
                    alt="compliancetoollogo"
                    layout="responsive"
                    width={240}
                    height={240}
                  />
                </div>
              </div>
            </div>
            <div className="col-md-5">
              <div>
                <h5>Organization Logo</h5>
                <p>This logo will appear on the tool bar for all users.</p>
                <p style={{ color: "red" }}>
                  Preferred Image Size: 240px x 240px @ 72 DPI Maximum size of
                  1MB.
                </p>
              </div>
            </div>
            <FormComponent
              title="Organization Name"
              slug="/org-profile"
              type="Submit"
              showbreadCrumb={false}
              page="Organization Profile"
              formFields={formFields}
            />
          </div>
        </div>
      </div>
    </>
  );
}
